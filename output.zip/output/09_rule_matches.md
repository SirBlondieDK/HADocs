# 09 Rule Matches

Generated: 2026-07-05 01:49:34

- `normal` — default: `1026`
- `ignored` — proxmox: ignored: `107`
- `ignored` — wled: ignored: `88`
- `ignored` — zigbee2mqtt: ignored: `70`
- `important` — tplink_deco: important: `61`
- `ignored` — mobile_app: ignored: `57`
- `important` — zigbee2mqtt: important: `54`
- `important` — google_cast: important: `20`
- `important` — wled: important: `20`
- `important` — proxmox: important: `18`
- `diagnostic` — frigate: diagnostic: `17`
- `important` — frigate: important: `14`
- `ignored` — tapo: ignored: `13`
- `ignored` — spotify: ignored: `12`
- `important` — mobile_app: important: `11`
- `diagnostic` — proxmox: diagnostic: `9`
- `diagnostic` — mobile_app: diagnostic: `8`
- `diagnostic` — wled: diagnostic: `6`
- `ignored` — frigate: ignored: `4`
- `important` — tapo: important: `3`
- `diagnostic` — tapo: diagnostic: `2`