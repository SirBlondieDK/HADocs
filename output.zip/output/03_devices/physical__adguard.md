# adguard

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.adguard_status` — `on` — `important` — proxmox: important
- `button.adguard_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.adguard_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.adguard_start` — `unknown` — `ignored` — proxmox: ignored
- `button.adguard_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.adguard_cpu_usage` — `0.0763899471021517` — `ignored` — proxmox: ignored
- `sensor.adguard_disk_usage` — `1.26160049438477` — `ignored` — proxmox: ignored
- `sensor.adguard_max_cpu` — `1` — `ignored` — proxmox: ignored
- `sensor.adguard_max_disk_usage` — `1.90024566650391` — `ignored` — proxmox: ignored
- `sensor.adguard_max_memory_usage` — `0.5` — `ignored` — proxmox: ignored
- `sensor.adguard_memory_usage` — `0.0646476745605469` — `ignored` — proxmox: ignored
- `sensor.adguard_memory_usage_percentage` — `12.9295349121094` — `ignored` — proxmox: ignored
- `sensor.adguard_network_input` — `0.308861369267106` — `normal` — default
- `sensor.adguard_network_output` — `0.0428385017439723` — `normal` — default
- `sensor.adguard_status` — `running` — `important` — proxmox: important
- `sensor.adguard_uptime` — `52.3427777777778` — `diagnostic` — proxmox: diagnostic