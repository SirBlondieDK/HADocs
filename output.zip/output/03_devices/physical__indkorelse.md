# Indkorelse

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Software: ``
- Hardware: ``
- Entity count: `36`

## Entities

- `binary_sensor.indkorelse_all_occupancy` — `off` — `normal` — default
- `binary_sensor.indkorelse_car_occupancy` — `off` — `normal` — default
- `binary_sensor.indkorelse_dog_occupancy` — `off` — `normal` — default
- `binary_sensor.indkorelse_motion` — `off` — `important` — frigate: important
- `binary_sensor.indkorelse_person_occupancy` — `off` — `normal` — default
- `camera.indkorelse` — `recording` — `important` — frigate: important
- `image.indkorelse_car` — `2026-07-04T22:27:38.968318` — `normal` — default
- `image.indkorelse_dog` — `2026-07-04T22:27:38.961530` — `normal` — default
- `image.indkorelse_person` — `2026-07-04T22:27:38.967685` — `normal` — default
- `number.indkorelse_contour_area` — `unknown` — `normal` — default
- `number.indkorelse_threshold` — `unknown` — `normal` — default
- `sensor.indkorelse_all_active_count` — `0` — `normal` — default
- `sensor.indkorelse_all_count` — `0` — `normal` — default
- `sensor.indkorelse_camera_fps` — `unknown` — `important` — frigate: important
- `sensor.indkorelse_capture_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.indkorelse_car_active_count` — `0` — `normal` — default
- `sensor.indkorelse_car_count` — `0` — `normal` — default
- `sensor.indkorelse_detect_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.indkorelse_detection_fps` — `unknown` — `important` — frigate: important
- `sensor.indkorelse_dog_active_count` — `0` — `normal` — default
- `sensor.indkorelse_dog_count` — `0` — `normal` — default
- `sensor.indkorelse_ffmpeg_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.indkorelse_person_active_count` — `0` — `normal` — default
- `sensor.indkorelse_person_count` — `0` — `normal` — default
- `sensor.indkorelse_process_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.indkorelse_review_status` — `unknown` — `normal` — default
- `sensor.indkorelse_skipped_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `switch.indkorelse_detect` — `on` — `normal` — default
- `switch.indkorelse_improve_contrast` — `unknown` — `normal` — default
- `switch.indkorelse_motion` — `on` — `normal` — default
- `switch.indkorelse_object_descriptions` — `unknown` — `normal` — default
- `switch.indkorelse_recordings` — `on` — `normal` — default
- `switch.indkorelse_review_alerts` — `on` — `normal` — default
- `switch.indkorelse_review_descriptions` — `unknown` — `normal` — default
- `switch.indkorelse_review_detections` — `on` — `normal` — default
- `switch.indkorelse_snapshots` — `on` — `ignored` — frigate: ignored