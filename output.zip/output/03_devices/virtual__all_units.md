# All Units

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.all_units_favorite_current_song` — `unknown` — `normal` — default
- `media_player.all_units_2` — `off` — `normal` — default