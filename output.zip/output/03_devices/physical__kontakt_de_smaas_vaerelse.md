# Kontakt de smås værelse

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `de_sma_s_vaerelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_de_smas_vaerelse_action` — `unknown` — `normal` — default
- `sensor.kontakt_de_smas_vaerelse_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_de_smas_vaerelse_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored