# zigbee2mqtt

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.zigbee2mqtt_status` — `on` — `important` — proxmox: important
- `button.zigbee2mqtt_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.zigbee2mqtt_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.zigbee2mqtt_start` — `unknown` — `ignored` — proxmox: ignored
- `button.zigbee2mqtt_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_cpu_usage` — `0.0213891851886025` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_disk_usage` — `2.38739395141602` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_max_cpu` — `2` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_max_disk_usage` — `4.83950805664062` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_max_memory_usage` — `1.0` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_memory_usage` — `0.101757049560547` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_memory_usage_percentage` — `10.1757049560547` — `ignored` — proxmox: ignored
- `sensor.zigbee2mqtt_network_input` — `0.326524491421878` — `normal` — default
- `sensor.zigbee2mqtt_network_output` — `0.0576689941808581` — `normal` — default
- `sensor.zigbee2mqtt_status` — `running` — `important` — proxmox: important
- `sensor.zigbee2mqtt_uptime` — `52.3427777777778` — `diagnostic` — proxmox: diagnostic