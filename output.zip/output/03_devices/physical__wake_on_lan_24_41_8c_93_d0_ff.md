# Wake on LAN 24:41:8c:93:d0:ff

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.wake_on_lan_24_41_8c_93_d0_ff` — `2025-01-08T20:33:46.742203+00:00` — `normal` — default
- `device_tracker.server_rum_deco_kokken_sebastianpc` — `not_home` — `important` — tplink_deco: important