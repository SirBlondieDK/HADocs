# Terminal & SSH

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Software: `10.3.0`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.terminal_ssh_korer` — `unknown` — `normal` — default
- `sensor.terminal_ssh_cpu_procent` — `unknown` — `normal` — default
- `sensor.terminal_ssh_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.terminal_ssh_nyeste_version` — `unknown` — `normal` — default
- `sensor.terminal_ssh_version` — `unknown` — `normal` — default
- `switch.terminal_ssh` — `unknown` — `normal` — default
- `update.terminal_ssh_update` — `off` — `normal` — default