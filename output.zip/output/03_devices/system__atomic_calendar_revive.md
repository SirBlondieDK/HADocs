# Atomic Calendar Revive

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `totaldebug`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.atomic_calendar_revive_pre_release` — `unknown` — `normal` — default
- `update.atomic_calendar_revive_update` — `off` — `normal` — default