# button-card

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `custom-cards`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.button_card_pre_release` — `unknown` — `normal` — default
- `update.button_card_update` — `off` — `normal` — default