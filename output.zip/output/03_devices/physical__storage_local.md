# Storage (local)

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Storage`
- Software: ``
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.storage_local_storage_active` — `on` — `normal` — default
- `binary_sensor.storage_local_storage_enabled` — `on` — `normal` — default
- `binary_sensor.storage_local_storage_shared` — `off` — `normal` — default
- `sensor.storage_local_available_storage` — `36.1821403503418` — `normal` — default
- `sensor.storage_local_storage_usage_percentage` — `41.5` — `normal` — default
- `sensor.storage_local_total_storage` — `67.8722076416016` — `normal` — default
- `sensor.storage_local_used_storage` — `28.1986618041992` — `normal` — default