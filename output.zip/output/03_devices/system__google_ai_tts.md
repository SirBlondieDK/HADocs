# Google AI TTS

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-tts-preview`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `tts.google_ai_tts` — `2026-03-02T03:07:54.381201+00:00` — `normal` — default