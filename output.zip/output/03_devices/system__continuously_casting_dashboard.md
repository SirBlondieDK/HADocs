# Continuously Casting Dashboard

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `b0mbays`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.continuously_casting_dashboard_pre_release` — `unknown` — `normal` — default
- `update.continuously_casting_dashboard_update` — `off` — `normal` — default