# Carport

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `carport`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Software: ``
- Hardware: ``
- Entity count: `36`

## Entities

- `binary_sensor.carport_all_occupancy` — `off` — `normal` — default
- `binary_sensor.carport_car_occupancy` — `off` — `normal` — default
- `binary_sensor.carport_dog_occupancy` — `off` — `normal` — default
- `binary_sensor.carport_motion` — `off` — `important` — frigate: important
- `binary_sensor.carport_person_occupancy` — `off` — `normal` — default
- `camera.carport` — `recording` — `important` — frigate: important
- `image.carport_car` — `2026-07-04T22:27:38.966380` — `normal` — default
- `image.carport_dog` — `2026-07-04T22:27:38.969634` — `normal` — default
- `image.carport_person` — `2026-07-04T22:27:38.964073` — `normal` — default
- `number.carport_contour_area` — `unknown` — `normal` — default
- `number.carport_threshold` — `unknown` — `normal` — default
- `sensor.carport_all_active_count` — `0` — `normal` — default
- `sensor.carport_all_count` — `0` — `normal` — default
- `sensor.carport_camera_fps` — `unknown` — `important` — frigate: important
- `sensor.carport_capture_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.carport_car_active_count` — `0` — `normal` — default
- `sensor.carport_car_count` — `0` — `normal` — default
- `sensor.carport_detect_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.carport_detection_fps` — `unknown` — `important` — frigate: important
- `sensor.carport_dog_active_count` — `0` — `normal` — default
- `sensor.carport_dog_count` — `0` — `normal` — default
- `sensor.carport_ffmpeg_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.carport_person_active_count` — `0` — `normal` — default
- `sensor.carport_person_count` — `0` — `normal` — default
- `sensor.carport_process_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.carport_review_status` — `unknown` — `normal` — default
- `sensor.carport_skipped_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `switch.carport_detect` — `on` — `normal` — default
- `switch.carport_improve_contrast` — `unknown` — `normal` — default
- `switch.carport_motion` — `on` — `normal` — default
- `switch.carport_object_descriptions` — `unknown` — `normal` — default
- `switch.carport_recordings` — `on` — `normal` — default
- `switch.carport_review_alerts` — `on` — `normal` — default
- `switch.carport_review_descriptions` — `unknown` — `normal` — default
- `switch.carport_review_detections` — `on` — `normal` — default
- `switch.carport_snapshots` — `on` — `ignored` — frigate: ignored