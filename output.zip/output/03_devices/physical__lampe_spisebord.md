# Lampe spisebord

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `kokken`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Software: `z.1.0`
- Hardware: `0`
- Entity count: `6`

## Entities

- `light.lampe_spisebord` — `on` — `important` — zigbee2mqtt: important
- `select.0xa4c138660fe2058a_effect` — `unknown` — `normal` — default
- `select.lampe_spisebord_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c138660fe2058a_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138660fe2058a_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.lampe_spisebord_do_not_disturb` — `off` — `important` — zigbee2mqtt: important