# Forecast

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Met.no`
- Model: `Forecast`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `weather.forecast_hjem` — `cloudy` — `normal` — default