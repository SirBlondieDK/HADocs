# Usb kontakt stue 1

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `Tuya`
- Model: `3 gang switch`
- Software: ``
- Hardware: `1`
- Entity count: `5`

## Entities

- `sensor.0xa4c138ab3197ecdf_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138ab3197ecdf_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.usb_kontakt_stue_1_center` — `off` — `important` — zigbee2mqtt: important
- `switch.usb_kontakt_stue_1_left` — `off` — `important` — zigbee2mqtt: important
- `switch.usb_kontakt_stue_1_right` — `off` — `important` — zigbee2mqtt: important