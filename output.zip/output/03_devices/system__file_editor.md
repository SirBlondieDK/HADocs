# File editor

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Software: `6.0.0`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.file_editor_korer` — `unknown` — `normal` — default
- `sensor.file_editor_cpu_procent` — `unknown` — `normal` — default
- `sensor.file_editor_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.file_editor_nyeste_version` — `unknown` — `normal` — default
- `sensor.file_editor_version` — `unknown` — `normal` — default
- `switch.file_editor` — `unknown` — `normal` — default
- `update.file_editor_update` — `off` — `normal` — default