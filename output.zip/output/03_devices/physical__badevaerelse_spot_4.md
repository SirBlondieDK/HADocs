# Badeværelse spot 4

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `badevaerelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Software: `1.3.6`
- Hardware: `0`
- Entity count: `7`

## Entities

- `light.badevaerelse_spot_4` — `off` — `important` — zigbee2mqtt: important
- `select.0xe8ca50de7c1c0000_effect` — `unknown` — `normal` — default
- `select.badevaerelse_spot_4_color_power_on_behavior` — `unknown` — `normal` — default
- `select.badevaerelse_spot_4_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xe8ca50de7c1c0000_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xe8ca50de7c1c0000_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.badevaerelse_spot_4_do_not_disturb` — `off` — `important` — zigbee2mqtt: important