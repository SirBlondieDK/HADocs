# Lampe Sofabord

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `WiZ`
- Model: `SHRGBC`
- Software: `1.37.0`
- Hardware: `ESP24 01`
- Entity count: `4`

## Entities

- `light.wiz_rgbw_tunable_44c896` — `off` — `normal` — default
- `number.wiz_rgbw_tunable_44c896_effect_speed` — `unavailable` — `normal` — default
- `sensor.wiz_rgbw_tunable_44c896_signalstyrke` — `unknown` — `normal` — default
- `sensor.wiz_rgbw_tunable_44c896_strom` — `unknown` — `normal` — default