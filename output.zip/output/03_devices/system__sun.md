# Sun

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `9`

## Entities

- `binary_sensor.sun_solar_rising` — `unknown` — `normal` — default
- `sensor.sun_next_dawn` — `2026-07-05T01:49:27+00:00` — `normal` — default
- `sensor.sun_next_dusk` — `2026-07-05T21:05:41+00:00` — `normal` — default
- `sensor.sun_next_midnight` — `2026-07-05T23:28:14+00:00` — `normal` — default
- `sensor.sun_next_noon` — `2026-07-05T11:27:58+00:00` — `normal` — default
- `sensor.sun_next_rising` — `2026-07-05T02:49:01+00:00` — `normal` — default
- `sensor.sun_next_setting` — `2026-07-05T20:06:29+00:00` — `normal` — default
- `sensor.sun_solar_azimuth` — `unknown` — `normal` — default
- `sensor.sun_solar_elevation` — `unknown` — `normal` — default