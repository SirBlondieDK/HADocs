# OpenAI STT

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini-transcribe`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `stt.openai_stt` — `unknown` — `normal` — default