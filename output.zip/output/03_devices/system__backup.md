# Backup

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Backup`
- Software: `2026.7.1`
- Hardware: ``
- Entity count: `5`

## Entities

- `event.backup_automatic_backup` — `2026-07-04T03:40:28.313+00:00` — `normal` — default
- `sensor.backup_backup_manager_state` — `idle` — `normal` — default
- `sensor.backup_last_attempted_automatic_backup` — `2026-07-04T03:40:03+00:00` — `normal` — default
- `sensor.backup_last_successful_automatic_backup` — `2026-07-04T03:40:28+00:00` — `normal` — default
- `sensor.backup_next_scheduled_automatic_backup` — `2026-07-08T03:04:40+00:00` — `normal` — default