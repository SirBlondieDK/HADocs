# Fjernsyn

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `My`
- Model: `Android TV`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.fjernsyn_favorite_current_song` — `unknown` — `normal` — default
- `media_player.fjernsyn` — `idle` — `normal` — default