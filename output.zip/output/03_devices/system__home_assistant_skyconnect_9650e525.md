# Home Assistant SkyConnect (9650e525)

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Nabu Casa`
- Model: `Home Assistant SkyConnect`
- Software: `OpenThread RCP None`
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.home_assistant_skyconnect_9650e525_beta_firmware_updates` — `unknown` — `normal` — default
- `update.home_assistant_skyconnect_9650e525_firmware` — `unknown` — `normal` — default