# Mosquitto broker

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Software: `7.1.0`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.mosquitto_broker_korer` — `unknown` — `normal` — default
- `sensor.mosquitto_broker_cpu_procent` — `unknown` — `normal` — default
- `sensor.mosquitto_broker_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.mosquitto_broker_nyeste_version` — `unknown` — `normal` — default
- `sensor.mosquitto_broker_version` — `unknown` — `normal` — default
- `switch.mosquitto_broker` — `unknown` — `normal` — default
- `update.mosquitto_broker_update` — `off` — `normal` — default