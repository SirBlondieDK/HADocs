# Local Tuya

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `xZetsubou`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.local_tuya_pre_release` — `unknown` — `normal` — default
- `update.local_tuya_update` — `off` — `normal` — default