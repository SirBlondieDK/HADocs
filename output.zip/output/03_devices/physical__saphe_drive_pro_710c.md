# Saphe Drive Pro 710C

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `device_tracker.saphe_drive_pro_710c` — `unavailable` — `normal` — default
- `sensor.saphe_drive_pro_710c_estimated_distance` — `unavailable` — `normal` — default
- `sensor.saphe_drive_pro_710c_power` — `unknown` — `normal` — default
- `sensor.saphe_drive_pro_710c_signalstyrke` — `unknown` — `normal` — default
- `sensor.saphe_drive_pro_710c_vendor` — `unknown` — `normal` — default