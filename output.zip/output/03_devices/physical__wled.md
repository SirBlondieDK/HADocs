# WLED

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `de_sma_s_vaerelse`
- Manufacturer: `WLED`
- Model: `FOSS`
- Software: `16.0.0`
- Hardware: `esp32`
- Entity count: `26`

## Entities

- `binary_sensor.wled_firmware_3` — `unknown` — `normal` — default
- `button.wled_genstart_3` — `unavailable` — `ignored` — wled: ignored
- `device_tracker.kitchen_deco_ledss` — `not_home` — `important` — tplink_deco: important
- `light.wled_3` — `unavailable` — `important` — wled: important
- `number.wled_intensity_3` — `unavailable` — `normal` — default
- `number.wled_speed_3` — `unavailable` — `normal` — default
- `select.wled_color_palette_3` — `unavailable` — `normal` — default
- `select.wled_live_override_3` — `unavailable` — `normal` — default
- `select.wled_playlist_3` — `unavailable` — `ignored` — wled: ignored
- `select.wled_preset_3` — `unavailable` — `ignored` — wled: ignored
- `sensor.wled_estimated_current_3` — `unavailable` — `ignored` — wled: ignored
- `sensor.wled_free_memory_3` — `unknown` — `normal` — default
- `sensor.wled_ip_3` — `unavailable` — `diagnostic` — wled: diagnostic
- `sensor.wled_led_count_3` — `unavailable` — `normal` — default
- `sensor.wled_max_current_3` — `unavailable` — `normal` — default
- `sensor.wled_uptime_3` — `unknown` — `ignored` — wled: ignored
- `sensor.wled_wi_fi_bssid_3` — `unknown` — `normal` — default
- `sensor.wled_wi_fi_channel_3` — `unknown` — `normal` — default
- `sensor.wled_wi_fi_rssi_3` — `unknown` — `diagnostic` — wled: diagnostic
- `sensor.wled_wi_fi_signal_3` — `unknown` — `normal` — default
- `switch.wled_freeze` — `unavailable` — `important` — wled: important
- `switch.wled_nightlight_3` — `unavailable` — `important` — wled: important
- `switch.wled_reverse_3` — `unavailable` — `important` — wled: important
- `switch.wled_sync_receive_3` — `unavailable` — `important` — wled: important
- `switch.wled_sync_send_3` — `unavailable` — `important` — wled: important
- `update.wled_firmware_3` — `unavailable` — `ignored` — wled: ignored