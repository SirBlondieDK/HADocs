# Frigate

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Frigate Add-ons`
- Model: `Home Assistant App`
- Software: `0.17.2`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.frigate_korer` — `unknown` — `normal` — default
- `sensor.frigate_cpu_procent` — `unknown` — `normal` — default
- `sensor.frigate_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.frigate_nyeste_version` — `unknown` — `normal` — default
- `sensor.frigate_version` — `unknown` — `normal` — default
- `switch.frigate` — `unknown` — `normal` — default
- `update.frigate_opdatering` — `off` — `normal` — default