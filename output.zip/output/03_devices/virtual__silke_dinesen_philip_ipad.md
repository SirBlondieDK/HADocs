# Silke Dinesen Philip - iPad

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `iPad`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.silke_dinesen_philip_ipad_batteri` — `unavailable` — `normal` — default