# XPED-0060370B54C3

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `device_tracker.xped_0060370b54c3` — `unavailable` — `normal` — default
- `sensor.xped_0060370b54c3_estimated_distance` — `unavailable` — `normal` — default
- `sensor.xped_0060370b54c3_power` — `unknown` — `normal` — default
- `sensor.xped_0060370b54c3_signalstyrke` — `unknown` — `normal` — default
- `sensor.xped_0060370b54c3_vendor` — `unknown` — `normal` — default