# Loftlampe Stue

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Software: ``
- Hardware: `1`
- Entity count: `6`

## Entities

- `light.loftlampe_stue` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c13862b3e83b4d_effect` — `unknown` — `normal` — default
- `select.loftlampe_stue_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c13862b3e83b4d_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c13862b3e83b4d_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_stue_do_not_disturb` — `off` — `important` — zigbee2mqtt: important