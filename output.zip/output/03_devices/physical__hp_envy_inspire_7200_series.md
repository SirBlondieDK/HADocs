# HP ENVY Inspire 7200 series

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `computer_hjorne`
- Manufacturer: `HP`
- Model: `ENVY Inspire 7200 series`
- Software: `NOVBASPP1N002.2621A.00`
- Hardware: ``
- Entity count: `4`

## Entities

- `sensor.hp_envy_inspire_7200_series` — `idle` — `normal` — default
- `sensor.hp_envy_inspire_7200_series_black_cartridge` — `40` — `normal` — default
- `sensor.hp_envy_inspire_7200_series_tri_color_cartridge` — `30` — `normal` — default
- `sensor.hp_envy_inspire_7200_series_uptime` — `unknown` — `normal` — default