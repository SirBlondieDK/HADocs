# soveværelset og de smås værelse

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `media_player.sovevaerelset_og_de_smas_vaerelse_2` — `off` — `important` — google_cast: important