# WiZ RGBWW Tunable 0123AC

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `WiZ`
- Model: `SHRGB`
- Software: `1.38.0`
- Hardware: `ESP20 01BT`
- Entity count: `4`

## Entities

- `light.wiz_rgbww_tunable_0123ac` — `off` — `normal` — default
- `number.wiz_rgbww_tunable_0123ac_effect_speed` — `unavailable` — `normal` — default
- `sensor.wiz_rgbww_tunable_0123ac_signalstyrke` — `unknown` — `normal` — default
- `sensor.wiz_rgbww_tunable_0123ac_strom` — `unknown` — `normal` — default