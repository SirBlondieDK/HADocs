# Robot plæneklipper

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `have`
- Manufacturer: `Adano Robotic Mower`
- Model: `RMC500E20V-ECWNTS`
- Software: `50003`
- Hardware: `230500`
- Entity count: `46`

## Entities

- `binary_sensor.robot_plaeneklipper_dock` — `off` — `normal` — default
- `binary_sensor.robot_plaeneklipper_multizone` — `off` — `normal` — default
- `binary_sensor.robot_plaeneklipper_multizone_auto` — `off` — `normal` — default
- `binary_sensor.robot_plaeneklipper_online` — `off` — `normal` — default
- `binary_sensor.robot_plaeneklipper_regn_sensor_aktiv` — `on` — `normal` — default
- `button.robot_plaeneklipper_hjem` — `unknown` — `normal` — default
- `button.robot_plaeneklipper_klip_kant` — `unknown` — `normal` — default
- `button.robot_plaeneklipper_pause` — `unknown` — `normal` — default
- `button.robot_plaeneklipper_start` — `2026-04-29T09:48:47.245783+00:00` — `normal` — default
- `device_tracker.robot_plaeneklipper_robot_lokation` — `unknown` — `normal` — default
- `lawn_mower.robot_plaeneklipper` — `Standby` — `normal` — default
- `number.robot_plaeneklipper_regn_forsinkelse` — `180` — `normal` — default
- `number.robot_plaeneklipper_zone_1_prioritet` — `25` — `normal` — default
- `number.robot_plaeneklipper_zone_1_start` — `0` — `normal` — default
- `number.robot_plaeneklipper_zone_2_prioritet` — `25` — `normal` — default
- `number.robot_plaeneklipper_zone_2_start` — `25` — `normal` — default
- `number.robot_plaeneklipper_zone_3_prioritet` — `25` — `normal` — default
- `number.robot_plaeneklipper_zone_3_start` — `50` — `normal` — default
- `number.robot_plaeneklipper_zone_4_prioritet` — `25` — `normal` — default
- `number.robot_plaeneklipper_zone_4_start` — `75` — `normal` — default
- `sensor.robot_plaeneklipper_aktuel_arbejdstid` — `0` — `normal` — default
- `sensor.robot_plaeneklipper_batteri` — `33` — `normal` — default
- `sensor.robot_plaeneklipper_fejl` — `normal` — `normal` — default
- `sensor.robot_plaeneklipper_fejlkode` — `0` — `normal` — default
- `sensor.robot_plaeneklipper_regn_sensor` — `Dry` — `normal` — default
- `sensor.robot_plaeneklipper_regn_sensor_forsinkelse` — `180` — `normal` — default
- `sensor.robot_plaeneklipper_regn_sensor_nedtaeller` — `180` — `normal` — default
- `sensor.robot_plaeneklipper_robot_status` — `Standby` — `normal` — default
- `sensor.robot_plaeneklipper_status_fejl` — `` — `normal` — default
- `sensor.robot_plaeneklipper_tidsstyrring` — `Schedule` — `normal` — default
- `sensor.robot_plaeneklipper_wifi_styrke` — `0` — `normal` — default
- `sensor.robot_plaeneklipper_zone_1_start` — `0` — `normal` — default
- `sensor.robot_plaeneklipper_zone_2_start` — `25` — `normal` — default
- `sensor.robot_plaeneklipper_zone_3_start` — `50` — `normal` — default
- `sensor.robot_plaeneklipper_zone_4_start` — `75` — `normal` — default
- `switch.robot_plaeneklipper_multizone` — `off` — `normal` — default
- `switch.robot_plaeneklipper_multizone_auto` — `off` — `normal` — default
- `switch.robot_plaeneklipper_regn_sensor` — `on` — `normal` — default
- `switch.robot_plaeneklipper_tidsstyrring` — `on` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_fredag` — `09:00 - 20:00 Trim` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_lordag` — `00:00 - 00:00` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_mandag` — `09:00 - 20:00 Trim` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_onsdag` — `09:00 - 20:00 Trim` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_sondag` — `09:00 - 20:00 Trim` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_tirsdag` — `00:00 - 00:00` — `normal` — default
- `text.robot_plaeneklipper_ugeplan_torsdag` — `00:00 - 00:00` — `normal` — default