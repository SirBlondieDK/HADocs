# homeassistant

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `VM`
- Software: ``
- Hardware: ``
- Entity count: `20`

## Entities

- `binary_sensor.homeassistant_status` — `on` — `important` — proxmox: important
- `button.homeassistant` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_hibernate` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_reset` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_shut_down` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_start` — `unknown` — `ignored` — proxmox: ignored
- `button.homeassistant_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.homeassistant_cpu_usage` — `3.20481184873061` — `ignored` — proxmox: ignored
- `sensor.homeassistant_disk_usage` — `0.0` — `ignored` — proxmox: ignored
- `sensor.homeassistant_max_cpu` — `4` — `ignored` — proxmox: ignored
- `sensor.homeassistant_max_disk_usage` — `32.0` — `ignored` — proxmox: ignored
- `sensor.homeassistant_max_memory_usage` — `4.0` — `ignored` — proxmox: ignored
- `sensor.homeassistant_memory_usage` — `3.60524368286133` — `ignored` — proxmox: ignored
- `sensor.homeassistant_memory_usage_percentage` — `90.1310920715332` — `ignored` — proxmox: ignored
- `sensor.homeassistant_network_input` — `3.77744380291551` — `normal` — default
- `sensor.homeassistant_network_output` — `1.41219561733305` — `normal` — default
- `sensor.homeassistant_status` — `running` — `important` — proxmox: important
- `sensor.homeassistant_uptime` — `52.0636111111111` — `diagnostic` — proxmox: diagnostic