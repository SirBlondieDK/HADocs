# Facadelys

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `udendors`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Hardware: `gen1`
- Entity count: `8`

## Entities

- `binary_sensor.shelly1_3494546a3372_cloud` — `unknown` — `normal` — default
- `binary_sensor.shelly1_3494546a3372_input` — `unknown` — `normal` — default
- `button.facadelys_reboot` — `unknown` — `normal` — default
- `sensor.shelly1_3494546a3372_rssi` — `unknown` — `normal` — default
- `sensor.shelly1_3494546a3372_uptime` — `unknown` — `normal` — default
- `switch.facadelys` — `off` — `normal` — default
- `update.shelly1_3494546a3372_beta_firmware` — `unknown` — `normal` — default
- `update.shelly1_3494546a3372_firmware` — `unknown` — `normal` — default