# Pool

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `terressen`
- Manufacturer: `Tuya`
- Model: `SH-OP01`
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `sensor.pool_current` — `unknown` — `normal` — default
- `sensor.pool_power` — `unknown` — `normal` — default
- `sensor.pool_total_energy` — `unavailable` — `normal` — default
- `sensor.pool_voltage` — `unknown` — `normal` — default
- `switch.pool_socket_1` — `unavailable` — `normal` — default