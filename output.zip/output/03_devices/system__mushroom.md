# Mushroom

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `piitaya`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.mushroom_pre_release` — `unknown` — `normal` — default
- `update.mushroom_update` — `off` — `normal` — default