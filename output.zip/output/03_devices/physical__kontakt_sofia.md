# Kontakt sofia

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sofia_s_vaerelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_sofia_action` — `unknown` — `normal` — default
- `sensor.kontakt_sofia_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_sofia_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored