# layout-card

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `thomasloven`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.layout_card_pre_release` — `unknown` — `normal` — default
- `update.layout_card_update` — `off` — `normal` — default