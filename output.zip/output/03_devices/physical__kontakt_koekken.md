# Kontakt Køkken

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `kokken`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_kokken_action` — `unknown` — `normal` — default
- `sensor.kontakt_kokken_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_kokken_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored