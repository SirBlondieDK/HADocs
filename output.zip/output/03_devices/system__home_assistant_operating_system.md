# Home Assistant Operating System

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Operating System`
- Software: `18.1`
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.home_assistant_operating_system_newest_version` — `unknown` — `normal` — default
- `sensor.home_assistant_operating_system_version` — `unknown` — `normal` — default
- `update.home_assistant_operating_system_update` — `off` — `normal` — default