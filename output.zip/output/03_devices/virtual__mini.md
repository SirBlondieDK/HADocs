# mini 

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.mini_favorite_current_song` — `unknown` — `normal` — default
- `media_player.mini_2` — `off` — `normal` — default