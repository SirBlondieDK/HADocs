# Google Translate en com

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Google`
- Model: `Google Translate TTS`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `tts.google_en_com` — `unknown` — `normal` — default