# Saphe Drive Pro F81F

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `device_tracker.saphe_drive_pro_f81f` — `unavailable` — `normal` — default
- `sensor.saphe_drive_pro_f81f_estimated_distance` — `unavailable` — `normal` — default
- `sensor.saphe_drive_pro_f81f_power` — `unknown` — `normal` — default
- `sensor.saphe_drive_pro_f81f_signalstyrke` — `unknown` — `normal` — default
- `sensor.saphe_drive_pro_f81f_vendor` — `unknown` — `normal` — default