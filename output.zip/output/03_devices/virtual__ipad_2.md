# iPad (2)

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `iPad (8th Generation)`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.ipad_2_batteri` — `unavailable` — `normal` — default