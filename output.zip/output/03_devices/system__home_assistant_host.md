# Home Assistant Host

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Host`
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `sensor.home_assistant_host_apparmor_version` — `unknown` — `normal` — default
- `sensor.home_assistant_host_disk_free` — `unknown` — `normal` — default
- `sensor.home_assistant_host_disk_total` — `unknown` — `normal` — default
- `sensor.home_assistant_host_disk_used` — `unknown` — `normal` — default
- `sensor.home_assistant_host_os_agent_version` — `unknown` — `normal` — default