# Group Element

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `custom-cards`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.group_element_pre_release` — `unknown` — `normal` — default
- `update.group_element_update` — `off` — `normal` — default