# Studio Code Server

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant Community Apps`
- Model: `Home Assistant App`
- Software: `6.0.1`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.studio_code_server_korer` — `unknown` — `normal` — default
- `sensor.studio_code_server_cpu_procent` — `unknown` — `normal` — default
- `sensor.studio_code_server_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.studio_code_server_nyeste_version` — `unknown` — `normal` — default
- `sensor.studio_code_server_version` — `unknown` — `normal` — default
- `switch.studio_code_server` — `unknown` — `normal` — default
- `update.studio_code_server_opdatering` — `off` — `normal` — default