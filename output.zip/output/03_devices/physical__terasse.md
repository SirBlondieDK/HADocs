# Terasse

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `terressen`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Software: ``
- Hardware: ``
- Entity count: `36`

## Entities

- `binary_sensor.terasse_all_occupancy` — `off` — `normal` — default
- `binary_sensor.terasse_car_occupancy` — `off` — `normal` — default
- `binary_sensor.terasse_dog_occupancy` — `off` — `normal` — default
- `binary_sensor.terasse_motion` — `off` — `important` — frigate: important
- `binary_sensor.terasse_person_occupancy` — `off` — `normal` — default
- `camera.terasse` — `recording` — `important` — frigate: important
- `image.terasse_car` — `2026-07-04T22:27:38.965589` — `normal` — default
- `image.terasse_dog` — `2026-07-04T22:27:38.966948` — `normal` — default
- `image.terasse_person` — `2026-07-04T22:27:38.962813` — `normal` — default
- `number.terasse_contour_area` — `unknown` — `normal` — default
- `number.terasse_threshold` — `unknown` — `normal` — default
- `sensor.terasse_all_active_count` — `0` — `normal` — default
- `sensor.terasse_all_count` — `0` — `normal` — default
- `sensor.terasse_camera_fps` — `unknown` — `important` — frigate: important
- `sensor.terasse_capture_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.terasse_car_active_count` — `0` — `normal` — default
- `sensor.terasse_car_count` — `0` — `normal` — default
- `sensor.terasse_detect_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.terasse_detection_fps` — `unknown` — `important` — frigate: important
- `sensor.terasse_dog_active_count` — `0` — `normal` — default
- `sensor.terasse_dog_count` — `0` — `normal` — default
- `sensor.terasse_ffmpeg_cpu_usage` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.terasse_person_active_count` — `0` — `normal` — default
- `sensor.terasse_person_count` — `0` — `normal` — default
- `sensor.terasse_process_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `sensor.terasse_review_status` — `unknown` — `normal` — default
- `sensor.terasse_skipped_fps` — `unknown` — `diagnostic` — frigate: diagnostic
- `switch.terasse_detect` — `on` — `normal` — default
- `switch.terasse_improve_contrast` — `unknown` — `normal` — default
- `switch.terasse_motion` — `on` — `normal` — default
- `switch.terasse_object_descriptions` — `unknown` — `normal` — default
- `switch.terasse_recordings` — `on` — `normal` — default
- `switch.terasse_review_alerts` — `on` — `normal` — default
- `switch.terasse_review_descriptions` — `unknown` — `normal` — default
- `switch.terasse_review_detections` — `on` — `normal` — default
- `switch.terasse_snapshots` — `on` — `ignored` — frigate: ignored