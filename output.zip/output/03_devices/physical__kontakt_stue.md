# kontakt stue

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_stue_action` — `unavailable` — `normal` — default
- `sensor.kontakt_stue_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_stue_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored