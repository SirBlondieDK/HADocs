# lampe de små pære 1

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Software: `z.1.0`
- Hardware: `0`
- Entity count: `6`

## Entities

- `light.lampe_de_sma_paere_1` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c1386c83e5e3a6_effect` — `unknown` — `normal` — default
- `select.lampe_de_sma_paere_1_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c1386c83e5e3a6_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c1386c83e5e3a6_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.lampe_de_sma_paere_1_do_not_disturb` — `off` — `important` — zigbee2mqtt: important