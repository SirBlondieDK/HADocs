# Bubble Card

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Clooos`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.bubble_card_pre_release` — `unknown` — `normal` — default
- `update.bubble_card_update` — `off` — `normal` — default