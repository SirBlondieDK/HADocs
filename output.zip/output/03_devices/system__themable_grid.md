# themable-grid

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `nervetattoo`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.themable_grid_pre_release` — `unknown` — `normal` — default
- `update.themable_grid_update` — `off` — `normal` — default