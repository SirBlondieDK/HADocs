# Marlene Ravn

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `iPhone 13`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.marlene_ravn_batteri` — `unknown` — `normal` — default