# HADashboard

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.hadashboard_status` — `off` — `important` — proxmox: important
- `button.hadashboard_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.hadashboard_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.hadashboard_start` — `unknown` — `ignored` — proxmox: ignored
- `button.hadashboard_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.hadashboard_cpu_usage` — `0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_disk_usage` — `0.0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_max_cpu` — `2` — `ignored` — proxmox: ignored
- `sensor.hadashboard_max_disk_usage` — `20.0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_max_memory_usage` — `1.0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_memory_usage` — `0.0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_memory_usage_percentage` — `0.0` — `ignored` — proxmox: ignored
- `sensor.hadashboard_network_input` — `0.0` — `normal` — default
- `sensor.hadashboard_network_output` — `0.0` — `normal` — default
- `sensor.hadashboard_status` — `stopped` — `important` — proxmox: important
- `sensor.hadashboard_uptime` — `0.0` — `diagnostic` — proxmox: diagnostic