# Spot Hoveddør 2

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `carport`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Software: `1.3.6`
- Hardware: `0`
- Entity count: `7`

## Entities

- `light.spot_hoveddor_2` — `unavailable` — `important` — zigbee2mqtt: important
- `select.0xe8ca50ddfe570000_effect` — `unknown` — `normal` — default
- `select.spot_hoveddor_2_color_power_on_behavior` — `unavailable` — `normal` — default
- `select.spot_hoveddor_2_power_on_behavior` — `unavailable` — `normal` — default
- `sensor.0xe8ca50ddfe570000_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xe8ca50ddfe570000_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.spot_hoveddor_2_do_not_disturb` — `unavailable` — `important` — zigbee2mqtt: important