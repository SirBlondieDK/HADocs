# Loftlampe soveværelse

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sovevaerelse`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Software: ``
- Hardware: `1`
- Entity count: `6`

## Entities

- `light.loftlampe_sovevaerelse` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c1388d5e4bed62_effect` — `unknown` — `normal` — default
- `select.loftlampe_sovevaerelse_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c1388d5e4bed62_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c1388d5e4bed62_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_sovevaerelse_do_not_disturb` — `off` — `important` — zigbee2mqtt: important