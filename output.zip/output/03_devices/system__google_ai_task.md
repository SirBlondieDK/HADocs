# Google AI Task

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-lite`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `ai_task.google_ai_task` — `unknown` — `normal` — default