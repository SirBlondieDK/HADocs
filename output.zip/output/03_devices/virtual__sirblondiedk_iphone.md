# Sirblondiedk iPhone

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `iPhone 13`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `device_tracker.sirblondiedk_iphone` — `unavailable` — `normal` — default
- `sensor.sirblondiedk_iphone_batteri` — `unavailable` — `normal` — default