# Bevægelses sensor badeværelse

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `badevaerelse`
- Manufacturer: `Tuya`
- Model: `Luminance motion sensor`
- Software: `0104012026`
- Hardware: `1`
- Entity count: `8`

## Entities

- `binary_sensor.bevaegelses_sensor_badevaerelse_occupancy` — `off` — `normal` — default
- `number.bevaegelses_sensor_badevaerelse_illuminance_interval` — `60` — `normal` — default
- `select.bevaegelses_sensor_badevaerelse_keep_time` — `30` — `normal` — default
- `select.bevaegelses_sensor_badevaerelse_sensitivity` — `high` — `normal` — default
- `sensor.0xa4c138b01f675fef_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138b01f675fef_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.bevaegelses_sensor_badevaerelse_battery` — `90` — `important` — zigbee2mqtt: important
- `sensor.bevaegelses_sensor_badevaerelse_illuminance` — `1097` — `normal` — default