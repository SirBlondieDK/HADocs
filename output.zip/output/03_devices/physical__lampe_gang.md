# Lampe gang

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `gang`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Software: ``
- Hardware: `1`
- Entity count: `6`

## Entities

- `light.lampe_gang` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c1389de2ac12d0_effect` — `unknown` — `normal` — default
- `select.lampe_gang_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c1389de2ac12d0_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c1389de2ac12d0_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.lampe_gang_do_not_disturb` — `off` — `important` — zigbee2mqtt: important