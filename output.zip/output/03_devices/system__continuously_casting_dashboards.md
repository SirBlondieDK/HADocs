# Continuously Casting Dashboards

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Continuously Casting Dashboards`
- Model: `Integration`
- Software: ``
- Hardware: ``
- Entity count: `11`

## Entities

- `sensor.continuously_casting_dashboards_192_168_68139_status` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_192_168_68_139_status` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_192_168_68_151_status` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_assistant_active` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_connected_devices` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_disconnected_devices` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_media_playing` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_other_content` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_sovevaerelse_hub_status` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_stue_status` — `unknown` — `normal` — default
- `sensor.continuously_casting_dashboards_total_devices` — `unknown` — `normal` — default