# Kaffe hjørnet

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `kokken`
- Manufacturer: `TP-Link`
- Model: `P100`
- Software: `1.4.3 Build 251205 Rel.141413`
- Hardware: `2.0`
- Entity count: `13`

## Entities

- `binary_sensor.kaffe_hjornet_cloud_connection` — `on` — `normal` — default
- `button.kaffe_hjornet_genstart` — `unknown` — `normal` — default
- `number.kaffe_hjornet_turn_off_in` — `120` — `normal` — default
- `sensor.kaffe_hjornet_auto_off_at` — `unknown` — `normal` — default
- `sensor.kaffe_hjornet_device_time` — `unknown` — `normal` — default
- `sensor.kaffe_hjornet_on_since` — `unknown` — `normal` — default
- `sensor.kaffe_hjornet_signal_level` — `3` — `normal` — default
- `sensor.kaffe_hjornet_signal_strength` — `unknown` — `normal` — default
- `sensor.kaffe_hjornet_ssid` — `unknown` — `normal` — default
- `switch.kaffe_hjornet` — `on` — `normal` — default
- `switch.kaffe_hjornet_auto_off_enabled` — `off` — `normal` — default
- `switch.kaffe_hjornet_auto_update_enabled` — `on` — `normal` — default
- `switch.kaffe_hjornet_led` — `on` — `normal` — default