# proxy

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.proxy_status` — `on` — `important` — proxmox: important
- `button.proxy_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.proxy_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.proxy_start` — `unknown` — `ignored` — proxmox: ignored
- `button.proxy_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.proxy_cpu_usage` — `0.173335734515428` — `ignored` — proxmox: ignored
- `sensor.proxy_disk_usage` — `2.76371765136719` — `ignored` — proxmox: ignored
- `sensor.proxy_max_cpu` — `1` — `ignored` — proxmox: ignored
- `sensor.proxy_max_disk_usage` — `7.77682113647461` — `ignored` — proxmox: ignored
- `sensor.proxy_max_memory_usage` — `0.5` — `ignored` — proxmox: ignored
- `sensor.proxy_memory_usage` — `0.0866737365722656` — `ignored` — proxmox: ignored
- `sensor.proxy_memory_usage_percentage` — `17.3347473144531` — `ignored` — proxmox: ignored
- `sensor.proxy_network_input` — `0.393929577432573` — `normal` — default
- `sensor.proxy_network_output` — `0.063800472766161` — `normal` — default
- `sensor.proxy_status` — `running` — `important` — proxmox: important
- `sensor.proxy_uptime` — `52.3427777777778` — `diagnostic` — proxmox: diagnostic