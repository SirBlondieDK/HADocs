# Loftlampe Køkken

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `kokken`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Software: ``
- Hardware: `1`
- Entity count: `6`

## Entities

- `light.loftlampe_kokken` — `on` — `important` — zigbee2mqtt: important
- `select.0xa4c138b4051e6603_effect` — `unknown` — `normal` — default
- `select.loftlampe_kokken_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c138b4051e6603_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138b4051e6603_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_kokken_do_not_disturb` — `off` — `important` — zigbee2mqtt: important