# Adano robotic mower

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Sdahl1234`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.adano_robotic_mower_pre_release` — `unknown` — `normal` — default
- `update.adano_robotic_mower_update` — `off` — `normal` — default