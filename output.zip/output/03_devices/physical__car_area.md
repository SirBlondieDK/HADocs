# Car Area

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Software: ``
- Hardware: ``
- Entity count: `12`

## Entities

- `binary_sensor.car_area_all_occupancy` — `off` — `normal` — default
- `binary_sensor.car_area_car_occupancy` — `unavailable` — `normal` — default
- `binary_sensor.car_area_dog_occupancy` — `unavailable` — `normal` — default
- `binary_sensor.car_area_person_occupancy` — `off` — `normal` — default
- `sensor.car_area_all_active_count` — `0` — `normal` — default
- `sensor.car_area_all_count` — `0` — `normal` — default
- `sensor.car_area_car_active_count` — `unavailable` — `normal` — default
- `sensor.car_area_car_count` — `unavailable` — `normal` — default
- `sensor.car_area_dog_active_count` — `unavailable` — `normal` — default
- `sensor.car_area_dog_count` — `unavailable` — `normal` — default
- `sensor.car_area_person_active_count` — `0` — `normal` — default
- `sensor.car_area_person_count` — `0` — `normal` — default