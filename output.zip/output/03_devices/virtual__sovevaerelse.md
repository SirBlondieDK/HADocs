# Soveværelse

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Google Inc.`
- Model: `Chromecast`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.sovevaerelse_favorite_current_song` — `unavailable` — `normal` — default
- `media_player.sovevaerelse_2` — `unavailable` — `normal` — default