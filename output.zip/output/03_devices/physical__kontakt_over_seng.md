# Kontakt over seng

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sovevaerelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_over_seng_action` — `unavailable` — `normal` — default
- `sensor.kontakt_over_seng_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_over_seng_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored