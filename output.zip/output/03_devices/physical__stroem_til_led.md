# Strøm til Led

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `loft`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Hardware: `gen1`
- Entity count: `8`

## Entities

- `binary_sensor.shelly1_3494546ae397_cloud` — `unknown` — `normal` — default
- `binary_sensor.shelly1_3494546ae397_input` — `unknown` — `normal` — default
- `button.shelly1_3494546ae397_reboot` — `unknown` — `normal` — default
- `sensor.shelly1_3494546ae397_rssi` — `unknown` — `normal` — default
- `sensor.shelly1_3494546ae397_uptime` — `unknown` — `normal` — default
- `switch.shelly1_3494546ae397` — `off` — `normal` — default
- `update.shelly1_3494546ae397_beta_firmware_update` — `unknown` — `normal` — default
- `update.shelly1_3494546ae397_firmware_update` — `unknown` — `normal` — default