# Deco Stue

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Hardware: `2.0`
- Entity count: `20`

## Entities

- `binary_sensor.kitchen_deco_deco_online_2` — `on` — `important` — tplink_deco: important
- `binary_sensor.kitchen_deco_internet_online_2` — `on` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_2` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_d100c` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_google_home` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_ipad_3` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_iphone` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_p100` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_pc_8a31` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_sirblondiedk` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_stue_maja_iphone` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_google_home` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_wiz_44c896` — `home` — `important` — tplink_deco: important
- `sensor.kitchen_deco_backhaul_type_2` — `unknown` — `normal` — default
- `sensor.kitchen_deco_bssid_2_4_ghz_2` — `unknown` — `normal` — default
- `sensor.kitchen_deco_bssid_5_ghz_2` — `unknown` — `normal` — default
- `sensor.kitchen_deco_connected_clients_2` — `10` — `normal` — default
- `sensor.kitchen_deco_ip_address_2` — `unknown` — `normal` — default
- `sensor.kitchen_deco_kitchen_down_2` — `0.0` — `normal` — default
- `sensor.kitchen_deco_kitchen_up_2` — `0.0` — `normal` — default