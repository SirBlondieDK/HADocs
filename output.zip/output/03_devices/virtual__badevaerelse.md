# Badeværelse

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `badevaerelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.badevaerelse_favorite_current_song` — `unknown` — `normal` — default
- `media_player.badevaerelse_2` — `idle` — `normal` — default