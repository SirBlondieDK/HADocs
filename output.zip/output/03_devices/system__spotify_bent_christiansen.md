# Spotify Bent Christiansen

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Spotify AB`
- Model: `Spotify premium`
- Software: ``
- Hardware: ``
- Entity count: `12`

## Entities

- `media_player.spotify_bent_christiansen` — `idle` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_acousticness` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_danceability` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_energy` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_instrumentalness` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_key` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_liveness` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_mode` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_speechiness` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_tempo` — `unavailable` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_time_signature` — `unknown` — `ignored` — spotify: ignored
- `sensor.spotify_bent_christiansen_song_valence` — `unknown` — `ignored` — spotify: ignored