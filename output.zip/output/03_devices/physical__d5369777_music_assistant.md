# d5369777-music-assistant

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Jellyfin`
- Model: `Music Assistant`
- Software: `2.9.5`
- Hardware: ``
- Entity count: `1`

## Entities

- `media_player.d5369777_music_assistant` — `idle` — `normal` — default