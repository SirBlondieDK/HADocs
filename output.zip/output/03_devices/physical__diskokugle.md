# Diskokugle

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Hardware: `gen1`
- Entity count: `8`

## Entities

- `binary_sensor.diskokugle_cloud` — `unknown` — `normal` — default
- `binary_sensor.diskokugle_input` — `unknown` — `normal` — default
- `button.diskokugle_reboot` — `unknown` — `normal` — default
- `sensor.diskokugle_rssi` — `unknown` — `normal` — default
- `sensor.diskokugle_uptime` — `unknown` — `normal` — default
- `switch.diskokugle` — `off` — `normal` — default
- `update.diskokugle_beta_firmware_update` — `unknown` — `normal` — default
- `update.diskokugle_firmware_update` — `unknown` — `normal` — default