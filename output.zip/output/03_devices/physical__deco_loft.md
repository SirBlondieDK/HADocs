# Deco loft

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Hardware: `2.0`
- Entity count: `41`

## Entities

- `binary_sensor.vaskerum_deco_deco_online` — `on` — `important` — tplink_deco: important
- `binary_sensor.vaskerum_deco_internet_online` — `on` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_google_home_mini_2` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_iot_device_0a30` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_iot_device_2d49` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_loft_device_1501` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_loft_device_1738` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_loft_device_3d54` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_loft_device_4f06` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_adguard` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_ajax_002133f1` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_d210` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_device_a5e8` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_device_d57f` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_esp_c2432f` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_google_home_mini_2` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_homeassistant` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_kamera_1` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_kamera_2` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_kamera_3` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_proxy_server` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_shelly1_3494546a3372` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_shelly1_3494546a890c` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_shelly1_3494546ae397` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_wlan0` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_wlan0_2` — `home` — `important` — tplink_deco: important
- `select.server_rum_deco_loft_polling_interval` — `30` — `normal` — default
- `sensor.vaskerum_deco_bssid_2_4_ghz` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_bssid_5_ghz` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_connected_clients` — `24` — `normal` — default
- `sensor.vaskerum_deco_cpu_usage` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_cpu_usage_raw` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_ip_address` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_memory_usage` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_memory_usage_raw` — `unknown` — `normal` — default
- `sensor.vaskerum_deco_total_down` — `0.625` — `normal` — default
- `sensor.vaskerum_deco_total_up` — `0.25` — `normal` — default
- `sensor.vaskerum_deco_vaskerum_down` — `0.625` — `normal` — default
- `sensor.vaskerum_deco_vaskerum_up` — `0.25` — `normal` — default
- `switch.vaskerum_deco_polling` — `on` — `normal` — default