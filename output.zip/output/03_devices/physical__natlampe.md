# Natlampe

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sovevaerelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Software: `1.3.6`
- Hardware: `0`
- Entity count: `7`

## Entities

- `light.natlampe` — `off` — `important` — zigbee2mqtt: important
- `select.0xe8ca50de90a20000_effect` — `unknown` — `normal` — default
- `select.natlampe_color_power_on_behavior` — `unknown` — `normal` — default
- `select.natlampe_power_on_behavior` — `on` — `normal` — default
- `sensor.0xe8ca50de90a20000_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xe8ca50de90a20000_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.natlampe_do_not_disturb` — `off` — `important` — zigbee2mqtt: important