# H5075 22BD

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sofia_s_vaerelse`
- Manufacturer: `Govee`
- Model: `H5075`
- Software: ``
- Hardware: ``
- Entity count: `4`

## Entities

- `sensor.h5075_22bd_battery` — `100` — `normal` — default
- `sensor.h5075_22bd_humidity` — `59.2` — `normal` — default
- `sensor.h5075_22bd_signal_strength` — `unknown` — `normal` — default
- `sensor.h5075_22bd_temperature` — `23.9` — `normal` — default