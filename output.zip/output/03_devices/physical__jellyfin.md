# jellyfin

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.jellyfin_status` — `on` — `important` — proxmox: important
- `button.jellyfin_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.jellyfin_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.jellyfin_start` — `unknown` — `ignored` — proxmox: ignored
- `button.jellyfin_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.jellyfin_cpu_usage` — `0.153891020707607` — `ignored` — proxmox: ignored
- `sensor.jellyfin_disk_usage` — `3.84215545654297` — `ignored` — proxmox: ignored
- `sensor.jellyfin_max_cpu` — `2` — `ignored` — proxmox: ignored
- `sensor.jellyfin_max_disk_usage` — `15.5809288024902` — `ignored` — proxmox: ignored
- `sensor.jellyfin_max_memory_usage` — `2.0` — `ignored` — proxmox: ignored
- `sensor.jellyfin_memory_usage` — `0.254646301269531` — `ignored` — proxmox: ignored
- `sensor.jellyfin_memory_usage_percentage` — `12.7323150634766` — `ignored` — proxmox: ignored
- `sensor.jellyfin_network_input` — `0.302751176059246` — `normal` — default
- `sensor.jellyfin_network_output` — `0.385323641821742` — `normal` — default
- `sensor.jellyfin_status` — `running` — `important` — proxmox: important
- `sensor.jellyfin_uptime` — `52.3427777777778` — `diagnostic` — proxmox: diagnostic