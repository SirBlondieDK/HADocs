# frigate

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.frigate_status` — `on` — `important` — proxmox: important
- `button.frigate_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.frigate_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.frigate_start` — `unknown` — `ignored` — proxmox: ignored
- `button.frigate_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.frigate_cpu_usage` — `14.9202066863664` — `ignored` — proxmox: ignored
- `sensor.frigate_disk_usage` — `10.696849822998` — `ignored` — proxmox: ignored
- `sensor.frigate_max_cpu` — `4` — `ignored` — proxmox: ignored
- `sensor.frigate_max_disk_usage` — `19.5181427001953` — `ignored` — proxmox: ignored
- `sensor.frigate_max_memory_usage` — `4.0` — `ignored` — proxmox: ignored
- `sensor.frigate_memory_usage` — `0.750534057617188` — `ignored` — proxmox: ignored
- `sensor.frigate_memory_usage_percentage` — `18.7633514404297` — `ignored` — proxmox: ignored
- `sensor.frigate_network_input` — `133.569391577505` — `normal` — default
- `sensor.frigate_network_output` — `3.06566507741809` — `normal` — default
- `sensor.frigate_status_2` — `running` — `important` — proxmox: important
- `sensor.frigate_uptime_2` — `14.2263888888889` — `diagnostic` — proxmox: diagnostic