# Hikvision NVR / IP Camera

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `maciej-or`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.hikvision_nvr_ip_camera_pre_release` — `unknown` — `normal` — default
- `update.hikvision_nvr_ip_camera_update` — `off` — `normal` — default