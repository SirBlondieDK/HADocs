# Kabelskinne

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `de_sma_s_vaerelse`
- Manufacturer: `Tuya`
- Model: `DELTACO SH-P03USB2`
- Software: ``
- Hardware: ``
- Entity count: `6`

## Entities

- `light.kabelskinne_usb_1` — `off` — `normal` — default
- `switch.deltaco_sh_p03usb2_socket` — `unknown` — `normal` — default
- `switch.deltaco_sh_p03usb2_socket_1` — `unknown` — `normal` — default
- `switch.deltaco_sh_p03usb2_socket_2` — `off` — `normal` — default
- `switch.deltaco_sh_p03usb2_socket_3` — `off` — `normal` — default
- `switch.deltaco_sh_p03usb2_usb_1` — `off` — `normal` — default