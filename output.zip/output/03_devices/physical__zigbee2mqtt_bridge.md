# Zigbee2MQTT Bridge

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Zigbee2MQTT`
- Model: `Bridge`
- Software: `2.9.2`
- Hardware: `EmberZNet 8.0.2 [GA]`
- Entity count: `8`

## Entities

- `binary_sensor.zigbee2mqtt_bridge_connection_state` — `on` — `normal` — default
- `binary_sensor.zigbee2mqtt_bridge_restart_required` — `unknown` — `normal` — default
- `button.zigbee2mqtt_bridge_restart` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `select.zigbee2mqtt_bridge_log_level` — `info` — `normal` — default
- `sensor.zigbee2mqtt_bridge_coordinator_version` — `unknown` — `normal` — default
- `sensor.zigbee2mqtt_bridge_network_map` — `unknown` — `normal` — default
- `sensor.zigbee2mqtt_bridge_version` — `2.9.2` — `normal` — default
- `switch.zigbee2mqtt_bridge_permit_join` — `off` — `important` — zigbee2mqtt: important