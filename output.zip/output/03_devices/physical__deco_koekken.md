# Deco Køkken

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Hardware: `2.0`
- Entity count: `19`

## Entities

- `binary_sensor.kitchen_deco_deco_online` — `on` — `important` — tplink_deco: important
- `binary_sensor.kitchen_deco_internet_online` — `on` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_fjernsyn_stue` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_google_home_2` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_google_home_mini` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_ipad_2` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_phone_c504` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_phone_d366` — `home` — `important` — tplink_deco: important
- `device_tracker.kitchen_deco_wiz_0123ac` — `home` — `important` — tplink_deco: important
- `device_tracker.server_rum_deco_stue_sebastiipiphone` — `home` — `important` — tplink_deco: important
- `device_tracker.vaskerum_deco_google_home_mini` — `home` — `important` — tplink_deco: important
- `sensor.kitchen_deco_backhaul_type` — `unknown` — `normal` — default
- `sensor.kitchen_deco_bssid_2_4_ghz` — `unknown` — `normal` — default
- `sensor.kitchen_deco_bssid_5_ghz` — `unknown` — `normal` — default
- `sensor.kitchen_deco_connected_clients` — `9` — `normal` — default
- `sensor.kitchen_deco_ip_address` — `unknown` — `normal` — default
- `sensor.kitchen_deco_kitchen_down` — `0.0` — `normal` — default
- `sensor.kitchen_deco_kitchen_up` — `0.0` — `normal` — default