# Loftlampe bryggers

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `bryggers`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Software: ``
- Hardware: `1`
- Entity count: `6`

## Entities

- `light.loftlampe_bryggers` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c1389d8fc50e9e_effect` — `unknown` — `normal` — default
- `select.loftlampe_bryggers_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c1389d8fc50e9e_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c1389d8fc50e9e_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_bryggers_do_not_disturb` — `off` — `important` — zigbee2mqtt: important