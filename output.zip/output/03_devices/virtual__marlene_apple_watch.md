# Marlene – Apple Watch

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `Apple Watch Series 7 (GPS + Cellular)`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.marlene_apple_watch_batteri` — `unknown` — `normal` — default