# Kontakt Rumdeler

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.kontakt_rumdeler_action` — `unavailable` — `normal` — default
- `sensor.kontakt_rumdeler_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_rumdeler_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored