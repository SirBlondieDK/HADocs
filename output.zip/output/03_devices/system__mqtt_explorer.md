# MQTT Explorer

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Gollum add-on repository for Home Assistant`
- Model: `Home Assistant App`
- Software: `browser-1.0.3`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.mqtt_explorer_korer` — `unknown` — `normal` — default
- `sensor.mqtt_explorer_cpu_procent` — `unknown` — `normal` — default
- `sensor.mqtt_explorer_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.mqtt_explorer_nyeste_version` — `unknown` — `normal` — default
- `sensor.mqtt_explorer_version` — `unknown` — `normal` — default
- `switch.mqtt_explorer` — `unknown` — `normal` — default
- `update.mqtt_explorer_update` — `off` — `normal` — default