# Kontakt Sebastian

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sebastian_s_vaerelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Software: ``
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.0x0000000001714ade_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0x0000000001714ade_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.kontakt_sebastian_action` — `unknown` — `normal` — default