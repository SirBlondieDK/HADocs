# Loftlampe Sebastian

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sebastian_s_vaerelse`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Software: `z.1.0`
- Hardware: `0`
- Entity count: `6`

## Entities

- `light.loftlampe_sebastian` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c1383c67fc69da_effect` — `unknown` — `normal` — default
- `select.loftlampe_sebastian_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c1383c67fc69da_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c1383c67fc69da_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_sebastian_do_not_disturb` — `off` — `important` — zigbee2mqtt: important