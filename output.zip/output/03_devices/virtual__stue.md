# Stue

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `stue`
- Manufacturer: `Google Inc.`
- Model: `Google Nest Hub`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.stue_favorite_current_song` — `unknown` — `normal` — default
- `media_player.stue_2` — `idle` — `normal` — default