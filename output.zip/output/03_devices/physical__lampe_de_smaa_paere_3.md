# lampe de små pære 3

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Software: `z.1.0`
- Hardware: `0`
- Entity count: `6`

## Entities

- `light.lampe_de_sma_paere_3` — `off` — `important` — zigbee2mqtt: important
- `select.0xa4c138bf6a50d1db_effect` — `unknown` — `normal` — default
- `select.lampe_de_sma_paere_3_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c138bf6a50d1db_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138bf6a50d1db_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.lampe_de_sma_paere_3_do_not_disturb` — `off` — `important` — zigbee2mqtt: important