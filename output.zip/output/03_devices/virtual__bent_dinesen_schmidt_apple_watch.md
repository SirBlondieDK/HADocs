# Bent Dinesen Schmidt – Apple Watch

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `Apple Watch Series 7 (GPS + Cellular)`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `device_tracker.bent_dinesen_schmidt_apple_watch` — `unavailable` — `normal` — default
- `sensor.bent_dinesen_schmidt_apple_watch_batteri` — `unavailable` — `normal` — default