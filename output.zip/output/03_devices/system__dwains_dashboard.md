# Dwains Dashboard

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `dwainscheeren`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.dwains_dashboard_pre_release` — `unknown` — `normal` — default
- `update.dwains_dashboard_update` — `off` — `normal` — default