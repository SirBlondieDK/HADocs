# Soveværelse hub

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `sovevaerelse`
- Manufacturer: `Google Inc.`
- Model: `Google Nest Hub`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.sovevaerelse_hub_favorite_current_song` — `unknown` — `normal` — default
- `media_player.sovevaerelse_hub_2` — `idle` — `normal` — default