# Home Assistant Supervisor

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Supervisor`
- Software: `2026.06.2`
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.home_assistant_supervisor_cpu_percent` — `unknown` — `normal` — default
- `sensor.home_assistant_supervisor_memory_percent` — `unknown` — `normal` — default
- `update.home_assistant_supervisor_update` — `off` — `normal` — default