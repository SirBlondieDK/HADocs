# Google Assistant SDK Custom

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `tronikos`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.google_assistant_sdk_custom_pre_release` — `unknown` — `normal` — default
- `update.google_assistant_sdk_custom_update` — `off` — `normal` — default