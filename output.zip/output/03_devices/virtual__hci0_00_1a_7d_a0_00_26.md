# hci0 (00:1A:7D:A0:00:26)

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Realtek`
- Model: `Bluetooth Radio (0bda:8771)`
- Software: `6.18.37-haos`
- Hardware: `usb:v1D6Bp0246d0555`
- Entity count: `0`

## Entities
