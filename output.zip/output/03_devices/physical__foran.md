# Foran

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `udendors`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Software: ``
- Hardware: ``
- Entity count: `6`

## Entities

- `binary_sensor.foran_all_occupancy` — `off` — `normal` — default
- `binary_sensor.foran_person_occupancy` — `off` — `normal` — default
- `sensor.foran_all_active_count` — `0` — `normal` — default
- `sensor.foran_all_count` — `0` — `normal` — default
- `sensor.foran_person_active_count` — `0` — `normal` — default
- `sensor.foran_person_count` — `0` — `normal` — default