# HACS

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `hacs.xyz`
- Model: ``
- Software: `2.0.5`
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.hacs_pre_release` — `unknown` — `normal` — default
- `update.hacs_update` — `off` — `normal` — default