# OpenAI TTS

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini-tts`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `tts.openai_tts` — `unknown` — `normal` — default