# Fjernsyn Stue

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `My`
- Model: `Android TV`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `media_player.fjernsyn_stue` — `off` — `important` — google_cast: important