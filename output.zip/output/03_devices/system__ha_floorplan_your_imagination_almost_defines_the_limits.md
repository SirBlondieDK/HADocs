# ha-floorplan 🖌🎨 | Your imagination (almost) defines the limits

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `ExperienceLovelace`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.ha_floorplan_your_imagination_almost_defines_the_limits_pre_release` — `unknown` — `normal` — default
- `update.ha_floorplan_your_imagination_almost_defines_the_limits_update` — `off` — `normal` — default