# Sebastian Dinesen Philip - iPhone

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `_uden_område`
- Manufacturer: `Apple`
- Model: `iPhone XR`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.sebastian_dinesen_philip_iphone_batteri` — `unavailable` — `normal` — default