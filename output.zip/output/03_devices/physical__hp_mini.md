# hp-mini

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Node`
- Software: ``
- Hardware: ``
- Entity count: `18`

## Entities

- `binary_sensor.hp_mini_backup_status` — `off` — `ignored` — proxmox: ignored
- `binary_sensor.hp_mini_status` — `on` — `important` — proxmox: important
- `button.hp_mini_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.hp_mini_shut_down` — `unknown` — `ignored` — proxmox: ignored
- `button.hp_mini_start_all` — `unknown` — `ignored` — proxmox: ignored
- `button.hp_mini_stop_all` — `unknown` — `ignored` — proxmox: ignored
- `button.hp_mini_suspend_all` — `unknown` — `ignored` — proxmox: ignored
- `sensor.hp_mini_backup_duration` — `1.4` — `ignored` — proxmox: ignored
- `sensor.hp_mini_cpu_usage` — `14.0376007162041` — `ignored` — proxmox: ignored
- `sensor.hp_mini_disk_usage` — `28.1986618041992` — `ignored` — proxmox: ignored
- `sensor.hp_mini_last_backup` — `2026-06-28T11:36:10+00:00` — `ignored` — proxmox: ignored
- `sensor.hp_mini_max_cpu` — `6` — `ignored` — proxmox: ignored
- `sensor.hp_mini_max_disk_usage` — `67.8722076416016` — `ignored` — proxmox: ignored
- `sensor.hp_mini_max_memory_usage` — `7.41191482543945` — `ignored` — proxmox: ignored
- `sensor.hp_mini_memory_usage` — `6.32236099243164` — `ignored` — proxmox: ignored
- `sensor.hp_mini_memory_usage_percentage` — `85.2999682448022` — `ignored` — proxmox: ignored
- `sensor.hp_mini_status` — `online` — `important` — proxmox: important
- `sensor.hp_mini_uptime` — `52.3483333333333` — `diagnostic` — proxmox: diagnostic