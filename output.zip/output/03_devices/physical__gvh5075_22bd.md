# GVH5075_22BD

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `device_tracker.gvh5075_22bd` — `home` — `normal` — default
- `sensor.gvh5075_22bd_estimated_distance` — `400` — `normal` — default
- `sensor.gvh5075_22bd_power` — `unknown` — `normal` — default
- `sensor.gvh5075_22bd_signalstyrke` — `unknown` — `normal` — default
- `sensor.gvh5075_22bd_vendor` — `unknown` — `normal` — default