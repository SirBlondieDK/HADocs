# Google Home Badeværelse

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `badevaerelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `media_player.badevaerelse` — `off` — `important` — google_cast: important