# Node-RED

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant Community Apps`
- Model: `Home Assistant App`
- Software: `22.0.0`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.node_red_korer` — `unknown` — `normal` — default
- `sensor.node_red_cpu_procent` — `unknown` — `normal` — default
- `sensor.node_red_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.node_red_nyeste_version` — `unknown` — `normal` — default
- `sensor.node_red_version` — `unknown` — `normal` — default
- `switch.node_red` — `unknown` — `normal` — default
- `update.node_red_update` — `off` — `normal` — default