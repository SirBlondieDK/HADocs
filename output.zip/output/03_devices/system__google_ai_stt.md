# Google AI STT

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-lite`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `stt.google_ai_stt` — `unknown` — `normal` — default