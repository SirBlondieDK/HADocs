# Storage (local-lvm)

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Storage`
- Software: ``
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.storage_local_lvm_storage_active` — `on` — `normal` — default
- `binary_sensor.storage_local_lvm_storage_enabled` — `on` — `normal` — default
- `binary_sensor.storage_local_lvm_storage_shared` — `off` — `normal` — default
- `sensor.storage_local_lvm_available_storage` — `50.3999039065093` — `normal` — default
- `sensor.storage_local_lvm_storage_usage_percentage` — `64.4` — `normal` — default
- `sensor.storage_local_lvm_total_storage` — `141.65234375` — `normal` — default
- `sensor.storage_local_lvm_used_storage` — `91.2524398434907` — `normal` — default