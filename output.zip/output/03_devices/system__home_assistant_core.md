# Home Assistant Core

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Core`
- Software: `2026.7.1`
- Hardware: ``
- Entity count: `3`

## Entities

- `sensor.home_assistant_core_cpu_percent` — `unknown` — `normal` — default
- `sensor.home_assistant_core_memory_percent` — `unknown` — `normal` — default
- `update.home_assistant_core_update` — `off` — `normal` — default