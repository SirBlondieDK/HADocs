# OpenAI AI Task

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini`
- Software: ``
- Hardware: ``
- Entity count: `1`

## Entities

- `ai_task.openai_ai_task` — `unknown` — `normal` — default