# Tapo: Cameras Control

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `JurajNyiri`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.tapo_cameras_control_pre_release` — `unknown` — `normal` — default
- `update.tapo_cameras_control_update` — `off` — `normal` — default