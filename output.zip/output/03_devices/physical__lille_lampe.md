# Lille Lampe

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Software: `1.3.6`
- Hardware: `0`
- Entity count: `7`

## Entities

- `light.lille_lampe` — `off` — `important` — zigbee2mqtt: important
- `select.lille_lampe_color_power_on_behavior` — `unknown` — `normal` — default
- `select.lille_lampe_effect` — `unknown` — `normal` — default
- `select.lille_lampe_power_on_behavior` — `on` — `normal` — default
- `sensor.0xe8ca50de54d40000_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xe8ca50de54d40000_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.lille_lampe_do_not_disturb` — `off` — `important` — zigbee2mqtt: important