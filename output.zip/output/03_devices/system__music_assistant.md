# Music Assistant

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Music Assistant`
- Model: `Home Assistant App`
- Software: `2.9.5`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.music_assistant_server_korer` — `unknown` — `normal` — default
- `sensor.music_assistant_server_cpu_procent` — `unknown` — `normal` — default
- `sensor.music_assistant_server_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.music_assistant_server_nyeste_version` — `unknown` — `normal` — default
- `sensor.music_assistant_server_version` — `unknown` — `normal` — default
- `switch.music_assistant_server` — `unknown` — `normal` — default
- `update.music_assistant_server_update` — `off` — `normal` — default