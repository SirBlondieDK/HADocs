# Spillemaskine

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `Tuya`
- Model: `SHP-102 - Smart Power Plug`
- Software: ``
- Hardware: ``
- Entity count: `6`

## Entities

- `select.spillemaskine_power_on_behavior` — `last` — `normal` — default
- `sensor.spillemaskine_current` — `unknown` — `normal` — default
- `sensor.spillemaskine_power` — `unknown` — `normal` — default
- `sensor.spillemaskine_total_energy` — `0` — `normal` — default
- `sensor.spillemaskine_voltage` — `unknown` — `normal` — default
- `switch.spillemaskine_socket_1` — `off` — `normal` — default