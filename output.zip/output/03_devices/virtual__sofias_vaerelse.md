# Sofias værelse

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `sofia_s_vaerelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.sofias_vaerelse_favorite_current_song` — `unknown` — `normal` — default
- `media_player.sofias_vaerelse_2` — `idle` — `normal` — default