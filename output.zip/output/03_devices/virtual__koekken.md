# Køkken

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `kokken`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.kokken_favorite_current_song` — `unknown` — `normal` — default
- `media_player.kokken_2` — `idle` — `normal` — default