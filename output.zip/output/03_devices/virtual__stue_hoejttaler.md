# stue højttaler

Generated: 2026-07-05 01:49:34

- Classification: `virtual`
- Area ID: `stue`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `button.stue_hojttaler_favorite_current_song` — `unknown` — `normal` — default
- `media_player.stue_hojttaler_2` — `idle` — `normal` — default