# Aula

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `scaarup`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.aula_pre_release` — `unknown` — `normal` — default
- `update.aula_update` — `off` — `normal` — default