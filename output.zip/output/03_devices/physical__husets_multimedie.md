# husets Multimedie 

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: `Jellyfin`
- Model: ``
- Software: `10.11.11`
- Hardware: ``
- Entity count: `1`

## Entities

- `sensor.husets_multimedie_active_clients` — `0` — `normal` — default