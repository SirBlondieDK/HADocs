# Silicon Labs Multiprotocol

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Software: `2.4.5`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.silicon_labs_multiprotocol_korer` — `unknown` — `normal` — default
- `sensor.silicon_labs_multiprotocol_cpu_procent` — `unknown` — `normal` — default
- `sensor.silicon_labs_multiprotocol_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.silicon_labs_multiprotocol_nyeste_version` — `unknown` — `normal` — default
- `sensor.silicon_labs_multiprotocol_version` — `unknown` — `normal` — default
- `switch.silicon_labs_multiprotocol` — `unknown` — `normal` — default
- `update.silicon_labs_multiprotocol_update` — `off` — `normal` — default