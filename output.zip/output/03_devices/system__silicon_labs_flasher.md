# Silicon Labs Flasher

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Software: `0.5.0`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.silicon_labs_flasher_korer` — `unknown` — `normal` — default
- `sensor.silicon_labs_flasher_cpu_procent` — `unknown` — `normal` — default
- `sensor.silicon_labs_flasher_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.silicon_labs_flasher_nyeste_version` — `unknown` — `normal` — default
- `sensor.silicon_labs_flasher_version` — `unknown` — `normal` — default
- `switch.silicon_labs_flasher` — `unknown` — `normal` — default
- `update.silicon_labs_flasher_update` — `off` — `normal` — default