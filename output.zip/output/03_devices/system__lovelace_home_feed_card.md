# Lovelace Home Feed Card

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `gadgetchnnel`
- Model: `plugin`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.lovelace_home_feed_card_pre_release` — `unknown` — `normal` — default
- `update.lovelace_home_feed_card_update` — `off` — `normal` — default