# S2eb7335ec69640c3C 94BC

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `_uden_område`
- Manufacturer: ``
- Model: ``
- Software: ``
- Hardware: ``
- Entity count: `5`

## Entities

- `device_tracker.s2eb7335ec69640c3c_94bc` — `unavailable` — `normal` — default
- `sensor.s2eb7335ec69640c3c_94bc_estimated_distance` — `unavailable` — `normal` — default
- `sensor.s2eb7335ec69640c3c_94bc_power` — `unknown` — `normal` — default
- `sensor.s2eb7335ec69640c3c_94bc_signalstyrke` — `unknown` — `normal` — default
- `sensor.s2eb7335ec69640c3c_94bc_vendor` — `unknown` — `normal` — default