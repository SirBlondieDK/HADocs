# Temp stue

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `stue`
- Manufacturer: `SONOFF`
- Model: `Temperature and humidity sensor with screen`
- Software: `2.3.0`
- Hardware: `0`
- Entity count: `13`

## Entities

- `number.temp_stue_comfort_humidity_max` — `unknown` — `normal` — default
- `number.temp_stue_comfort_humidity_min` — `unknown` — `normal` — default
- `number.temp_stue_comfort_temperature_max` — `unknown` — `normal` — default
- `number.temp_stue_comfort_temperature_min` — `unknown` — `normal` — default
- `number.temp_stue_humidity_calibration` — `unknown` — `normal` — default
- `number.temp_stue_temperature_calibration` — `unknown` — `normal` — default
- `select.temp_stue_temperature_units` — `unknown` — `normal` — default
- `sensor.0x0cae5ffffed10fd2_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0x0cae5ffffed10fd2_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.temp_stue_battery` — `100` — `important` — zigbee2mqtt: important
- `sensor.temp_stue_humidity` — `56.6` — `normal` — default
- `sensor.temp_stue_temperature` — `23.4` — `normal` — default
- `update.temp_stue` — `off` — `ignored` — zigbee2mqtt: ignored