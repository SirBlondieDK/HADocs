# Home-Assistant-Matter-Hub

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `Addons by riddix`
- Model: `Home Assistant App`
- Software: `2.0.48`
- Hardware: ``
- Entity count: `7`

## Entities

- `binary_sensor.home_assistant_matter_hub_korer` — `unknown` — `normal` — default
- `sensor.home_assistant_matter_hub_cpu_procent` — `unknown` — `normal` — default
- `sensor.home_assistant_matter_hub_hukommelsesprocent` — `unknown` — `normal` — default
- `sensor.home_assistant_matter_hub_nyeste_version` — `unknown` — `normal` — default
- `sensor.home_assistant_matter_hub_version` — `unknown` — `normal` — default
- `switch.home_assistant_matter_hub` — `unknown` — `normal` — default
- `update.home_assistant_matter_hub_opdatering` — `off` — `normal` — default