# TP-Link Deco

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `_uden_område`
- Manufacturer: `amosyuen`
- Model: `integration`
- Software: ``
- Hardware: ``
- Entity count: `2`

## Entities

- `switch.tp_link_deco_pre_release` — `unknown` — `normal` — default
- `update.tp_link_deco_update` — `off` — `normal` — default