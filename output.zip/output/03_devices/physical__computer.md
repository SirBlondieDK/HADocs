# Computer

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `computer_hjorne`
- Manufacturer: `Tuya`
- Model: `SHP-102 - Smart Power Plug`
- Software: ``
- Hardware: ``
- Entity count: `6`

## Entities

- `select.pejs_power_on_behavior` — `last` — `normal` — default
- `sensor.pejs_current` — `unknown` — `normal` — default
- `sensor.pejs_power` — `unknown` — `normal` — default
- `sensor.pejs_total_energy` — `1.107` — `normal` — default
- `sensor.pejs_voltage` — `unknown` — `normal` — default
- `switch.pejs_socket_1` — `on` — `normal` — default