# nextcloud

Generated: 2026-07-05 01:49:34

- Classification: `system`
- Area ID: `server_rum`
- Manufacturer: ``
- Model: `Container`
- Software: ``
- Hardware: ``
- Entity count: `16`

## Entities

- `binary_sensor.nextcloud_status` — `on` — `important` — proxmox: important
- `button.nextcloud_create_snapshot` — `unknown` — `ignored` — proxmox: ignored
- `button.nextcloud_genstart` — `unknown` — `ignored` — proxmox: ignored
- `button.nextcloud_start` — `unknown` — `ignored` — proxmox: ignored
- `button.nextcloud_stop` — `unknown` — `ignored` — proxmox: ignored
- `sensor.nextcloud_cpu_usage` — `0.925707268065165` — `ignored` — proxmox: ignored
- `sensor.nextcloud_disk_usage` — `17.7851791381836` — `ignored` — proxmox: ignored
- `sensor.nextcloud_max_cpu` — `2` — `ignored` — proxmox: ignored
- `sensor.nextcloud_max_disk_usage` — `19.5181427001953` — `ignored` — proxmox: ignored
- `sensor.nextcloud_max_memory_usage` — `2.0` — `ignored` — proxmox: ignored
- `sensor.nextcloud_memory_usage` — `0.141387939453125` — `ignored` — proxmox: ignored
- `sensor.nextcloud_memory_usage_percentage` — `7.06939697265625` — `ignored` — proxmox: ignored
- `sensor.nextcloud_network_input` — `0.31948977150023` — `normal` — default
- `sensor.nextcloud_network_output` — `0.0226710569113493` — `normal` — default
- `sensor.nextcloud_status` — `running` — `important` — proxmox: important
- `sensor.nextcloud_uptime` — `51.6683333333333` — `diagnostic` — proxmox: diagnostic