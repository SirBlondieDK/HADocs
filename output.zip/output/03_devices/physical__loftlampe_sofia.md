# Loftlampe Sofia

Generated: 2026-07-05 01:49:34

- Classification: `physical`
- Area ID: `sofia_s_vaerelse`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Software: `z.1.0`
- Hardware: `0`
- Entity count: `6`

## Entities

- `light.loftlampe_sofia` — `on` — `important` — zigbee2mqtt: important
- `select.0xa4c138312c122baa_effect` — `unknown` — `normal` — default
- `select.loftlampe_sofia_color_power_on_behavior` — `unknown` — `normal` — default
- `sensor.0xa4c138312c122baa_last_seen` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `sensor.0xa4c138312c122baa_linkquality` — `unknown` — `ignored` — zigbee2mqtt: ignored
- `switch.loftlampe_sofia_do_not_disturb` — `off` — `important` — zigbee2mqtt: important