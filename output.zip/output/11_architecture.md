# 11 Architecture

Generated: 2026-07-05 01:49:34

```text
Home Assistant API
      │
      ▼
HADocs Core Model
      │
      ├── Rules Engine
      ├── Areas
      ├── Physical Devices
      ├── Virtual Devices
      ├── System Devices
      ├── Entities
      ├── Integrations
      └── Health Model
      │
      ▼
Reports / CSV / Future HTML / Future Relationship Engine
```