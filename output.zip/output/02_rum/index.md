# 02 Areas

Generated: 2026-07-05 00:57:13

- [Badeværelse](badevaerelse.md) — 47 entities
- [Bryggers](bryggers.md) — 9 entities
- [Carport](carport.md) — 51 entities
- [Computer hjørne](computer_hjoerne.md) — 10 entities
- [De små's værelse](de_smaa_s_vaerelse.md) — 44 entities
- [Gang](gang.md) — 6 entities
- [Have](have.md) — 46 entities
- [Hoveddør](hoveddoer.md) — 82 entities
- [Køkken](koekken.md) — 33 entities
- [Loft](loft.md) — 8 entities
- [Sebastian's værelse](sebastian_s_vaerelse.md) — 12 entities
- [Server rum](server_rum.md) — 244 entities
- [Sofia's værelse](sofia_s_vaerelse.md) — 19 entities
- [Soveværelse](sovevaerelse.md) — 90 entities
- [Stue](stue.md) — 127 entities
- [Uden område](uden_omraade.md) — 737 entities
- [Udendørs](udendoers.md) — 14 entities
- [terrasse](terrasse.md) — 41 entities