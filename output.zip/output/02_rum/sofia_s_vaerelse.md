# Sofia's værelse

Generated: 2026-07-05 00:57:13

## automation

- **Kontakt Sofias værelse** — `automation.kontakt_sofias_vaerelse` — `on`

## button

- **Sofias værelse Favorite current song** — `button.sofias_vaerelse_favorite_current_song` — `unknown`

## calendar

- **Skoleskema Sofia Dinesen Philip Christiansen** — `calendar.skoleskema_sofia_dinesen_philip_christiansen` — `off`

## light

- **Loftlampe Sofia** — `light.loftlampe_sofia` — `on`

## media_player

- **Sofias værelse** — `media_player.sofias_vaerelse` — `off`
- **Sofias værelse** — `media_player.sofias_vaerelse_2` — `idle`

## select

- **select.0xa4c138312c122baa_effect** — `select.0xa4c138312c122baa_effect` — `unknown`
- **Loftlampe Sofia Color power on behavior** — `select.loftlampe_sofia_color_power_on_behavior` — `unknown`

## sensor

- **sensor.0xa4c138312c122baa_last_seen** — `sensor.0xa4c138312c122baa_last_seen` — `unknown`
- **sensor.0xa4c138312c122baa_linkquality** — `sensor.0xa4c138312c122baa_linkquality` — `unknown`
- **Hærvejens Skole og Dagtilbud Sofia** — `sensor.baekke_skole_sofia` — `Ikke kommet`
- **H5075 22BD Battery** — `sensor.h5075_22bd_battery` — `100`
- **H5075 22BD Humidity** — `sensor.h5075_22bd_humidity` — `58.8`
- **sensor.h5075_22bd_signal_strength** — `sensor.h5075_22bd_signal_strength` — `unknown`
- **H5075 22BD Temperature** — `sensor.h5075_22bd_temperature` — `23.9`
- **Kontakt sofia Action** — `sensor.kontakt_sofia_action` — `unknown`
- **sensor.kontakt_sofia_last_seen** — `sensor.kontakt_sofia_last_seen` — `unknown`
- **sensor.kontakt_sofia_linkquality** — `sensor.kontakt_sofia_linkquality` — `unknown`

## switch

- **Loftlampe Sofia Do not disturb** — `switch.loftlampe_sofia_do_not_disturb` — `off`
