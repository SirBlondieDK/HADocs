# Carport

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Carport All occupancy** — `binary_sensor.carport_all_occupancy` — `off`
- **Carport Car occupancy** — `binary_sensor.carport_car_occupancy` — `off`
- **Carport Dog occupancy** — `binary_sensor.carport_dog_occupancy` — `off`
- **Carport Motion** — `binary_sensor.carport_motion` — `off`
- **Carport Person occupancy** — `binary_sensor.carport_person_occupancy` — `off`

## camera

- **Carport** — `camera.carport` — `recording`

## image

- **Carport Car** — `image.carport_car` — `2026-07-04T22:27:38.966380`
- **Carport Dog** — `image.carport_dog` — `2026-07-04T22:27:38.969634`
- **Carport Person** — `image.carport_person` — `2026-07-04T22:27:38.964073`

## light

- **Spot Hoveddør 1** — `light.spot_hoveddor_1` — `unavailable`
- **Spot Hoveddør 2** — `light.spot_hoveddor_2` — `unavailable`
- **Spot Hovededør** — `light.spot_hovededor` — `unavailable`

## number

- **number.carport_contour_area** — `number.carport_contour_area` — `unknown`
- **number.carport_threshold** — `number.carport_threshold` — `unknown`

## select

- **select.0xe8ca50ddfe570000_effect** — `select.0xe8ca50ddfe570000_effect` — `unknown`
- **select.0xe8ca50de33300000_effect** — `select.0xe8ca50de33300000_effect` — `unknown`
- **Spot Hoveddør 1 Color power on behavior** — `select.spot_hoveddor_1_color_power_on_behavior` — `unavailable`
- **Spot Hoveddør 1 Power-on behavior** — `select.spot_hoveddor_1_power_on_behavior` — `unavailable`
- **Spot Hoveddør 2 Color power on behavior** — `select.spot_hoveddor_2_color_power_on_behavior` — `unavailable`
- **Spot Hoveddør 2 Power-on behavior** — `select.spot_hoveddor_2_power_on_behavior` — `unavailable`

## sensor

- **sensor.0xe8ca50ddfe570000_last_seen** — `sensor.0xe8ca50ddfe570000_last_seen` — `unknown`
- **sensor.0xe8ca50ddfe570000_linkquality** — `sensor.0xe8ca50ddfe570000_linkquality` — `unknown`
- **sensor.0xe8ca50de33300000_last_seen** — `sensor.0xe8ca50de33300000_last_seen` — `unknown`
- **sensor.0xe8ca50de33300000_linkquality** — `sensor.0xe8ca50de33300000_linkquality` — `unknown`
- **Carport All Active Count** — `sensor.carport_all_active_count` — `0`
- **Carport All count** — `sensor.carport_all_count` — `0`
- **sensor.carport_camera_fps** — `sensor.carport_camera_fps` — `unknown`
- **sensor.carport_capture_cpu_usage** — `sensor.carport_capture_cpu_usage` — `unknown`
- **Carport Car Active Count** — `sensor.carport_car_active_count` — `0`
- **Carport Car count** — `sensor.carport_car_count` — `0`
- **sensor.carport_detect_cpu_usage** — `sensor.carport_detect_cpu_usage` — `unknown`
- **sensor.carport_detection_fps** — `sensor.carport_detection_fps` — `unknown`
- **Carport Dog Active Count** — `sensor.carport_dog_active_count` — `0`
- **Carport Dog count** — `sensor.carport_dog_count` — `0`
- **sensor.carport_ffmpeg_cpu_usage** — `sensor.carport_ffmpeg_cpu_usage` — `unknown`
- **Carport Person Active Count** — `sensor.carport_person_active_count` — `0`
- **Carport Person count** — `sensor.carport_person_count` — `0`
- **sensor.carport_process_fps** — `sensor.carport_process_fps` — `unknown`
- **Carport Review Status** — `sensor.carport_review_status` — `unknown`
- **sensor.carport_skipped_fps** — `sensor.carport_skipped_fps` — `unknown`

## switch

- **Carport Detect** — `switch.carport_detect` — `on`
- **switch.carport_improve_contrast** — `switch.carport_improve_contrast` — `unknown`
- **Carport Motion** — `switch.carport_motion` — `on`
- **switch.carport_object_descriptions** — `switch.carport_object_descriptions` — `unknown`
- **Carport Recordings** — `switch.carport_recordings` — `on`
- **Carport Review Alerts** — `switch.carport_review_alerts` — `on`
- **switch.carport_review_descriptions** — `switch.carport_review_descriptions` — `unknown`
- **Carport Review Detections** — `switch.carport_review_detections` — `on`
- **Carport Snapshots** — `switch.carport_snapshots` — `on`
- **Spot Hoveddør 1 Do not disturb** — `switch.spot_hoveddor_1_do_not_disturb` — `unavailable`
- **Spot Hoveddør 2 Do not disturb** — `switch.spot_hoveddor_2_do_not_disturb` — `unavailable`
