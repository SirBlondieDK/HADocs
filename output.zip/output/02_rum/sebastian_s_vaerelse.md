# Sebastian's værelse

Generated: 2026-07-05 00:57:13

## calendar

- **Skoleskema Sebastian Christiansen** — `calendar.skoleskema_sebastian_christiansen` — `off`

## light

- **Loftlampe Sebastian** — `light.loftlampe_sebastian` — `off`

## media_player

- **Sebastian** — `media_player.sebastian` — `off`

## select

- **select.0xa4c1383c67fc69da_effect** — `select.0xa4c1383c67fc69da_effect` — `unknown`
- **Loftlampe Sebastian Color power on behavior** — `select.loftlampe_sebastian_color_power_on_behavior` — `unknown`

## sensor

- **sensor.0x0000000001714ade_last_seen** — `sensor.0x0000000001714ade_last_seen` — `unknown`
- **sensor.0x0000000001714ade_linkquality** — `sensor.0x0000000001714ade_linkquality` — `unknown`
- **sensor.0xa4c1383c67fc69da_last_seen** — `sensor.0xa4c1383c67fc69da_last_seen` — `unknown`
- **sensor.0xa4c1383c67fc69da_linkquality** — `sensor.0xa4c1383c67fc69da_linkquality` — `unknown`
- **Hærvejens Skole og Dagtilbud Sebastian** — `sensor.baekke_skole_sebastian` — `Ikke kommet`
- **Kontakt Sebastian Action** — `sensor.kontakt_sebastian_action` — `unknown`

## switch

- **Loftlampe Sebastian Do not disturb** — `switch.loftlampe_sebastian_do_not_disturb` — `off`
