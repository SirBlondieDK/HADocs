# Stue

Generated: 2026-07-05 00:57:13

## automation

- **Kontakt Rumdeler** — `automation.kontakt_ved_de_smas_vaerelse` — `on`

## binary_sensor

- **binary_sensor.diskokugle_cloud** — `binary_sensor.diskokugle_cloud` — `unknown`
- **binary_sensor.diskokugle_input** — `binary_sensor.diskokugle_input` — `unknown`
- **Stue Firmware** — `binary_sensor.wled_firmware` — `unavailable`

## button

- **Diskokugle Genstart** — `button.diskokugle_reboot` — `unknown`
- **Stue Favorite current song** — `button.stue_favorite_current_song` — `unknown`
- **stue højttaler Favorite current song** — `button.stue_hojttaler_favorite_current_song` — `unknown`
- **Stue Genstart** — `button.wled_genstart` — `unavailable`

## device_tracker

- **Stue wledmic** — `device_tracker.kitchen_deco_wledmic` — `not_home`

## input_button

- **PC** — `input_button.pc` — `2026-06-30T17:20:33.296932+00:00`

## light

- **Lille Lampe** — `light.lille_lampe` — `off`
- **Loftlampe Stue** — `light.loftlampe_stue` — `off`
- **Lampe Sofabord** — `light.wiz_rgbw_tunable_44c896` — `off`
- **Bordlampe** — `light.wiz_rgbww_tunable_0123ac` — `off`
- **Led Stue** — `light.wled` — `unavailable`
- **Stue Main** — `light.wled_main_2` — `unavailable`
- **Stue Segment 1** — `light.wled_segment_1_2` — `unavailable`
- **Stue Segment 2** — `light.wled_segment_2_2` — `unavailable`
- **Stue Segment 3** — `light.wled_segment_3_2` — `unavailable`
- **Stue Segment 4** — `light.wled_segment_4_2` — `unavailable`
- **Stue Segment 5** — `light.wled_segment_5_2` — `unavailable`
- **Stue Segment 6** — `light.wled_segment_6_2` — `unavailable`
- **Stue Segment 7** — `light.wled_segment_7_2` — `unavailable`

## media_player

- **Fjernsyn Stue** — `media_player.fjernsyn_stue` — `off`
- **Stue** — `media_player.stue` — `off`
- **Stue** — `media_player.stue_2` — `idle`
- **stue højttaler** — `media_player.stue_hojttaler` — `off`
- **stue højttaler** — `media_player.stue_hojttaler_2` — `idle`

## number

- **Temp stue Comfort humidity max** — `number.temp_stue_comfort_humidity_max` — `unknown`
- **Temp stue Comfort humidity min** — `number.temp_stue_comfort_humidity_min` — `unknown`
- **Temp stue Comfort temperature max** — `number.temp_stue_comfort_temperature_max` — `unknown`
- **Temp stue Comfort temperature min** — `number.temp_stue_comfort_temperature_min` — `unknown`
- **Temp stue Humidity calibration** — `number.temp_stue_humidity_calibration` — `unknown`
- **Temp stue Temperature calibration** — `number.temp_stue_temperature_calibration` — `unknown`
- **Lampe Sofabord Effect speed** — `number.wiz_rgbw_tunable_44c896_effect_speed` — `unavailable`
- **WiZ RGBWW Tunable 0123AC Effect speed** — `number.wiz_rgbww_tunable_0123ac_effect_speed` — `unavailable`
- **Stue Intensity** — `number.wled_intensity` — `unavailable`
- **Stue Segment 1 intensity** — `number.wled_segment_1_intensity_2` — `unavailable`
- **Stue Segment 1 speed** — `number.wled_segment_1_speed_2` — `unavailable`
- **Stue Segment 2 intensity** — `number.wled_segment_2_intensity_2` — `unavailable`
- **Stue Segment 2 speed** — `number.wled_segment_2_speed_2` — `unavailable`
- **Stue Segment 3 intensity** — `number.wled_segment_3_intensity_2` — `unavailable`
- **Stue Segment 3 speed** — `number.wled_segment_3_speed_2` — `unavailable`
- **Stue Segment 4 intensity** — `number.wled_segment_4_intensity_2` — `unavailable`
- **Stue Segment 4 speed** — `number.wled_segment_4_speed_2` — `unavailable`
- **Stue Segment 5 intensity** — `number.wled_segment_5_intensity_2` — `unavailable`
- **Stue Segment 5 speed** — `number.wled_segment_5_speed_2` — `unavailable`
- **Stue Segment 6 intensity** — `number.wled_segment_6_intensity_2` — `unavailable`
- **Stue Segment 6 speed** — `number.wled_segment_6_speed_2` — `unavailable`
- **Stue Segment 7 intensity** — `number.wled_segment_7_intensity_2` — `unavailable`
- **Stue Segment 7 speed** — `number.wled_segment_7_speed_2` — `unavailable`
- **Stue Speed** — `number.wled_speed` — `unavailable`

## select

- **select.0xa4c13862b3e83b4d_effect** — `select.0xa4c13862b3e83b4d_effect` — `unknown`
- **Lille Lampe Color power on behavior** — `select.lille_lampe_color_power_on_behavior` — `unknown`
- **select.lille_lampe_effect** — `select.lille_lampe_effect` — `unknown`
- **Lille Lampe Power-on behavior** — `select.lille_lampe_power_on_behavior` — `on`
- **Loftlampe Stue Color power on behavior** — `select.loftlampe_stue_color_power_on_behavior` — `unknown`
- **Spillemaskine Power-on behavior** — `select.spillemaskine_power_on_behavior` — `last`
- **Temp stue Temperature units** — `select.temp_stue_temperature_units` — `unknown`
- **Stue Color palette** — `select.wled_color_palette` — `unavailable`
- **Stue Live override** — `select.wled_live_override` — `unavailable`
- **Stue Playlist** — `select.wled_playlist` — `unavailable`
- **Stue Preset** — `select.wled_preset` — `unavailable`
- **Stue Segment 1 color palette** — `select.wled_segment_1_color_palette_2` — `unavailable`
- **Stue Segment 2 color palette** — `select.wled_segment_2_color_palette_2` — `unavailable`
- **Stue Segment 3 color palette** — `select.wled_segment_3_color_palette_2` — `unavailable`
- **Stue Segment 4 color palette** — `select.wled_segment_4_color_palette_2` — `unavailable`
- **Stue Segment 5 color palette** — `select.wled_segment_5_color_palette_2` — `unavailable`
- **Stue Segment 6 color palette** — `select.wled_segment_6_color_palette_2` — `unavailable`
- **Stue Segment 7 color palette** — `select.wled_segment_7_color_palette_2` — `unavailable`

## sensor

- **sensor.0x0cae5ffffed10fd2_last_seen** — `sensor.0x0cae5ffffed10fd2_last_seen` — `unknown`
- **sensor.0x0cae5ffffed10fd2_linkquality** — `sensor.0x0cae5ffffed10fd2_linkquality` — `unknown`
- **sensor.0xa4c13862b3e83b4d_last_seen** — `sensor.0xa4c13862b3e83b4d_last_seen` — `unknown`
- **sensor.0xa4c13862b3e83b4d_linkquality** — `sensor.0xa4c13862b3e83b4d_linkquality` — `unknown`
- **sensor.0xa4c138ab3197ecdf_last_seen** — `sensor.0xa4c138ab3197ecdf_last_seen` — `unknown`
- **sensor.0xa4c138ab3197ecdf_linkquality** — `sensor.0xa4c138ab3197ecdf_linkquality` — `unknown`
- **sensor.0xe8ca50de54d40000_last_seen** — `sensor.0xe8ca50de54d40000_last_seen` — `unknown`
- **sensor.0xe8ca50de54d40000_linkquality** — `sensor.0xe8ca50de54d40000_linkquality` — `unknown`
- **sensor.diskokugle_rssi** — `sensor.diskokugle_rssi` — `unknown`
- **sensor.diskokugle_uptime** — `sensor.diskokugle_uptime` — `unknown`
- **kontakt stue Action** — `sensor.kontakt_stue_action` — `unavailable`
- **sensor.kontakt_stue_last_seen** — `sensor.kontakt_stue_last_seen` — `unknown`
- **sensor.kontakt_stue_linkquality** — `sensor.kontakt_stue_linkquality` — `unknown`
- **sensor.spillemaskine_current** — `sensor.spillemaskine_current` — `unknown`
- **sensor.spillemaskine_power** — `sensor.spillemaskine_power` — `unknown`
- **Spillemaskine Total energy** — `sensor.spillemaskine_total_energy` — `0`
- **sensor.spillemaskine_voltage** — `sensor.spillemaskine_voltage` — `unknown`
- **Temp stue Batteri** — `sensor.temp_stue_battery` — `100`
- **Temp stue Luftfugtighed** — `sensor.temp_stue_humidity` — `56.6`
- **Temp stue Temperatur** — `sensor.temp_stue_temperature` — `23.2`
- **sensor.wiz_rgbw_tunable_44c896_signalstyrke** — `sensor.wiz_rgbw_tunable_44c896_signalstyrke` — `unknown`
- **Lampe Sofabord Effekt** — `sensor.wiz_rgbw_tunable_44c896_strom` — `unknown`
- **sensor.wiz_rgbww_tunable_0123ac_signalstyrke** — `sensor.wiz_rgbww_tunable_0123ac_signalstyrke` — `unknown`
- **WiZ RGBWW Tunable 0123AC Effekt** — `sensor.wiz_rgbww_tunable_0123ac_strom` — `unknown`
- **Stue Estimated current** — `sensor.wled_estimated_current` — `unavailable`
- **sensor.wled_free_memory** — `sensor.wled_free_memory` — `unknown`
- **Stue IP** — `sensor.wled_ip` — `unavailable`
- **Stue LED count** — `sensor.wled_led_count` — `unavailable`
- **Stue Max current** — `sensor.wled_max_current` — `unavailable`
- **sensor.wled_uptime** — `sensor.wled_uptime` — `unknown`
- **sensor.wled_wi_fi_bssid** — `sensor.wled_wi_fi_bssid` — `unknown`
- **sensor.wled_wi_fi_channel** — `sensor.wled_wi_fi_channel` — `unknown`
- **sensor.wled_wi_fi_rssi** — `sensor.wled_wi_fi_rssi` — `unknown`
- **sensor.wled_wi_fi_signal** — `sensor.wled_wi_fi_signal` — `unknown`

## switch

- **Diskokugle** — `switch.diskokugle` — `off`
- **Lille Lampe Do not disturb** — `switch.lille_lampe_do_not_disturb` — `off`
- **Loftlampe Stue Do not disturb** — `switch.loftlampe_stue_do_not_disturb` — `off`
- **Spillemaskine Socket 1** — `switch.spillemaskine_socket_1` — `off`
- **Stue Freeze** — `switch.stue_freeze` — `unavailable`
- **Lysende rose** — `switch.usb_kontakt_stue_1_center` — `off`
- **USB kontakt 1** — `switch.usb_kontakt_stue_1_left` — `off`
- **The Black Pearl** — `switch.usb_kontakt_stue_1_right` — `off`
- **Stue Nightlight** — `switch.wled_nightlight` — `unavailable`
- **Stue Reverse** — `switch.wled_reverse` — `unavailable`
- **Stue Segment 1 reverse** — `switch.wled_segment_1_reverse_2` — `unavailable`
- **Stue Segment 2 reverse** — `switch.wled_segment_2_reverse_2` — `unavailable`
- **Stue Segment 3 reverse** — `switch.wled_segment_3_reverse_2` — `unavailable`
- **Stue Segment 4 reverse** — `switch.wled_segment_4_reverse_2` — `unavailable`
- **Stue Segment 5 reverse** — `switch.wled_segment_5_reverse_2` — `unavailable`
- **Stue Segment 6 reverse** — `switch.wled_segment_6_reverse_2` — `unavailable`
- **Stue Segment 7 reverse** — `switch.wled_segment_7_reverse_2` — `unavailable`
- **Stue Sync receive** — `switch.wled_sync_receive` — `unavailable`
- **Stue Sync send** — `switch.wled_sync_send` — `unavailable`

## update

- **update.diskokugle_beta_firmware_update** — `update.diskokugle_beta_firmware_update` — `unknown`
- **update.diskokugle_firmware_update** — `update.diskokugle_firmware_update` — `unknown`
- **Temp stue** — `update.temp_stue` — `off`
- **Stue Firmware** — `update.wled_firmware` — `unavailable`
