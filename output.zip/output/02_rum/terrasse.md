# terrasse

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Terasse All occupancy** — `binary_sensor.terasse_all_occupancy` — `off`
- **Terasse Car occupancy** — `binary_sensor.terasse_car_occupancy` — `off`
- **Terasse Dog occupancy** — `binary_sensor.terasse_dog_occupancy` — `off`
- **Terasse Motion** — `binary_sensor.terasse_motion` — `off`
- **Terasse Person occupancy** — `binary_sensor.terasse_person_occupancy` — `off`

## camera

- **Terasse** — `camera.terasse` — `recording`

## image

- **Terasse Car** — `image.terasse_car` — `2026-07-04T22:27:38.965589`
- **Terasse Dog** — `image.terasse_dog` — `2026-07-04T22:27:38.966948`
- **Terasse Person** — `image.terasse_person` — `2026-07-04T22:27:38.962813`

## number

- **number.terasse_contour_area** — `number.terasse_contour_area` — `unknown`
- **number.terasse_threshold** — `number.terasse_threshold` — `unknown`

## sensor

- **sensor.pool_current** — `sensor.pool_current` — `unknown`
- **sensor.pool_power** — `sensor.pool_power` — `unknown`
- **Pool Total energy** — `sensor.pool_total_energy` — `unavailable`
- **sensor.pool_voltage** — `sensor.pool_voltage` — `unknown`
- **Terasse All Active Count** — `sensor.terasse_all_active_count` — `0`
- **Terasse All count** — `sensor.terasse_all_count` — `0`
- **sensor.terasse_camera_fps** — `sensor.terasse_camera_fps` — `unknown`
- **sensor.terasse_capture_cpu_usage** — `sensor.terasse_capture_cpu_usage` — `unknown`
- **Terasse Car Active Count** — `sensor.terasse_car_active_count` — `0`
- **Terasse Car count** — `sensor.terasse_car_count` — `0`
- **sensor.terasse_detect_cpu_usage** — `sensor.terasse_detect_cpu_usage` — `unknown`
- **sensor.terasse_detection_fps** — `sensor.terasse_detection_fps` — `unknown`
- **Terasse Dog Active Count** — `sensor.terasse_dog_active_count` — `0`
- **Terasse Dog count** — `sensor.terasse_dog_count` — `0`
- **sensor.terasse_ffmpeg_cpu_usage** — `sensor.terasse_ffmpeg_cpu_usage` — `unknown`
- **Terasse Person Active Count** — `sensor.terasse_person_active_count` — `0`
- **Terasse Person count** — `sensor.terasse_person_count` — `0`
- **sensor.terasse_process_fps** — `sensor.terasse_process_fps` — `unknown`
- **Terasse Review Status** — `sensor.terasse_review_status` — `unknown`
- **sensor.terasse_skipped_fps** — `sensor.terasse_skipped_fps` — `unknown`

## switch

- **Pool** — `switch.pool_socket_1` — `unavailable`
- **Terasse Detect** — `switch.terasse_detect` — `on`
- **switch.terasse_improve_contrast** — `switch.terasse_improve_contrast` — `unknown`
- **Terasse Motion** — `switch.terasse_motion` — `on`
- **switch.terasse_object_descriptions** — `switch.terasse_object_descriptions` — `unknown`
- **Terasse Recordings** — `switch.terasse_recordings` — `on`
- **Terasse Review Alerts** — `switch.terasse_review_alerts` — `on`
- **switch.terasse_review_descriptions** — `switch.terasse_review_descriptions` — `unknown`
- **Terasse Review Detections** — `switch.terasse_review_detections` — `on`
- **Terasse Snapshots** — `switch.terasse_snapshots` — `on`
