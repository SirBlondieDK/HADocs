# Loft

Generated: 2026-07-05 00:57:13

## binary_sensor

- **binary_sensor.shelly1_3494546ae397_cloud** — `binary_sensor.shelly1_3494546ae397_cloud` — `unknown`
- **binary_sensor.shelly1_3494546ae397_input** — `binary_sensor.shelly1_3494546ae397_input` — `unknown`

## button

- **Strøm til Led Genstart** — `button.shelly1_3494546ae397_reboot` — `unknown`

## sensor

- **sensor.shelly1_3494546ae397_rssi** — `sensor.shelly1_3494546ae397_rssi` — `unknown`
- **sensor.shelly1_3494546ae397_uptime** — `sensor.shelly1_3494546ae397_uptime` — `unknown`

## switch

- **Strøm til LED** — `switch.shelly1_3494546ae397` — `off`

## update

- **update.shelly1_3494546ae397_beta_firmware_update** — `update.shelly1_3494546ae397_beta_firmware_update` — `unknown`
- **update.shelly1_3494546ae397_firmware_update** — `update.shelly1_3494546ae397_firmware_update` — `unknown`
