# Computer hjørne

Generated: 2026-07-05 00:57:13

## select

- **Computer Power-on behavior** — `select.pejs_power_on_behavior` — `last`

## sensor

- **HP ENVY Inspire 7200 series** — `sensor.hp_envy_inspire_7200_series` — `idle`
- **HP ENVY Inspire 7200 series black cartridge** — `sensor.hp_envy_inspire_7200_series_black_cartridge` — `40`
- **HP ENVY Inspire 7200 series tri-color cartridge** — `sensor.hp_envy_inspire_7200_series_tri_color_cartridge` — `30`
- **sensor.hp_envy_inspire_7200_series_uptime** — `sensor.hp_envy_inspire_7200_series_uptime` — `unknown`
- **sensor.pejs_current** — `sensor.pejs_current` — `unknown`
- **sensor.pejs_power** — `sensor.pejs_power` — `unknown`
- **Computer Total energy** — `sensor.pejs_total_energy` — `0.807`
- **sensor.pejs_voltage** — `sensor.pejs_voltage` — `unknown`

## switch

- **Strøm til PC** — `switch.pejs_socket_1` — `on`
