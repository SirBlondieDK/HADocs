# Køkken

Generated: 2026-07-05 00:57:13

## automation

- **Kontakt køkken** — `automation.kontakt_kokken` — `on`

## binary_sensor

- **Kaffe hjørnet Cloud connection** — `binary_sensor.kaffe_hjornet_cloud_connection` — `on`

## button

- **button.kaffe_hjornet_genstart** — `button.kaffe_hjornet_genstart` — `unknown`
- **Køkken Favorite current song** — `button.kokken_favorite_current_song` — `unknown`

## light

- **Lampe spisebord** — `light.lampe_spisebord` — `on`
- **Loftlampe Køkken** — `light.loftlampe_kokken` — `on`
- **Spot Køkken** — `light.spot_kokken` — `on`

## media_player

- **Køkken** — `media_player.kokken` — `off`
- **Køkken** — `media_player.kokken_2` — `idle`

## number

- **Kaffe hjørnet Turn off in** — `number.kaffe_hjornet_turn_off_in` — `120`

## select

- **select.0xa4c138660fe2058a_effect** — `select.0xa4c138660fe2058a_effect` — `unknown`
- **select.0xa4c138b4051e6603_effect** — `select.0xa4c138b4051e6603_effect` — `unknown`
- **Lampe spisebord Color power on behavior** — `select.lampe_spisebord_color_power_on_behavior` — `unknown`
- **Loftlampe Køkken Color power on behavior** — `select.loftlampe_kokken_color_power_on_behavior` — `unknown`

## sensor

- **sensor.0xa4c138660fe2058a_last_seen** — `sensor.0xa4c138660fe2058a_last_seen` — `unknown`
- **sensor.0xa4c138660fe2058a_linkquality** — `sensor.0xa4c138660fe2058a_linkquality` — `unknown`
- **sensor.0xa4c138b4051e6603_last_seen** — `sensor.0xa4c138b4051e6603_last_seen` — `unknown`
- **sensor.0xa4c138b4051e6603_linkquality** — `sensor.0xa4c138b4051e6603_linkquality` — `unknown`
- **Kaffe hjørnet Auto-off at** — `sensor.kaffe_hjornet_auto_off_at` — `unknown`
- **sensor.kaffe_hjornet_device_time** — `sensor.kaffe_hjornet_device_time` — `unknown`
- **sensor.kaffe_hjornet_on_since** — `sensor.kaffe_hjornet_on_since` — `unknown`
- **Kaffe hjørnet Signal level** — `sensor.kaffe_hjornet_signal_level` — `2`
- **sensor.kaffe_hjornet_signal_strength** — `sensor.kaffe_hjornet_signal_strength` — `unknown`
- **sensor.kaffe_hjornet_ssid** — `sensor.kaffe_hjornet_ssid` — `unknown`
- **Kontakt Køkken Action** — `sensor.kontakt_kokken_action` — `unknown`
- **sensor.kontakt_kokken_last_seen** — `sensor.kontakt_kokken_last_seen` — `unknown`
- **sensor.kontakt_kokken_linkquality** — `sensor.kontakt_kokken_linkquality` — `unknown`

## switch

- **Kaffe hjørnet** — `switch.kaffe_hjornet` — `on`
- **Kaffe hjørnet Auto-off enabled** — `switch.kaffe_hjornet_auto_off_enabled` — `off`
- **Kaffe hjørnet Auto-update enabled** — `switch.kaffe_hjornet_auto_update_enabled` — `on`
- **Kaffe hjørnet LED** — `switch.kaffe_hjornet_led` — `on`
- **Lampe spisebord Do not disturb** — `switch.lampe_spisebord_do_not_disturb` — `off`
- **Loftlampe Køkken Do not disturb** — `switch.loftlampe_kokken_do_not_disturb` — `off`
