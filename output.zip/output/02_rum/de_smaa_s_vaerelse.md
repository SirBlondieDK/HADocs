# De små's værelse

Generated: 2026-07-05 00:57:13

## automation

- **kontakt de smås værelse** — `automation.kontakt_de_smas_vaerelse` — `on`

## binary_sensor

- **binary_sensor.wled_firmware_3** — `binary_sensor.wled_firmware_3` — `unknown`

## button

- **De smås værelse Favorite current song** — `button.de_smas_vaerelse_favorite_current_song` — `unknown`
- **WLED Genstart** — `button.wled_genstart_3` — `unavailable`

## calendar

- **Skoleskema Sesilie Dinesen Philip Christiansen** — `calendar.skoleskema_sesilie_dinesen_philip_christiansen` — `off`
- **Skoleskema Silke Dinesen Philip Christiansen** — `calendar.skoleskema_silke_dinesen_philip_christiansen_2` — `off`

## device_tracker

- **WLED Ledss** — `device_tracker.kitchen_deco_ledss` — `not_home`

## light

- **stjerne Himmel** — `light.kabelskinne_usb_1` — `off`
- **Lampe ved de små** — `light.lampe_ved_de_sma` — `off`
- **Led ved de små** — `light.wled_3` — `unavailable`

## media_player

- **De smås værelse** — `media_player.de_smas_vaerelse` — `off`
- **De smås værelse** — `media_player.de_smas_vaerelse_2` — `idle`

## number

- **WLED Intensity** — `number.wled_intensity_3` — `unavailable`
- **WLED Speed** — `number.wled_speed_3` — `unavailable`

## select

- **WLED Color palette** — `select.wled_color_palette_3` — `unavailable`
- **WLED Live override** — `select.wled_live_override_3` — `unavailable`
- **WLED Playlist** — `select.wled_playlist_3` — `unavailable`
- **WLED Preset** — `select.wled_preset_3` — `unavailable`

## sensor

- **Hærvejens Skole og Dagtilbud Sesilie** — `sensor.baekke_skole_sesilie` — `Ikke kommet`
- **Hærvejens Skole og Dagtilbud Silke** — `sensor.baekke_skole_silke` — `n/a`
- **Kontakt de smås værelse Action** — `sensor.kontakt_de_smas_vaerelse_action` — `unknown`
- **sensor.kontakt_de_smas_vaerelse_last_seen** — `sensor.kontakt_de_smas_vaerelse_last_seen` — `unknown`
- **sensor.kontakt_de_smas_vaerelse_linkquality** — `sensor.kontakt_de_smas_vaerelse_linkquality` — `unknown`
- **WLED Estimated current** — `sensor.wled_estimated_current_3` — `unavailable`
- **sensor.wled_free_memory_3** — `sensor.wled_free_memory_3` — `unknown`
- **WLED IP** — `sensor.wled_ip_3` — `unavailable`
- **WLED LED count** — `sensor.wled_led_count_3` — `unavailable`
- **WLED Max current** — `sensor.wled_max_current_3` — `unavailable`
- **sensor.wled_uptime_3** — `sensor.wled_uptime_3` — `unknown`
- **sensor.wled_wi_fi_bssid_3** — `sensor.wled_wi_fi_bssid_3` — `unknown`
- **sensor.wled_wi_fi_channel_3** — `sensor.wled_wi_fi_channel_3` — `unknown`
- **sensor.wled_wi_fi_rssi_3** — `sensor.wled_wi_fi_rssi_3` — `unknown`
- **sensor.wled_wi_fi_signal_3** — `sensor.wled_wi_fi_signal_3` — `unknown`

## switch

- **Kabelskinne** — `switch.deltaco_sh_p03usb2_socket` — `unknown`
- **Disko kugle** — `switch.deltaco_sh_p03usb2_socket_1` — `unknown`
- **TV** — `switch.deltaco_sh_p03usb2_socket_2` — `off`
- **CromeCast** — `switch.deltaco_sh_p03usb2_socket_3` — `off`
- **stjerne Himmel** — `switch.deltaco_sh_p03usb2_usb_1` — `off`
- **WLED Freeze** — `switch.wled_freeze` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_3` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_3` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_3` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_3` — `unavailable`

## update

- **WLED Firmware** — `update.wled_firmware_3` — `unavailable`
