# Udendørs

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Foran All occupancy** — `binary_sensor.foran_all_occupancy` — `off`
- **Foran Person occupancy** — `binary_sensor.foran_person_occupancy` — `off`
- **binary_sensor.shelly1_3494546a3372_cloud** — `binary_sensor.shelly1_3494546a3372_cloud` — `unknown`
- **binary_sensor.shelly1_3494546a3372_input** — `binary_sensor.shelly1_3494546a3372_input` — `unknown`

## button

- **Facadelys Genstart** — `button.facadelys_reboot` — `unknown`

## sensor

- **Foran All Active Count** — `sensor.foran_all_active_count` — `0`
- **Foran All count** — `sensor.foran_all_count` — `0`
- **Foran Person Active Count** — `sensor.foran_person_active_count` — `0`
- **Foran Person count** — `sensor.foran_person_count` — `0`
- **sensor.shelly1_3494546a3372_rssi** — `sensor.shelly1_3494546a3372_rssi` — `unknown`
- **sensor.shelly1_3494546a3372_uptime** — `sensor.shelly1_3494546a3372_uptime` — `unknown`

## switch

- **Facadelys** — `switch.facadelys` — `off`

## update

- **update.shelly1_3494546a3372_beta_firmware** — `update.shelly1_3494546a3372_beta_firmware` — `unknown`
- **update.shelly1_3494546a3372_firmware** — `update.shelly1_3494546a3372_firmware` — `unknown`
