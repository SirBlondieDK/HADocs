# Hoveddør

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Ringklokke Doorbell** — `binary_sensor.ringklokke_doorbell` — `off`

## button

- **Ringklokke Format SD Card** — `button.ringklokke_format_sd_card` — `unknown`
- **Ringklokke Manual Alarm Start** — `button.ringklokke_manual_alarm_start` — `unknown`
- **Ringklokke Manual Alarm Stop** — `button.ringklokke_manual_alarm_stop` — `unknown`
- **Ringklokke Reboot** — `button.ringklokke_reboot` — `unknown`
- **Ringklokke Sync Time** — `button.ringklokke_sync_time` — `unavailable`

## camera

- **Ringklokke** — `camera.ringklokke_hd_stream_direct` — `idle`
- **camera.ringklokke_sd_stream_direct** — `camera.ringklokke_sd_stream_direct` — `unknown`

## light

- **Ringklokke Floodlight (Timed)** — `light.ringklokke_floodlight_timed` — `off`

## number

- **Ringklokke Microphone - Volume** — `number.ringklokke_microphone_volume` — `100`
- **Ringklokke Motion Detection - Digital Sensitivity** — `number.ringklokke_motion_detection_digital_sensitivity` — `60`
- **Ringklokke Speaker - Volume** — `number.ringklokke_speaker_volume` — `100`
- **Ringklokke Spotlight Intensity** — `number.ringklokke_spotlight_intensity` — `3`

## select

- **Ringklokke Automatic Alarm** — `select.ringklokke_automatic_alarm` — `off`
- **Ringklokke Automatic Reboot - Time** — `select.ringklokke_automatic_reboot_time` — `03:00 - 03:30`
- **Ringklokke Light Frequency** — `select.ringklokke_light_frequency` — `50`
- **Ringklokke Motion Detection** — `select.ringklokke_motion_detection` — `off`
- **Ringklokke Night Vision** — `select.ringklokke_night_vision` — `Infrared Mode`
- **Ringklokke Night Vision Switching** — `select.ringklokke_night_vision_switching` — `auto`
- **Ringklokke Person Detection** — `select.ringklokke_person_detection` — `off`
- **Ringklokke Pet Detection** — `select.ringklokke_pet_detection` — `off`
- **Ringklokke Siren Type** — `select.ringklokke_siren_type` — `Siren`
- **Ringklokke Spotlight on/off for** — `select.ringklokke_spotlight_on_off_for` — `5 min`
- **Ringklokke Timezone** — `select.ringklokke_timezone` — `UTC+01:00 (Europe/Brussels)`
- **Ringklokke Vehicle Detection** — `select.ringklokke_vehicle_detection` — `off`

## sensor

- **sensor.hoveddor_ringklokke_disk_1_hardware_security_config** — `sensor.hoveddor_ringklokke_disk_1_hardware_security_config` — `unknown`
- **sensor.hoveddor_ringklokke_disk_1_password** — `sensor.hoveddor_ringklokke_disk_1_password` — `unknown`
- **sensor.hoveddor_ringklokke_disk_1_security_status** — `sensor.hoveddor_ringklokke_disk_1_security_status` — `unknown`
- **Ringklokke Battery** — `sensor.ringklokke_battery` — `100`
- **sensor.ringklokke_disk_1_crossline_free_space** — `sensor.ringklokke_disk_1_crossline_free_space` — `unknown`
- **sensor.ringklokke_disk_1_crossline_free_space_accurate** — `sensor.ringklokke_disk_1_crossline_free_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_crossline_total_space** — `sensor.ringklokke_disk_1_crossline_total_space` — `unknown`
- **sensor.ringklokke_disk_1_crossline_total_space_accurate** — `sensor.ringklokke_disk_1_crossline_total_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_detect_status** — `sensor.ringklokke_disk_1_detect_status` — `unknown`
- **sensor.ringklokke_disk_1_disk_name** — `sensor.ringklokke_disk_1_disk_name` — `unknown`
- **sensor.ringklokke_disk_1_free_space** — `sensor.ringklokke_disk_1_free_space` — `unknown`
- **sensor.ringklokke_disk_1_free_space_accurate** — `sensor.ringklokke_disk_1_free_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_loop_record_status** — `sensor.ringklokke_disk_1_loop_record_status` — `unknown`
- **sensor.ringklokke_disk_1_msg_push_free_space** — `sensor.ringklokke_disk_1_msg_push_free_space` — `unknown`
- **sensor.ringklokke_disk_1_msg_push_free_space_accurate** — `sensor.ringklokke_disk_1_msg_push_free_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_msg_push_total_space** — `sensor.ringklokke_disk_1_msg_push_total_space` — `unknown`
- **sensor.ringklokke_disk_1_msg_push_total_space_accurate** — `sensor.ringklokke_disk_1_msg_push_total_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_percent** — `sensor.ringklokke_disk_1_percent` — `unknown`
- **sensor.ringklokke_disk_1_picture_free_space** — `sensor.ringklokke_disk_1_picture_free_space` — `unknown`
- **sensor.ringklokke_disk_1_picture_free_space_accurate** — `sensor.ringklokke_disk_1_picture_free_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_picture_total_space** — `sensor.ringklokke_disk_1_picture_total_space` — `unknown`
- **sensor.ringklokke_disk_1_picture_total_space_accurate** — `sensor.ringklokke_disk_1_picture_total_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_record_duration** — `sensor.ringklokke_disk_1_record_duration` — `unknown`
- **sensor.ringklokke_disk_1_record_free_duration** — `sensor.ringklokke_disk_1_record_free_duration` — `unknown`
- **sensor.ringklokke_disk_1_record_start_time** — `sensor.ringklokke_disk_1_record_start_time` — `unknown`
- **sensor.ringklokke_disk_1_rw_attr** — `sensor.ringklokke_disk_1_rw_attr` — `unknown`
- **sensor.ringklokke_disk_1_status** — `sensor.ringklokke_disk_1_status` — `unknown`
- **sensor.ringklokke_disk_1_total_space** — `sensor.ringklokke_disk_1_total_space` — `unknown`
- **sensor.ringklokke_disk_1_total_space_accurate** — `sensor.ringklokke_disk_1_total_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_type** — `sensor.ringklokke_disk_1_type` — `unknown`
- **sensor.ringklokke_disk_1_video_free_space** — `sensor.ringklokke_disk_1_video_free_space` — `unknown`
- **sensor.ringklokke_disk_1_video_free_space_accurate** — `sensor.ringklokke_disk_1_video_free_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_video_total_space** — `sensor.ringklokke_disk_1_video_total_space` — `unknown`
- **sensor.ringklokke_disk_1_video_total_space_accurate** — `sensor.ringklokke_disk_1_video_total_space_accurate` — `unknown`
- **sensor.ringklokke_disk_1_write_protect** — `sensor.ringklokke_disk_1_write_protect` — `unknown`
- **Ringklokke Last Automatic Reboot Time** — `sensor.ringklokke_last_automatic_reboot_time` — `2026-06-23T01:38:07+00:00`
- **Ringklokke Link Type** — `sensor.ringklokke_link_type` — `wifi`
- **Ringklokke Network SSID** — `sensor.ringklokke_network_ssid` — `Det lille hjem`
- **Ringklokke Recordings Synchronization** — `sensor.ringklokke_recordings_synchronization` — `Idle`
- **Ringklokke RSSI** — `sensor.ringklokke_rssi` — `-48`

## siren

- **Ringklokke Siren** — `siren.ringklokke_siren` — `off`

## switch

- **Ringklokke Automatic Reboot** — `switch.ringklokke_automatic_reboot` — `off`
- **Ringklokke Automatically Upgrade Firmware** — `switch.ringklokke_automatically_upgrade_firmware` — `on`
- **Ringklokke Diagnose Mode** — `switch.ringklokke_diagnose_mode` — `off`
- **Ringklokke Flip** — `switch.ringklokke_flip` — `on`
- **Ringklokke Indicator LED** — `switch.ringklokke_indicator_led` — `off`
- **Ringklokke Lens Distortion Correction** — `switch.ringklokke_lens_distortion_correction` — `off`
- **Ringklokke Media Sync** — `switch.ringklokke_media_sync` — `off`
- **Ringklokke Microphone - Mute** — `switch.ringklokke_microphone_mute` — `off`
- **Ringklokke Microphone - Noise Cancellation** — `switch.ringklokke_microphone_noise_cancellation` — `on`
- **Ringklokke Notifications** — `switch.ringklokke_notifications` — `on`
- **Ringklokke Privacy** — `switch.ringklokke_privacy` — `off`
- **Ringklokke Privacy Zones** — `switch.ringklokke_privacy_zones` — `off`
- **Ringklokke Record Audio** — `switch.ringklokke_record_audio` — `on`
- **Ringklokke Record to SD Card** — `switch.ringklokke_record_to_sd_card` — `on`
- **Ringklokke Rich Notifications** — `switch.ringklokke_rich_notifications` — `off`

## update

- **Ringklokke Update** — `update.ringklokke_update` — `off`
