# Bryggers

Generated: 2026-07-05 00:57:13

## button

- **Bryggers Favorite current song** — `button.bryggers_favorite_current_song` — `unknown`

## light

- **Loftlampe bryggers** — `light.loftlampe_bryggers` — `off`

## media_player

- **Bryggers** — `media_player.bryggers` — `off`
- **Bryggers** — `media_player.bryggers_2` — `idle`

## select

- **select.0xa4c1389d8fc50e9e_effect** — `select.0xa4c1389d8fc50e9e_effect` — `unknown`
- **Loftlampe bryggers Color power on behavior** — `select.loftlampe_bryggers_color_power_on_behavior` — `unknown`

## sensor

- **sensor.0xa4c1389d8fc50e9e_last_seen** — `sensor.0xa4c1389d8fc50e9e_last_seen` — `unknown`
- **sensor.0xa4c1389d8fc50e9e_linkquality** — `sensor.0xa4c1389d8fc50e9e_linkquality` — `unknown`

## switch

- **Loftlampe bryggers Do not disturb** — `switch.loftlampe_bryggers_do_not_disturb` — `off`
