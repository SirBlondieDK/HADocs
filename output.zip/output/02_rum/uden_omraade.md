# Uden område

Generated: 2026-07-05 00:57:13

## ai_task

- **Google AI Task** — `ai_task.google_ai_task` — `unknown`
- **OpenAI AI Task** — `ai_task.openai_ai_task` — `unknown`

## automation

- **badeværelse lys ved bevægelse (dag/nat)** — `automation.badevaerelse_lys_ved_bevaegelse_dag_nat` — `on`
- **Besked: Der bliver ringet på dørklokken** — `automation.besked_der_bliver_ringet_pa_dorklokken` — `off`
- **Facadelys + Carport-spot ved Frigate person (kun mørkt, ikke når robot kører)** — `automation.facadelys_carport_spot_ved_frigate_person_kun_morkt` — `off`
- **Facadelys slukkes med carport lys** — `automation.facadelys_slukkes_med_carport_lys` — `on`
- **Facadelys tændes med lys i carport** — `automation.facadelys_taendes_med_lys_i_carport` — `on`
- **Frigate AI Person Alert (FINAL FINAL 😄)** — `automation.frigate_ai_person_alert_vision` — `off`
- **Frigate AI Person Alert (Alle kameraer)** — `automation.frigate_ai_test` — `off`
- **Kontakt Sebastian** — `automation.kontakt_sebastian` — `on`
- **Lyskæde** — `automation.lyskaede` — `unavailable`
- **Night Light Auto** — `automation.night_light_auto` — `on`
- **pc** — `automation.pc` — `on`
- **tænd-pc** — `automation.taend_pc` — `on`
- **test lys** — `automation.test_lys` — `on`

## binary_sensor

- **Aula message** — `binary_sensor.aula_aulamessage` — `on`
- **Car Area All occupancy** — `binary_sensor.car_area_all_occupancy` — `off`
- **Car Area Car occupancy** — `binary_sensor.car_area_car_occupancy` — `unavailable`
- **Car Area Dog occupancy** — `binary_sensor.car_area_dog_occupancy` — `unavailable`
- **Car Area Person occupancy** — `binary_sensor.car_area_person_occupancy` — `off`
- **binary_sensor.file_editor_korer** — `binary_sensor.file_editor_korer` — `unknown`
- **binary_sensor.frigate_korer** — `binary_sensor.frigate_korer` — `unknown`
- **binary_sensor.home_assistant_matter_hub_korer** — `binary_sensor.home_assistant_matter_hub_korer` — `unknown`
- **Indkorelse All occupancy** — `binary_sensor.indkorelse_all_occupancy` — `off`
- **Indkorelse Car occupancy** — `binary_sensor.indkorelse_car_occupancy` — `off`
- **Indkorelse Dog occupancy** — `binary_sensor.indkorelse_dog_occupancy` — `off`
- **Indkorelse Motion** — `binary_sensor.indkorelse_motion` — `off`
- **Indkorelse Person occupancy** — `binary_sensor.indkorelse_person_occupancy` — `off`
- **binary_sensor.mosquitto_broker_korer** — `binary_sensor.mosquitto_broker_korer` — `unknown`
- **binary_sensor.mqtt_explorer_korer** — `binary_sensor.mqtt_explorer_korer` — `unknown`
- **binary_sensor.music_assistant_server_korer** — `binary_sensor.music_assistant_server_korer` — `unknown`
- **binary_sensor.node_red_korer** — `binary_sensor.node_red_korer` — `unknown`
- **Remote UI** — `binary_sensor.remote_ui` — `on`
- **binary_sensor.sebastian_wall_display_android_auto** — `binary_sensor.sebastian_wall_display_android_auto` — `unknown`
- **binary_sensor.sebastian_wall_display_app_inactive** — `binary_sensor.sebastian_wall_display_app_inactive` — `unknown`
- **binary_sensor.sebastian_wall_display_bluetooth_state** — `binary_sensor.sebastian_wall_display_bluetooth_state` — `unknown`
- **binary_sensor.sebastian_wall_display_device_locked** — `binary_sensor.sebastian_wall_display_device_locked` — `unknown`
- **binary_sensor.sebastian_wall_display_device_secure** — `binary_sensor.sebastian_wall_display_device_secure` — `unknown`
- **binary_sensor.sebastian_wall_display_doze_mode** — `binary_sensor.sebastian_wall_display_doze_mode` — `unknown`
- **binary_sensor.sebastian_wall_display_headphones** — `binary_sensor.sebastian_wall_display_headphones` — `unknown`
- **binary_sensor.sebastian_wall_display_high_accuracy_mode** — `binary_sensor.sebastian_wall_display_high_accuracy_mode` — `unknown`
- **binary_sensor.sebastian_wall_display_hotspot_state** — `binary_sensor.sebastian_wall_display_hotspot_state` — `unknown`
- **binary_sensor.sebastian_wall_display_interactive** — `binary_sensor.sebastian_wall_display_interactive` — `unknown`
- **binary_sensor.sebastian_wall_display_is_charging** — `binary_sensor.sebastian_wall_display_is_charging` — `unknown`
- **binary_sensor.sebastian_wall_display_keyguard_locked** — `binary_sensor.sebastian_wall_display_keyguard_locked` — `unknown`
- **binary_sensor.sebastian_wall_display_keyguard_secure** — `binary_sensor.sebastian_wall_display_keyguard_secure` — `unknown`
- **binary_sensor.sebastian_wall_display_mic_muted** — `binary_sensor.sebastian_wall_display_mic_muted` — `unknown`
- **binary_sensor.sebastian_wall_display_music_active** — `binary_sensor.sebastian_wall_display_music_active` — `unknown`
- **binary_sensor.sebastian_wall_display_power_save** — `binary_sensor.sebastian_wall_display_power_save` — `unknown`
- **binary_sensor.sebastian_wall_display_speakerphone** — `binary_sensor.sebastian_wall_display_speakerphone` — `unknown`
- **binary_sensor.sebastian_wall_display_wi_fi_state** — `binary_sensor.sebastian_wall_display_wi_fi_state` — `unknown`
- **binary_sensor.sebastian_wall_display_work_profile** — `binary_sensor.sebastian_wall_display_work_profile` — `unknown`
- **binary_sensor.silicon_labs_flasher_korer** — `binary_sensor.silicon_labs_flasher_korer` — `unknown`
- **binary_sensor.silicon_labs_multiprotocol_korer** — `binary_sensor.silicon_labs_multiprotocol_korer` — `unknown`
- **Sirblondiedk iPhone Focus** — `binary_sensor.sirblondiedk_iphone_focus` — `off`
- **binary_sensor.sofia_wall_display_android_auto** — `binary_sensor.sofia_wall_display_android_auto` — `unknown`
- **binary_sensor.sofia_wall_display_app_inactive** — `binary_sensor.sofia_wall_display_app_inactive` — `unknown`
- **binary_sensor.sofia_wall_display_bluetooth_state** — `binary_sensor.sofia_wall_display_bluetooth_state` — `unknown`
- **binary_sensor.sofia_wall_display_device_locked** — `binary_sensor.sofia_wall_display_device_locked` — `unknown`
- **binary_sensor.sofia_wall_display_device_secure** — `binary_sensor.sofia_wall_display_device_secure` — `unknown`
- **binary_sensor.sofia_wall_display_doze_mode** — `binary_sensor.sofia_wall_display_doze_mode` — `unknown`
- **binary_sensor.sofia_wall_display_headphones** — `binary_sensor.sofia_wall_display_headphones` — `unknown`
- **binary_sensor.sofia_wall_display_high_accuracy_mode** — `binary_sensor.sofia_wall_display_high_accuracy_mode` — `unknown`
- **binary_sensor.sofia_wall_display_hotspot_state** — `binary_sensor.sofia_wall_display_hotspot_state` — `unknown`
- **binary_sensor.sofia_wall_display_interactive** — `binary_sensor.sofia_wall_display_interactive` — `unknown`
- **binary_sensor.sofia_wall_display_is_charging** — `binary_sensor.sofia_wall_display_is_charging` — `unknown`
- **binary_sensor.sofia_wall_display_keyguard_locked** — `binary_sensor.sofia_wall_display_keyguard_locked` — `unknown`
- **binary_sensor.sofia_wall_display_keyguard_secure** — `binary_sensor.sofia_wall_display_keyguard_secure` — `unknown`
- **binary_sensor.sofia_wall_display_mic_muted** — `binary_sensor.sofia_wall_display_mic_muted` — `unknown`
- **binary_sensor.sofia_wall_display_music_active** — `binary_sensor.sofia_wall_display_music_active` — `unknown`
- **binary_sensor.sofia_wall_display_power_save** — `binary_sensor.sofia_wall_display_power_save` — `unknown`
- **binary_sensor.sofia_wall_display_speakerphone** — `binary_sensor.sofia_wall_display_speakerphone` — `unknown`
- **binary_sensor.sofia_wall_display_wi_fi_state** — `binary_sensor.sofia_wall_display_wi_fi_state` — `unknown`
- **binary_sensor.sofia_wall_display_work_profile** — `binary_sensor.sofia_wall_display_work_profile` — `unknown`
- **binary_sensor.studio_code_server_korer** — `binary_sensor.studio_code_server_korer` — `unknown`
- **binary_sensor.sun_solar_rising** — `binary_sensor.sun_solar_rising` — `unknown`
- **binary_sensor.tabet_stue_android_auto** — `binary_sensor.tabet_stue_android_auto` — `unknown`
- **binary_sensor.tabet_stue_app_inactive** — `binary_sensor.tabet_stue_app_inactive` — `unknown`
- **binary_sensor.tabet_stue_bluetooth_state** — `binary_sensor.tabet_stue_bluetooth_state` — `unknown`
- **binary_sensor.tabet_stue_device_locked** — `binary_sensor.tabet_stue_device_locked` — `unknown`
- **binary_sensor.tabet_stue_device_secure** — `binary_sensor.tabet_stue_device_secure` — `unknown`
- **binary_sensor.tabet_stue_doze_mode** — `binary_sensor.tabet_stue_doze_mode` — `unknown`
- **binary_sensor.tabet_stue_headphones** — `binary_sensor.tabet_stue_headphones` — `unknown`
- **binary_sensor.tabet_stue_high_accuracy_mode** — `binary_sensor.tabet_stue_high_accuracy_mode` — `unknown`
- **binary_sensor.tabet_stue_hotspot_state** — `binary_sensor.tabet_stue_hotspot_state` — `unknown`
- **binary_sensor.tabet_stue_interactive** — `binary_sensor.tabet_stue_interactive` — `unknown`
- **binary_sensor.tabet_stue_is_charging** — `binary_sensor.tabet_stue_is_charging` — `unknown`
- **binary_sensor.tabet_stue_keyguard_locked** — `binary_sensor.tabet_stue_keyguard_locked` — `unknown`
- **binary_sensor.tabet_stue_keyguard_secure** — `binary_sensor.tabet_stue_keyguard_secure` — `unknown`
- **binary_sensor.tabet_stue_mic_muted** — `binary_sensor.tabet_stue_mic_muted` — `unknown`
- **binary_sensor.tabet_stue_music_active** — `binary_sensor.tabet_stue_music_active` — `unknown`
- **binary_sensor.tabet_stue_power_save** — `binary_sensor.tabet_stue_power_save` — `unknown`
- **binary_sensor.tabet_stue_speakerphone** — `binary_sensor.tabet_stue_speakerphone` — `unknown`
- **binary_sensor.tabet_stue_wifi_state** — `binary_sensor.tabet_stue_wifi_state` — `unknown`
- **binary_sensor.tabet_stue_work_profile** — `binary_sensor.tabet_stue_work_profile` — `unknown`
- **binary_sensor.terminal_ssh_korer** — `binary_sensor.terminal_ssh_korer` — `unknown`
- **Zigbee2MQTT Bridge Connection state** — `binary_sensor.zigbee2mqtt_bridge_connection_state` — `on`
- **binary_sensor.zigbee2mqtt_bridge_restart_required** — `binary_sensor.zigbee2mqtt_bridge_restart_required` — `unknown`

## button

- **All Units Favorite current song** — `button.all_units_favorite_current_song` — `unknown`
- **Fjernsyn Favorite current song** — `button.fjernsyn_favorite_current_song` — `unknown`
- **højttaler gruppe 1 Favorite current song** — `button.hojttaler_gruppe_1_favorite_current_song` — `unknown`
- **højttaler uden hubs Favorite current song** — `button.hojttaler_uden_hubs_favorite_current_song` — `unknown`
- **hub stue og soveværelse Favorite current song** — `button.hub_stue_og_sovevaerelse_favorite_current_song` — `unknown`
- **hubs Favorite current song** — `button.hubs_favorite_current_song` — `unknown`
- **mini  Favorite current song** — `button.mini_favorite_current_song` — `unknown`
- **Sebastian Favorite current song** — `button.sebastian_favorite_current_song` — `unknown`
- **små og soveværelse Favorite current song** — `button.sma_og_sovevaerelse_favorite_current_song` — `unknown`
- **Soveværelse Favorite current song** — `button.sovevaerelse_favorite_current_song` — `unavailable`
- **soveværelset og de smås værelse Favorite current song** — `button.sovevaerelset_og_de_smas_vaerelse_favorite_current_song` — `unknown`
- **stue og soveværelse  Favorite current song** — `button.stue_og_sovevaerelse_favorite_current_song` — `unknown`
- **Fars PC** — `button.wake_on_lan_24_41_8c_93_d0_ff` — `2025-01-08T20:33:46.742203+00:00`
- **Zigbee2MQTT Bridge Restart** — `button.zigbee2mqtt_bridge_restart` — `unknown`

## calendar

- **Birthdays** — `calendar.birthdays` — `off`
- **Den mentale kriger** — `calendar.den_mentale_kriger` — `off`
- **Familie** — `calendar.familie` — `off`
- **Fødselsdage** — `calendar.fodselsdage` — `unavailable`
- **Helligdage i danmark** — `calendar.helligdage_i_danmark` — `off`
- **Sirblondiedk@gmail.com** — `calendar.sirblondiedk_gmail_com` — `off`
- **calendar.skoleskema_silke_dinesen_philip_christiansen** — `calendar.skoleskema_silke_dinesen_philip_christiansen` — `unknown`
- **Ugenumre** — `calendar.ugenumre` — `off`
- **calendar.working_location** — `calendar.working_location` — `unknown`

## camera

- **indkørelse** — `camera.indkorelse` — `recording`

## conversation

- **Google AI Conversation** — `conversation.google_ai_conversation` — `unknown`
- **OpenAI Conversation** — `conversation.openai_conversation` — `unknown`

## device_tracker

- **Bent Dinesen Schmidt – Apple Watch** — `device_tracker.bent_dinesen_schmidt_apple_watch` — `unavailable`
- **GVH5075_22BD** — `device_tracker.gvh5075_22bd` — `not_home`
- **iPad** — `device_tracker.kitchen_deco_ipad` — `not_home`
- **iPhone** — `device_tracker.kitchen_deco_iphone_2` — `not_home`
- **S2eb7335ec69640c3C 94BC** — `device_tracker.s2eb7335ec69640c3c_94bc` — `unavailable`
- **Saphe Drive Pro 710C** — `device_tracker.saphe_drive_pro_710c` — `unavailable`
- **Saphe Drive Pro F81F** — `device_tracker.saphe_drive_pro_f81f` — `unavailable`
- **Sebastian wall display ** — `device_tracker.sebastian_wall_display` — `unknown`
- **Lenovo-Tab** — `device_tracker.server_rum_deco_kokken_lenovo_tab` — `not_home`
- **Lenovo-Tab** — `device_tracker.server_rum_deco_kokken_lenovo_tab_2` — `not_home`
- **Wake on LAN 24:41:8c:93:d0:ff SebastianPC** — `device_tracker.server_rum_deco_kokken_sebastianpc` — `not_home`
- **Chromecast** — `device_tracker.server_rum_deco_loft_chromecast` — `not_home`
- **Sirblondiedk iPhone** — `device_tracker.sirblondiedk_iphone` — `unavailable`
- **Sirblondiedk iPhone** — `device_tracker.sirblondiedk_iphone_2` — `home`
- **Sofia Dinesen Philip - iPhone** — `device_tracker.sofia_dinesen_philip_iphone` — `not_home`
- **Sofia wall display ** — `device_tracker.sofia_wall_display` — `unknown`
- **Tabet stue** — `device_tracker.tabet_stue` — `unknown`
- **XPED-0060370B54C3** — `device_tracker.xped_0060370b54c3` — `unavailable`

## event

- **Backup Automatic backup** — `event.backup_automatic_backup` — `2026-07-04T03:40:28.313+00:00`

## image

- **Indkorelse Car** — `image.indkorelse_car` — `2026-07-04T22:27:38.968318`
- **Indkorelse Dog** — `image.indkorelse_dog` — `2026-07-04T22:27:38.961530`
- **Indkorelse Person** — `image.indkorelse_person` — `2026-07-04T22:27:38.967685`

## input_boolean

- **Party mode** — `input_boolean.party_mode` — `off`

## input_datetime

- **Last AI Alert** — `input_datetime.last_ai_alert` — `2026-04-04 00:00:00`

## input_select

- **AI Mode** — `input_select.ai_mode` — `Normal`

## input_text

- **Kontakt ved de små sidste status** — `input_text.kontakt_ved_de_sma_sidste_status` — `unknown`

## light

- **køkken spot 1** — `light.kokken_spot_1` — `on`
- **Køkken spot 2** — `light.kokken_spot_2` — `on`
- **Køkken spot 3** — `light.kokken_spot_3` — `on`
- **lampe de små pære 1** — `light.lampe_de_sma_paere_1` — `off`
- **lampe de små pære 2** — `light.lampe_de_sma_paere_2` — `off`
- **lampe de små pære 3** — `light.lampe_de_sma_paere_3` — `off`

## media_player

- **All Units** — `media_player.all_units` — `off`
- **All Units** — `media_player.all_units_2` — `off`
- **d5369777-music-assistant** — `media_player.d5369777_music_assistant` — `idle`
- **Fjernsyn** — `media_player.fjernsyn` — `idle`
- **højttaler gruppe 1** — `media_player.hojttaler_gruppe_1` — `off`
- **højttaler gruppe 1** — `media_player.hojttaler_gruppe_1_2` — `off`
- **højttaler uden hubs** — `media_player.hojttaler_uden_hubs` — `off`
- **højttaler uden hubs** — `media_player.hojttaler_uden_hubs_2` — `off`
- **hub stue og soveværelse** — `media_player.hub_stue_og_sovevaerelse` — `off`
- **hub stue og soveværelse** — `media_player.hub_stue_og_sovevaerelse_2` — `off`
- **hubs** — `media_player.hubs` — `off`
- **hubs** — `media_player.hubs_2` — `off`
- **mini ** — `media_player.mini` — `off`
- **mini ** — `media_player.mini_2` — `off`
- **Sebastian** — `media_player.sebastian_2` — `idle`
- **små og soveværelse** — `media_player.sma_og_sovevaerelse` — `off`
- **små og soveværelse** — `media_player.sma_og_sovevaerelse_2` — `off`
- **Soveværelse** — `media_player.sovevaerelse_2` — `unavailable`
- **soveværelset og de smås værelse** — `media_player.sovevaerelset_og_de_smas_vaerelse` — `off`
- **soveværelset og de smås værelse** — `media_player.sovevaerelset_og_de_smas_vaerelse_2` — `off`
- **Spotify Bent Christiansen** — `media_player.spotify_bent_christiansen` — `idle`
- **stue og soveværelse ** — `media_player.stue_og_sovevaerelse` — `off`
- **stue og soveværelse ** — `media_player.stue_og_sovevaerelse_2` — `off`

## notify

- **File** — `notify.file` — `unknown`
- **Sebastian wall display ** — `notify.sebastian_wall_display` — `unknown`
- **Sirblondiedk iPhone** — `notify.sirblondiedk_iphone` — `unknown`
- **Sofia Dinesen Philip - iPhone** — `notify.sofia_dinesen_philip_iphone` — `unknown`
- **Sofia wall display ** — `notify.sofia_wall_display` — `unknown`
- **Tabet stue** — `notify.tabet_stue` — `unknown`

## number

- **number.indkorelse_contour_area** — `number.indkorelse_contour_area` — `unknown`
- **number.indkorelse_threshold** — `number.indkorelse_threshold` — `unknown`

## person

- **Bent Dinesen Schmidt Christiansen** — `person.bent_dinesen_schmidt_christiansen` — `home`
- **Maja** — `person.maja` — `unknown`
- **Sebastian Dinesen Philip Christiansen** — `person.sebastian_dinesen_philip_christiansen` — `unknown`
- **Sofia Dinesen Philip Christiansen** — `person.sofie_dinesen_philip_christiansen` — `not_home`

## schedule

- **Test** — `schedule.test` — `off`

## script

- **Dørklokke** — `script.dorklokke` — `off`
- **fest** — `script.fest` — `off`
- **Natlys de små** — `script.natlys_de_sma` — `off`
- **Natlys Sebastian** — `script.natlys_sebastian` — `off`
- **Natlys Sofia** — `script.natlys_sofia` — `off`
- **print_entity_attributes** — `script.print_entity_attributes` — `off`
- **Wakeup de små** — `script.wakeup_de_sma` — `off`
- **Wakeup køkken** — `script.wakeup_kokken` — `off`
- **Wakeup Sebastian** — `script.wakeup_sebastian` — `off`
- **Wakeup Sofia** — `script.wakeup_sofia` — `off`
- **Wakeup Soveværelse** — `script.wakeup_sovevarelse` — `off`

## select

- **select.0xa4c1386c83e5e3a6_effect** — `select.0xa4c1386c83e5e3a6_effect` — `unknown`
- **select.0xa4c1387f1efbb7b4_effect** — `select.0xa4c1387f1efbb7b4_effect` — `unknown`
- **select.0xa4c138bf6a50d1db_effect** — `select.0xa4c138bf6a50d1db_effect` — `unknown`
- **select.0xe8ca50dda00d0000_effect** — `select.0xe8ca50dda00d0000_effect` — `unknown`
- **select.0xe8ca50ddece90000_effect** — `select.0xe8ca50ddece90000_effect` — `unknown`
- **select.0xe8ca50ddf9bc0000_effect** — `select.0xe8ca50ddf9bc0000_effect` — `unknown`
- **køkken spot 1 Color power on behavior** — `select.kokken_spot_1_color_power_on_behavior` — `unknown`
- **køkken spot 1 Power-on behavior** — `select.kokken_spot_1_power_on_behavior` — `unknown`
- **Køkken spot 2 Color power on behavior** — `select.kokken_spot_2_color_power_on_behavior` — `unknown`
- **Køkken spot 2 Power-on behavior** — `select.kokken_spot_2_power_on_behavior` — `unknown`
- **Køkken spot 3 Color power on behavior** — `select.kokken_spot_3_color_power_on_behavior` — `unknown`
- **Køkken spot 3 Power-on behavior** — `select.kokken_spot_3_power_on_behavior` — `unknown`
- **lampe de små pære 1 Color power on behavior** — `select.lampe_de_sma_paere_1_color_power_on_behavior` — `unknown`
- **lampe de små pære 2 Color power on behavior** — `select.lampe_de_sma_paere_2_color_power_on_behavior` — `unknown`
- **lampe de små pære 3 Color power on behavior** — `select.lampe_de_sma_paere_3_color_power_on_behavior` — `unknown`
- **Zigbee2MQTT Bridge Log level** — `select.zigbee2mqtt_bridge_log_level` — `info`

## sensor

- **sensor.0xa4c1386c83e5e3a6_last_seen** — `sensor.0xa4c1386c83e5e3a6_last_seen` — `unknown`
- **sensor.0xa4c1386c83e5e3a6_linkquality** — `sensor.0xa4c1386c83e5e3a6_linkquality` — `unknown`
- **sensor.0xa4c1387f1efbb7b4_last_seen** — `sensor.0xa4c1387f1efbb7b4_last_seen` — `unknown`
- **sensor.0xa4c1387f1efbb7b4_linkquality** — `sensor.0xa4c1387f1efbb7b4_linkquality` — `unknown`
- **sensor.0xa4c138bf6a50d1db_last_seen** — `sensor.0xa4c138bf6a50d1db_last_seen` — `unknown`
- **sensor.0xa4c138bf6a50d1db_linkquality** — `sensor.0xa4c138bf6a50d1db_linkquality` — `unknown`
- **sensor.0xe8ca50dda00d0000_last_seen** — `sensor.0xe8ca50dda00d0000_last_seen` — `unknown`
- **sensor.0xe8ca50dda00d0000_linkquality** — `sensor.0xe8ca50dda00d0000_linkquality` — `unknown`
- **sensor.0xe8ca50ddece90000_last_seen** — `sensor.0xe8ca50ddece90000_last_seen` — `unknown`
- **sensor.0xe8ca50ddece90000_linkquality** — `sensor.0xe8ca50ddece90000_linkquality` — `unknown`
- **sensor.0xe8ca50ddf9bc0000_last_seen** — `sensor.0xe8ca50ddf9bc0000_last_seen` — `unknown`
- **sensor.0xe8ca50ddf9bc0000_linkquality** — `sensor.0xe8ca50ddf9bc0000_linkquality` — `unknown`
- **Backup Backup Manager state** — `sensor.backup_backup_manager_state` — `idle`
- **Backup Last attempted automatic backup** — `sensor.backup_last_attempted_automatic_backup` — `2026-07-04T03:40:03+00:00`
- **Backup Last successful automatic backup** — `sensor.backup_last_successful_automatic_backup` — `2026-07-04T03:40:28+00:00`
- **Backup Next scheduled automatic backup** — `sensor.backup_next_scheduled_automatic_backup` — `2026-07-08T03:04:40+00:00`
- **Bent Dinesen Schmidt – Apple Watch Batteri** — `sensor.bent_dinesen_schmidt_apple_watch_batteri` — `unavailable`
- **Car Area All Active Count** — `sensor.car_area_all_active_count` — `0`
- **Car Area All count** — `sensor.car_area_all_count` — `0`
- **Car Area Car Active Count** — `sensor.car_area_car_active_count` — `unavailable`
- **Car Area Car count** — `sensor.car_area_car_count` — `unavailable`
- **Car Area Dog Active Count** — `sensor.car_area_dog_active_count` — `unavailable`
- **Car Area Dog count** — `sensor.car_area_dog_count` — `unavailable`
- **Car Area Person Active Count** — `sensor.car_area_person_active_count` — `0`
- **Car Area Person count** — `sensor.car_area_person_count` — `0`
- **sensor.continuously_casting_dashboards_192_168_68139_status** — `sensor.continuously_casting_dashboards_192_168_68139_status` — `unknown`
- **sensor.continuously_casting_dashboards_192_168_68_139_status** — `sensor.continuously_casting_dashboards_192_168_68_139_status` — `unknown`
- **sensor.continuously_casting_dashboards_192_168_68_151_status** — `sensor.continuously_casting_dashboards_192_168_68_151_status` — `unknown`
- **sensor.continuously_casting_dashboards_assistant_active** — `sensor.continuously_casting_dashboards_assistant_active` — `unknown`
- **sensor.continuously_casting_dashboards_connected_devices** — `sensor.continuously_casting_dashboards_connected_devices` — `unknown`
- **sensor.continuously_casting_dashboards_disconnected_devices** — `sensor.continuously_casting_dashboards_disconnected_devices` — `unknown`
- **sensor.continuously_casting_dashboards_media_playing** — `sensor.continuously_casting_dashboards_media_playing` — `unknown`
- **sensor.continuously_casting_dashboards_other_content** — `sensor.continuously_casting_dashboards_other_content` — `unknown`
- **sensor.continuously_casting_dashboards_sovevaerelse_hub_status** — `sensor.continuously_casting_dashboards_sovevaerelse_hub_status` — `unknown`
- **sensor.continuously_casting_dashboards_stue_status** — `sensor.continuously_casting_dashboards_stue_status` — `unknown`
- **sensor.continuously_casting_dashboards_total_devices** — `sensor.continuously_casting_dashboards_total_devices` — `unknown`
- **Dwains Dashboard Latest version** — `sensor.dwains_dashboard_latest_version` — `3.7.0`
- **sensor.file_editor_cpu_procent** — `sensor.file_editor_cpu_procent` — `unknown`
- **sensor.file_editor_hukommelsesprocent** — `sensor.file_editor_hukommelsesprocent` — `unknown`
- **sensor.file_editor_nyeste_version** — `sensor.file_editor_nyeste_version` — `unknown`
- **sensor.file_editor_version** — `sensor.file_editor_version` — `unknown`
- **sensor.frigate_camera_fps** — `sensor.frigate_camera_fps` — `unknown`
- **sensor.frigate_coral_inference_speed** — `sensor.frigate_coral_inference_speed` — `unknown`
- **sensor.frigate_cpu_procent** — `sensor.frigate_cpu_procent` — `unknown`
- **sensor.frigate_detection_fps** — `sensor.frigate_detection_fps` — `unknown`
- **sensor.frigate_hukommelsesprocent** — `sensor.frigate_hukommelsesprocent` — `unknown`
- **sensor.frigate_intel_vaapi_gpu_load** — `sensor.frigate_intel_vaapi_gpu_load` — `unknown`
- **sensor.frigate_nyeste_version** — `sensor.frigate_nyeste_version` — `unknown`
- **sensor.frigate_process_fps** — `sensor.frigate_process_fps` — `unknown`
- **sensor.frigate_skipped_fps** — `sensor.frigate_skipped_fps` — `unknown`
- **sensor.frigate_status** — `sensor.frigate_status` — `unknown`
- **sensor.frigate_uptime** — `sensor.frigate_uptime` — `unknown`
- **sensor.frigate_version** — `sensor.frigate_version` — `unknown`
- **GVH5075_22BD Estimated distance** — `sensor.gvh5075_22bd_estimated_distance` — `unavailable`
- **sensor.gvh5075_22bd_power** — `sensor.gvh5075_22bd_power` — `unknown`
- **sensor.gvh5075_22bd_signalstyrke** — `sensor.gvh5075_22bd_signalstyrke` — `unknown`
- **sensor.gvh5075_22bd_vendor** — `sensor.gvh5075_22bd_vendor` — `unknown`
- **sensor.home_assistant_core_cpu_percent** — `sensor.home_assistant_core_cpu_percent` — `unknown`
- **sensor.home_assistant_core_memory_percent** — `sensor.home_assistant_core_memory_percent` — `unknown`
- **sensor.home_assistant_host_apparmor_version** — `sensor.home_assistant_host_apparmor_version` — `unknown`
- **sensor.home_assistant_host_disk_free** — `sensor.home_assistant_host_disk_free` — `unknown`
- **sensor.home_assistant_host_disk_total** — `sensor.home_assistant_host_disk_total` — `unknown`
- **sensor.home_assistant_host_disk_used** — `sensor.home_assistant_host_disk_used` — `unknown`
- **sensor.home_assistant_host_os_agent_version** — `sensor.home_assistant_host_os_agent_version` — `unknown`
- **sensor.home_assistant_matter_hub_cpu_procent** — `sensor.home_assistant_matter_hub_cpu_procent` — `unknown`
- **sensor.home_assistant_matter_hub_hukommelsesprocent** — `sensor.home_assistant_matter_hub_hukommelsesprocent` — `unknown`
- **sensor.home_assistant_matter_hub_nyeste_version** — `sensor.home_assistant_matter_hub_nyeste_version` — `unknown`
- **sensor.home_assistant_matter_hub_version** — `sensor.home_assistant_matter_hub_version` — `unknown`
- **sensor.home_assistant_operating_system_newest_version** — `sensor.home_assistant_operating_system_newest_version` — `unknown`
- **sensor.home_assistant_operating_system_version** — `sensor.home_assistant_operating_system_version` — `unknown`
- **sensor.home_assistant_supervisor_cpu_percent** — `sensor.home_assistant_supervisor_cpu_percent` — `unknown`
- **sensor.home_assistant_supervisor_memory_percent** — `sensor.home_assistant_supervisor_memory_percent` — `unknown`
- **husets Multimedie  Active clients** — `sensor.husets_multimedie_active_clients` — `0`
- **Indkorelse All Active Count** — `sensor.indkorelse_all_active_count` — `0`
- **Indkorelse All count** — `sensor.indkorelse_all_count` — `0`
- **sensor.indkorelse_camera_fps** — `sensor.indkorelse_camera_fps` — `unknown`
- **sensor.indkorelse_capture_cpu_usage** — `sensor.indkorelse_capture_cpu_usage` — `unknown`
- **Indkorelse Car Active Count** — `sensor.indkorelse_car_active_count` — `0`
- **Indkorelse Car count** — `sensor.indkorelse_car_count` — `0`
- **sensor.indkorelse_detect_cpu_usage** — `sensor.indkorelse_detect_cpu_usage` — `unknown`
- **sensor.indkorelse_detection_fps** — `sensor.indkorelse_detection_fps` — `unknown`
- **Indkorelse Dog Active Count** — `sensor.indkorelse_dog_active_count` — `0`
- **Indkorelse Dog count** — `sensor.indkorelse_dog_count` — `0`
- **sensor.indkorelse_ffmpeg_cpu_usage** — `sensor.indkorelse_ffmpeg_cpu_usage` — `unknown`
- **Indkorelse Person Active Count** — `sensor.indkorelse_person_active_count` — `0`
- **Indkorelse Person count** — `sensor.indkorelse_person_count` — `0`
- **sensor.indkorelse_process_fps** — `sensor.indkorelse_process_fps` — `unknown`
- **Indkorelse Review Status** — `sensor.indkorelse_review_status` — `unknown`
- **sensor.indkorelse_skipped_fps** — `sensor.indkorelse_skipped_fps` — `unknown`
- **iPad (2) Batteri** — `sensor.ipad_2_batteri` — `unavailable`
- **iPad Batteri** — `sensor.ipad_batteri` — `unavailable`
- **Kontakt Rumdeler Action** — `sensor.kontakt_rumdeler_action` — `unavailable`
- **sensor.kontakt_rumdeler_last_seen** — `sensor.kontakt_rumdeler_last_seen` — `unknown`
- **sensor.kontakt_rumdeler_linkquality** — `sensor.kontakt_rumdeler_linkquality` — `unknown`
- **sensor.marlene_apple_watch_batteri** — `sensor.marlene_apple_watch_batteri` — `unknown`
- **sensor.marlene_ravn_batteri** — `sensor.marlene_ravn_batteri` — `unknown`
- **sensor.mosquitto_broker_cpu_procent** — `sensor.mosquitto_broker_cpu_procent` — `unknown`
- **sensor.mosquitto_broker_hukommelsesprocent** — `sensor.mosquitto_broker_hukommelsesprocent` — `unknown`
- **sensor.mosquitto_broker_nyeste_version** — `sensor.mosquitto_broker_nyeste_version` — `unknown`
- **sensor.mosquitto_broker_version** — `sensor.mosquitto_broker_version` — `unknown`
- **sensor.mqtt_explorer_cpu_procent** — `sensor.mqtt_explorer_cpu_procent` — `unknown`
- **sensor.mqtt_explorer_hukommelsesprocent** — `sensor.mqtt_explorer_hukommelsesprocent` — `unknown`
- **sensor.mqtt_explorer_nyeste_version** — `sensor.mqtt_explorer_nyeste_version` — `unknown`
- **sensor.mqtt_explorer_version** — `sensor.mqtt_explorer_version` — `unknown`
- **sensor.music_assistant_server_cpu_procent** — `sensor.music_assistant_server_cpu_procent` — `unknown`
- **sensor.music_assistant_server_hukommelsesprocent** — `sensor.music_assistant_server_hukommelsesprocent` — `unknown`
- **sensor.music_assistant_server_nyeste_version** — `sensor.music_assistant_server_nyeste_version` — `unknown`
- **sensor.music_assistant_server_version** — `sensor.music_assistant_server_version` — `unknown`
- **sensor.node_red_cpu_procent** — `sensor.node_red_cpu_procent` — `unknown`
- **sensor.node_red_hukommelsesprocent** — `sensor.node_red_hukommelsesprocent` — `unknown`
- **sensor.node_red_nyeste_version** — `sensor.node_red_nyeste_version` — `unknown`
- **sensor.node_red_version** — `sensor.node_red_version` — `unknown`
- **S2eb7335ec69640c3C 94BC Estimated distance** — `sensor.s2eb7335ec69640c3c_94bc_estimated_distance` — `unavailable`
- **sensor.s2eb7335ec69640c3c_94bc_power** — `sensor.s2eb7335ec69640c3c_94bc_power` — `unknown`
- **sensor.s2eb7335ec69640c3c_94bc_signalstyrke** — `sensor.s2eb7335ec69640c3c_94bc_signalstyrke` — `unknown`
- **sensor.s2eb7335ec69640c3c_94bc_vendor** — `sensor.s2eb7335ec69640c3c_94bc_vendor` — `unknown`
- **Saphe Drive Pro 710C Estimated distance** — `sensor.saphe_drive_pro_710c_estimated_distance` — `unavailable`
- **sensor.saphe_drive_pro_710c_power** — `sensor.saphe_drive_pro_710c_power` — `unknown`
- **sensor.saphe_drive_pro_710c_signalstyrke** — `sensor.saphe_drive_pro_710c_signalstyrke` — `unknown`
- **sensor.saphe_drive_pro_710c_vendor** — `sensor.saphe_drive_pro_710c_vendor` — `unknown`
- **Saphe Drive Pro F81F Estimated distance** — `sensor.saphe_drive_pro_f81f_estimated_distance` — `unavailable`
- **sensor.saphe_drive_pro_f81f_power** — `sensor.saphe_drive_pro_f81f_power` — `unknown`
- **sensor.saphe_drive_pro_f81f_signalstyrke** — `sensor.saphe_drive_pro_f81f_signalstyrke` — `unknown`
- **sensor.saphe_drive_pro_f81f_vendor** — `sensor.saphe_drive_pro_f81f_vendor` — `unknown`
- **Sebastian Dinesen Philip - iPhone Batteri** — `sensor.sebastian_dinesen_philip_iphone_batteri` — `unavailable`
- **sensor.sebastian_wall_display_active_notification_count** — `sensor.sebastian_wall_display_active_notification_count` — `unknown`
- **sensor.sebastian_wall_display_app_importance** — `sensor.sebastian_wall_display_app_importance` — `unknown`
- **sensor.sebastian_wall_display_app_memory** — `sensor.sebastian_wall_display_app_memory` — `unknown`
- **sensor.sebastian_wall_display_app_rx_gb** — `sensor.sebastian_wall_display_app_rx_gb` — `unknown`
- **sensor.sebastian_wall_display_app_tx_gb** — `sensor.sebastian_wall_display_app_tx_gb` — `unknown`
- **sensor.sebastian_wall_display_audio_mode** — `sensor.sebastian_wall_display_audio_mode` — `unknown`
- **sensor.sebastian_wall_display_battery_health** — `sensor.sebastian_wall_display_battery_health` — `unknown`
- **Sebastian wall display  Battery level** — `sensor.sebastian_wall_display_battery_level` — `3`
- **sensor.sebastian_wall_display_battery_power** — `sensor.sebastian_wall_display_battery_power` — `unknown`
- **Sebastian wall display  Battery state** — `sensor.sebastian_wall_display_battery_state` — `discharging`
- **sensor.sebastian_wall_display_battery_temperature** — `sensor.sebastian_wall_display_battery_temperature` — `unknown`
- **sensor.sebastian_wall_display_beacon_monitor** — `sensor.sebastian_wall_display_beacon_monitor` — `unknown`
- **sensor.sebastian_wall_display_ble_transmitter** — `sensor.sebastian_wall_display_ble_transmitter` — `unknown`
- **sensor.sebastian_wall_display_bluetooth_connection** — `sensor.sebastian_wall_display_bluetooth_connection` — `unknown`
- **sensor.sebastian_wall_display_car_battery** — `sensor.sebastian_wall_display_car_battery` — `unknown`
- **sensor.sebastian_wall_display_car_charging_status** — `sensor.sebastian_wall_display_car_charging_status` — `unknown`
- **sensor.sebastian_wall_display_car_ev_connector_type** — `sensor.sebastian_wall_display_car_ev_connector_type` — `unknown`
- **sensor.sebastian_wall_display_car_fuel** — `sensor.sebastian_wall_display_car_fuel` — `unknown`
- **sensor.sebastian_wall_display_car_fuel_type** — `sensor.sebastian_wall_display_car_fuel_type` — `unknown`
- **sensor.sebastian_wall_display_car_name** — `sensor.sebastian_wall_display_car_name` — `unknown`
- **sensor.sebastian_wall_display_car_odometer** — `sensor.sebastian_wall_display_car_odometer` — `unknown`
- **sensor.sebastian_wall_display_car_range_remaining** — `sensor.sebastian_wall_display_car_range_remaining` — `unknown`
- **sensor.sebastian_wall_display_car_speed** — `sensor.sebastian_wall_display_car_speed` — `unknown`
- **Sebastian wall display  Charger type** — `sensor.sebastian_wall_display_charger_type` — `none`
- **sensor.sebastian_wall_display_current_time_zone** — `sensor.sebastian_wall_display_current_time_zone` — `unknown`
- **sensor.sebastian_wall_display_current_version** — `sensor.sebastian_wall_display_current_version` — `unknown`
- **sensor.sebastian_wall_display_detected_activity** — `sensor.sebastian_wall_display_detected_activity` — `unknown`
- **sensor.sebastian_wall_display_do_not_disturb_sensor** — `sensor.sebastian_wall_display_do_not_disturb_sensor` — `unknown`
- **sensor.sebastian_wall_display_external_storage** — `sensor.sebastian_wall_display_external_storage` — `unknown`
- **sensor.sebastian_wall_display_geocoded_location** — `sensor.sebastian_wall_display_geocoded_location` — `unknown`
- **sensor.sebastian_wall_display_high_accuracy_update_interval** — `sensor.sebastian_wall_display_high_accuracy_update_interval` — `unknown`
- **sensor.sebastian_wall_display_internal_storage** — `sensor.sebastian_wall_display_internal_storage` — `unknown`
- **sensor.sebastian_wall_display_ipv6_addresses** — `sensor.sebastian_wall_display_ipv6_addresses` — `unknown`
- **sensor.sebastian_wall_display_last_notification** — `sensor.sebastian_wall_display_last_notification` — `unknown`
- **sensor.sebastian_wall_display_last_reboot** — `sensor.sebastian_wall_display_last_reboot` — `unknown`
- **sensor.sebastian_wall_display_last_removed_notification** — `sensor.sebastian_wall_display_last_removed_notification` — `unknown`
- **sensor.sebastian_wall_display_last_update_trigger** — `sensor.sebastian_wall_display_last_update_trigger` — `unknown`
- **sensor.sebastian_wall_display_last_used_app** — `sensor.sebastian_wall_display_last_used_app` — `unknown`
- **sensor.sebastian_wall_display_media_session** — `sensor.sebastian_wall_display_media_session` — `unknown`
- **sensor.sebastian_wall_display_network_type** — `sensor.sebastian_wall_display_network_type` — `unknown`
- **sensor.sebastian_wall_display_next_alarm** — `sensor.sebastian_wall_display_next_alarm` — `unknown`
- **sensor.sebastian_wall_display_os_version** — `sensor.sebastian_wall_display_os_version` — `unknown`
- **sensor.sebastian_wall_display_public_ip_address** — `sensor.sebastian_wall_display_public_ip_address` — `unknown`
- **sensor.sebastian_wall_display_ringer_mode** — `sensor.sebastian_wall_display_ringer_mode` — `unknown`
- **sensor.sebastian_wall_display_screen_brightness** — `sensor.sebastian_wall_display_screen_brightness` — `unknown`
- **sensor.sebastian_wall_display_screen_off_timeout** — `sensor.sebastian_wall_display_screen_off_timeout` — `unknown`
- **sensor.sebastian_wall_display_screen_orientation** — `sensor.sebastian_wall_display_screen_orientation` — `unknown`
- **sensor.sebastian_wall_display_screen_rotation** — `sensor.sebastian_wall_display_screen_rotation` — `unknown`
- **sensor.sebastian_wall_display_security_patch** — `sensor.sebastian_wall_display_security_patch` — `unknown`
- **sensor.sebastian_wall_display_sleep_confidence** — `sensor.sebastian_wall_display_sleep_confidence` — `unknown`
- **sensor.sebastian_wall_display_sleep_segment** — `sensor.sebastian_wall_display_sleep_segment` — `unknown`
- **sensor.sebastian_wall_display_total_rx_gb** — `sensor.sebastian_wall_display_total_rx_gb` — `unknown`
- **sensor.sebastian_wall_display_total_tx_gb** — `sensor.sebastian_wall_display_total_tx_gb` — `unknown`
- **sensor.sebastian_wall_display_volume_level_accessibility** — `sensor.sebastian_wall_display_volume_level_accessibility` — `unknown`
- **sensor.sebastian_wall_display_volume_level_alarm** — `sensor.sebastian_wall_display_volume_level_alarm` — `unknown`
- **sensor.sebastian_wall_display_volume_level_call** — `sensor.sebastian_wall_display_volume_level_call` — `unknown`
- **sensor.sebastian_wall_display_volume_level_dtmf** — `sensor.sebastian_wall_display_volume_level_dtmf` — `unknown`
- **sensor.sebastian_wall_display_volume_level_music** — `sensor.sebastian_wall_display_volume_level_music` — `unknown`
- **sensor.sebastian_wall_display_volume_level_notification** — `sensor.sebastian_wall_display_volume_level_notification` — `unknown`
- **sensor.sebastian_wall_display_volume_level_ringer** — `sensor.sebastian_wall_display_volume_level_ringer` — `unknown`
- **sensor.sebastian_wall_display_volume_level_system** — `sensor.sebastian_wall_display_volume_level_system` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_bssid** — `sensor.sebastian_wall_display_wi_fi_bssid` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_connection** — `sensor.sebastian_wall_display_wi_fi_connection` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_frequency** — `sensor.sebastian_wall_display_wi_fi_frequency` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_ip_address** — `sensor.sebastian_wall_display_wi_fi_ip_address` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_link_speed** — `sensor.sebastian_wall_display_wi_fi_link_speed` — `unknown`
- **sensor.sebastian_wall_display_wi_fi_signal_strength** — `sensor.sebastian_wall_display_wi_fi_signal_strength` — `unknown`
- **Sebastians iPad Batteri** — `sensor.sebastians_ipad_batteri` — `unavailable`
- **sensor.silicon_labs_flasher_cpu_procent** — `sensor.silicon_labs_flasher_cpu_procent` — `unknown`
- **sensor.silicon_labs_flasher_hukommelsesprocent** — `sensor.silicon_labs_flasher_hukommelsesprocent` — `unknown`
- **sensor.silicon_labs_flasher_nyeste_version** — `sensor.silicon_labs_flasher_nyeste_version` — `unknown`
- **sensor.silicon_labs_flasher_version** — `sensor.silicon_labs_flasher_version` — `unknown`
- **sensor.silicon_labs_multiprotocol_cpu_procent** — `sensor.silicon_labs_multiprotocol_cpu_procent` — `unknown`
- **sensor.silicon_labs_multiprotocol_hukommelsesprocent** — `sensor.silicon_labs_multiprotocol_hukommelsesprocent` — `unknown`
- **sensor.silicon_labs_multiprotocol_nyeste_version** — `sensor.silicon_labs_multiprotocol_nyeste_version` — `unknown`
- **sensor.silicon_labs_multiprotocol_version** — `sensor.silicon_labs_multiprotocol_version` — `unknown`
- **Silke Dinesen Philip - iPad Batteri** — `sensor.silke_dinesen_philip_ipad_batteri` — `unavailable`
- **Sirblondiedk iPhone Activity** — `sensor.sirblondiedk_iphone_activity` — `Stationary`
- **Sirblondiedk iPhone App Version** — `sensor.sirblondiedk_iphone_app_version` — `2026.6.0`
- **Sirblondiedk iPhone Audio Output** — `sensor.sirblondiedk_iphone_audio_output` — `Built-in Speaker`
- **Sirblondiedk iPhone Average Active Pace** — `sensor.sirblondiedk_iphone_average_active_pace` — `0`
- **Sirblondiedk iPhone Batteri** — `sensor.sirblondiedk_iphone_batteri` — `unavailable`
- **Sirblondiedk iPhone Battery Level** — `sensor.sirblondiedk_iphone_battery_level` — `50`
- **Sirblondiedk iPhone Battery State** — `sensor.sirblondiedk_iphone_battery_state` — `Not Charging`
- **Sirblondiedk iPhone BSSID** — `sensor.sirblondiedk_iphone_bssid` — `cc:32:e5:3b:b3:8f`
- **Sirblondiedk iPhone Connection Type** — `sensor.sirblondiedk_iphone_connection_type` — `Wi-Fi`
- **Sirblondiedk iPhone Distance** — `sensor.sirblondiedk_iphone_distance` — `1900`
- **Sirblondiedk iPhone Floors Ascended** — `sensor.sirblondiedk_iphone_floors_ascended` — `0`
- **Sirblondiedk iPhone Floors Descended** — `sensor.sirblondiedk_iphone_floors_descended` — `0`
- **Sirblondiedk iPhone Geocoded Location** — `sensor.sirblondiedk_iphone_geocoded_location` — `Podersvej 16
6622 Bække
Danmark`
- **Sirblondiedk iPhone Last Update Trigger** — `sensor.sirblondiedk_iphone_last_update_trigger` — `Signaled`
- **Sirblondiedk iPhone Location permission** — `sensor.sirblondiedk_iphone_location_permission` — `Authorized Always`
- **Sirblondiedk iPhone Pressure** — `sensor.sirblondiedk_iphone_pressure` — `1007.99`
- **Sirblondiedk iPhone SIM 1** — `sensor.sirblondiedk_iphone_sim_1` — `--`
- **Sirblondiedk iPhone SIM 2** — `sensor.sirblondiedk_iphone_sim_2` — `--`
- **Sirblondiedk iPhone SSID** — `sensor.sirblondiedk_iphone_ssid` — `Det lille hjem`
- **Sirblondiedk iPhone Steps** — `sensor.sirblondiedk_iphone_steps` — `2067`
- **Sirblondiedk iPhone Storage** — `sensor.sirblondiedk_iphone_storage` — `0.99`
- **Sirblondiedk iPhone Watch Battery** — `sensor.sirblondiedk_iphone_watch_battery` — `100`
- **Sirblondiedk iPhone Watch Battery State** — `sensor.sirblondiedk_iphone_watch_battery_state` — `Full`
- **Sofia Dinesen Philip - iPhone Activity** — `sensor.sofia_dinesen_philip_iphone_activity` — `Unknown`
- **Sofia Dinesen Philip - iPhone Average Active Pace** — `sensor.sofia_dinesen_philip_iphone_average_active_pace` — `1`
- **Sofia Iphone** — `sensor.sofia_dinesen_philip_iphone_batteri` — `unavailable`
- **Sofia Dinesen Philip - iPhone Battery Level** — `sensor.sofia_dinesen_philip_iphone_battery_level` — `100`
- **Sofia Dinesen Philip - iPhone Battery State** — `sensor.sofia_dinesen_philip_iphone_battery_state` — `Not Charging`
- **Sofia Dinesen Philip - iPhone BSSID** — `sensor.sofia_dinesen_philip_iphone_bssid` — `Not Connected`
- **Sofia Dinesen Philip - iPhone Connection Type** — `sensor.sofia_dinesen_philip_iphone_connection_type` — `Cellular`
- **Sofia Dinesen Philip - iPhone Distance** — `sensor.sofia_dinesen_philip_iphone_distance` — `134`
- **Sofia Dinesen Philip - iPhone Floors Ascended** — `sensor.sofia_dinesen_philip_iphone_floors_ascended` — `0`
- **Sofia Dinesen Philip - iPhone Floors Descended** — `sensor.sofia_dinesen_philip_iphone_floors_descended` — `0`
- **Sofia Dinesen Philip - iPhone Geocoded Location** — `sensor.sofia_dinesen_philip_iphone_geocoded_location` — `Møllevej 34
6622 Bække
Danmark`
- **Sofia Dinesen Philip - iPhone Last Update Trigger** — `sensor.sofia_dinesen_philip_iphone_last_update_trigger` — `Launch`
- **Sofia Dinesen Philip - iPhone SIM 1** — `sensor.sofia_dinesen_philip_iphone_sim_1` — `--`
- **Sofia Dinesen Philip - iPhone SIM 2** — `sensor.sofia_dinesen_philip_iphone_sim_2` — `--`
- **Sofia Dinesen Philip - iPhone SSID** — `sensor.sofia_dinesen_philip_iphone_ssid` — `Not Connected`
- **Sofia Dinesen Philip - iPhone Steps** — `sensor.sofia_dinesen_philip_iphone_steps` — `196`
- **Sofia Dinesen Philip - iPhone Storage** — `sensor.sofia_dinesen_philip_iphone_storage` — `37.26`
- **sensor.sofia_wall_display_active_notification_count** — `sensor.sofia_wall_display_active_notification_count` — `unknown`
- **sensor.sofia_wall_display_app_importance** — `sensor.sofia_wall_display_app_importance` — `unknown`
- **sensor.sofia_wall_display_app_memory** — `sensor.sofia_wall_display_app_memory` — `unknown`
- **sensor.sofia_wall_display_app_rx_gb** — `sensor.sofia_wall_display_app_rx_gb` — `unknown`
- **sensor.sofia_wall_display_app_tx_gb** — `sensor.sofia_wall_display_app_tx_gb` — `unknown`
- **sensor.sofia_wall_display_audio_mode** — `sensor.sofia_wall_display_audio_mode` — `unknown`
- **sensor.sofia_wall_display_battery_health** — `sensor.sofia_wall_display_battery_health` — `unknown`
- **Sofia wall display  Battery level** — `sensor.sofia_wall_display_battery_level` — `100`
- **sensor.sofia_wall_display_battery_power** — `sensor.sofia_wall_display_battery_power` — `unknown`
- **Sofia wall display  Battery state** — `sensor.sofia_wall_display_battery_state` — `full`
- **sensor.sofia_wall_display_battery_temperature** — `sensor.sofia_wall_display_battery_temperature` — `unknown`
- **sensor.sofia_wall_display_beacon_monitor** — `sensor.sofia_wall_display_beacon_monitor` — `unknown`
- **sensor.sofia_wall_display_ble_transmitter** — `sensor.sofia_wall_display_ble_transmitter` — `unknown`
- **sensor.sofia_wall_display_bluetooth_connection** — `sensor.sofia_wall_display_bluetooth_connection` — `unknown`
- **sensor.sofia_wall_display_car_battery** — `sensor.sofia_wall_display_car_battery` — `unknown`
- **sensor.sofia_wall_display_car_charging_status** — `sensor.sofia_wall_display_car_charging_status` — `unknown`
- **sensor.sofia_wall_display_car_ev_connector_type** — `sensor.sofia_wall_display_car_ev_connector_type` — `unknown`
- **sensor.sofia_wall_display_car_fuel** — `sensor.sofia_wall_display_car_fuel` — `unknown`
- **sensor.sofia_wall_display_car_fuel_type** — `sensor.sofia_wall_display_car_fuel_type` — `unknown`
- **sensor.sofia_wall_display_car_name** — `sensor.sofia_wall_display_car_name` — `unknown`
- **sensor.sofia_wall_display_car_odometer** — `sensor.sofia_wall_display_car_odometer` — `unknown`
- **sensor.sofia_wall_display_car_range_remaining** — `sensor.sofia_wall_display_car_range_remaining` — `unknown`
- **sensor.sofia_wall_display_car_speed** — `sensor.sofia_wall_display_car_speed` — `unknown`
- **Sofia wall display  Charger type** — `sensor.sofia_wall_display_charger_type` — `ac`
- **sensor.sofia_wall_display_current_time_zone** — `sensor.sofia_wall_display_current_time_zone` — `unknown`
- **sensor.sofia_wall_display_current_version** — `sensor.sofia_wall_display_current_version` — `unknown`
- **sensor.sofia_wall_display_detected_activity** — `sensor.sofia_wall_display_detected_activity` — `unknown`
- **sensor.sofia_wall_display_do_not_disturb_sensor** — `sensor.sofia_wall_display_do_not_disturb_sensor` — `unknown`
- **sensor.sofia_wall_display_external_storage** — `sensor.sofia_wall_display_external_storage` — `unknown`
- **sensor.sofia_wall_display_geocoded_location** — `sensor.sofia_wall_display_geocoded_location` — `unknown`
- **sensor.sofia_wall_display_high_accuracy_update_interval** — `sensor.sofia_wall_display_high_accuracy_update_interval` — `unknown`
- **sensor.sofia_wall_display_internal_storage** — `sensor.sofia_wall_display_internal_storage` — `unknown`
- **sensor.sofia_wall_display_ipv6_addresses** — `sensor.sofia_wall_display_ipv6_addresses` — `unknown`
- **sensor.sofia_wall_display_last_notification** — `sensor.sofia_wall_display_last_notification` — `unknown`
- **sensor.sofia_wall_display_last_reboot** — `sensor.sofia_wall_display_last_reboot` — `unknown`
- **sensor.sofia_wall_display_last_removed_notification** — `sensor.sofia_wall_display_last_removed_notification` — `unknown`
- **sensor.sofia_wall_display_last_update_trigger** — `sensor.sofia_wall_display_last_update_trigger` — `unknown`
- **sensor.sofia_wall_display_last_used_app** — `sensor.sofia_wall_display_last_used_app` — `unknown`
- **sensor.sofia_wall_display_media_session** — `sensor.sofia_wall_display_media_session` — `unknown`
- **sensor.sofia_wall_display_network_type** — `sensor.sofia_wall_display_network_type` — `unknown`
- **sensor.sofia_wall_display_next_alarm** — `sensor.sofia_wall_display_next_alarm` — `unknown`
- **sensor.sofia_wall_display_os_version** — `sensor.sofia_wall_display_os_version` — `unknown`
- **sensor.sofia_wall_display_public_ip_address** — `sensor.sofia_wall_display_public_ip_address` — `unknown`
- **sensor.sofia_wall_display_ringer_mode** — `sensor.sofia_wall_display_ringer_mode` — `unknown`
- **sensor.sofia_wall_display_screen_brightness** — `sensor.sofia_wall_display_screen_brightness` — `unknown`
- **sensor.sofia_wall_display_screen_off_timeout** — `sensor.sofia_wall_display_screen_off_timeout` — `unknown`
- **sensor.sofia_wall_display_screen_orientation** — `sensor.sofia_wall_display_screen_orientation` — `unknown`
- **sensor.sofia_wall_display_screen_rotation** — `sensor.sofia_wall_display_screen_rotation` — `unknown`
- **sensor.sofia_wall_display_security_patch** — `sensor.sofia_wall_display_security_patch` — `unknown`
- **sensor.sofia_wall_display_sleep_confidence** — `sensor.sofia_wall_display_sleep_confidence` — `unknown`
- **sensor.sofia_wall_display_sleep_segment** — `sensor.sofia_wall_display_sleep_segment` — `unknown`
- **sensor.sofia_wall_display_total_rx_gb** — `sensor.sofia_wall_display_total_rx_gb` — `unknown`
- **sensor.sofia_wall_display_total_tx_gb** — `sensor.sofia_wall_display_total_tx_gb` — `unknown`
- **sensor.sofia_wall_display_volume_level_accessibility** — `sensor.sofia_wall_display_volume_level_accessibility` — `unknown`
- **sensor.sofia_wall_display_volume_level_alarm** — `sensor.sofia_wall_display_volume_level_alarm` — `unknown`
- **sensor.sofia_wall_display_volume_level_call** — `sensor.sofia_wall_display_volume_level_call` — `unknown`
- **sensor.sofia_wall_display_volume_level_dtmf** — `sensor.sofia_wall_display_volume_level_dtmf` — `unknown`
- **sensor.sofia_wall_display_volume_level_music** — `sensor.sofia_wall_display_volume_level_music` — `unknown`
- **sensor.sofia_wall_display_volume_level_notification** — `sensor.sofia_wall_display_volume_level_notification` — `unknown`
- **sensor.sofia_wall_display_volume_level_ringer** — `sensor.sofia_wall_display_volume_level_ringer` — `unknown`
- **sensor.sofia_wall_display_volume_level_system** — `sensor.sofia_wall_display_volume_level_system` — `unknown`
- **sensor.sofia_wall_display_wi_fi_bssid** — `sensor.sofia_wall_display_wi_fi_bssid` — `unknown`
- **sensor.sofia_wall_display_wi_fi_connection** — `sensor.sofia_wall_display_wi_fi_connection` — `unknown`
- **sensor.sofia_wall_display_wi_fi_frequency** — `sensor.sofia_wall_display_wi_fi_frequency` — `unknown`
- **sensor.sofia_wall_display_wi_fi_ip_address** — `sensor.sofia_wall_display_wi_fi_ip_address` — `unknown`
- **sensor.sofia_wall_display_wi_fi_link_speed** — `sensor.sofia_wall_display_wi_fi_link_speed` — `unknown`
- **sensor.sofia_wall_display_wi_fi_signal_strength** — `sensor.sofia_wall_display_wi_fi_signal_strength` — `unknown`
- **sensor.spotify_bent_christiansen_song_acousticness** — `sensor.spotify_bent_christiansen_song_acousticness` — `unknown`
- **sensor.spotify_bent_christiansen_song_danceability** — `sensor.spotify_bent_christiansen_song_danceability` — `unknown`
- **sensor.spotify_bent_christiansen_song_energy** — `sensor.spotify_bent_christiansen_song_energy` — `unknown`
- **sensor.spotify_bent_christiansen_song_instrumentalness** — `sensor.spotify_bent_christiansen_song_instrumentalness` — `unknown`
- **sensor.spotify_bent_christiansen_song_key** — `sensor.spotify_bent_christiansen_song_key` — `unknown`
- **sensor.spotify_bent_christiansen_song_liveness** — `sensor.spotify_bent_christiansen_song_liveness` — `unknown`
- **sensor.spotify_bent_christiansen_song_mode** — `sensor.spotify_bent_christiansen_song_mode` — `unknown`
- **sensor.spotify_bent_christiansen_song_speechiness** — `sensor.spotify_bent_christiansen_song_speechiness` — `unknown`
- **Spotify Bent Christiansen Song tempo** — `sensor.spotify_bent_christiansen_song_tempo` — `unavailable`
- **sensor.spotify_bent_christiansen_song_time_signature** — `sensor.spotify_bent_christiansen_song_time_signature` — `unknown`
- **sensor.spotify_bent_christiansen_song_valence** — `sensor.spotify_bent_christiansen_song_valence` — `unknown`
- **sensor.studio_code_server_cpu_procent** — `sensor.studio_code_server_cpu_procent` — `unknown`
- **sensor.studio_code_server_hukommelsesprocent** — `sensor.studio_code_server_hukommelsesprocent` — `unknown`
- **sensor.studio_code_server_nyeste_version** — `sensor.studio_code_server_nyeste_version` — `unknown`
- **sensor.studio_code_server_version** — `sensor.studio_code_server_version` — `unknown`
- **Sun Næste daggry** — `sensor.sun_next_dawn` — `2026-07-05T01:49:27+00:00`
- **Sun Næste skumring** — `sensor.sun_next_dusk` — `2026-07-05T21:05:41+00:00`
- **Sun Næste midnat** — `sensor.sun_next_midnight` — `2026-07-04T23:28:04+00:00`
- **Sun Næste middag** — `sensor.sun_next_noon` — `2026-07-05T11:27:58+00:00`
- **Sun Næste solopgang** — `sensor.sun_next_rising` — `2026-07-05T02:49:01+00:00`
- **Sun Næste solnedgang** — `sensor.sun_next_setting` — `2026-07-05T20:06:29+00:00`
- **sensor.sun_solar_azimuth** — `sensor.sun_solar_azimuth` — `unknown`
- **sensor.sun_solar_elevation** — `sensor.sun_solar_elevation` — `unknown`
- **sensor.tabet_stue_active_notification_count** — `sensor.tabet_stue_active_notification_count` — `unknown`
- **sensor.tabet_stue_app_importance** — `sensor.tabet_stue_app_importance` — `unknown`
- **sensor.tabet_stue_app_memory** — `sensor.tabet_stue_app_memory` — `unknown`
- **sensor.tabet_stue_app_rx_gb** — `sensor.tabet_stue_app_rx_gb` — `unknown`
- **sensor.tabet_stue_app_tx_gb** — `sensor.tabet_stue_app_tx_gb` — `unknown`
- **sensor.tabet_stue_audio_mode** — `sensor.tabet_stue_audio_mode` — `unknown`
- **sensor.tabet_stue_battery_health** — `sensor.tabet_stue_battery_health` — `unknown`
- **Tabet stue Battery level** — `sensor.tabet_stue_battery_level` — `100`
- **sensor.tabet_stue_battery_power** — `sensor.tabet_stue_battery_power` — `unknown`
- **Tabet stue Battery state** — `sensor.tabet_stue_battery_state` — `full`
- **sensor.tabet_stue_battery_temperature** — `sensor.tabet_stue_battery_temperature` — `unknown`
- **sensor.tabet_stue_beacon_monitor** — `sensor.tabet_stue_beacon_monitor` — `unknown`
- **sensor.tabet_stue_ble_transmitter** — `sensor.tabet_stue_ble_transmitter` — `unknown`
- **sensor.tabet_stue_bluetooth_connection** — `sensor.tabet_stue_bluetooth_connection` — `unknown`
- **sensor.tabet_stue_car_battery** — `sensor.tabet_stue_car_battery` — `unknown`
- **sensor.tabet_stue_car_charging_status** — `sensor.tabet_stue_car_charging_status` — `unknown`
- **sensor.tabet_stue_car_ev_connector_type** — `sensor.tabet_stue_car_ev_connector_type` — `unknown`
- **sensor.tabet_stue_car_fuel** — `sensor.tabet_stue_car_fuel` — `unknown`
- **sensor.tabet_stue_car_fuel_type** — `sensor.tabet_stue_car_fuel_type` — `unknown`
- **sensor.tabet_stue_car_name** — `sensor.tabet_stue_car_name` — `unknown`
- **sensor.tabet_stue_car_odometer** — `sensor.tabet_stue_car_odometer` — `unknown`
- **sensor.tabet_stue_car_range_remaining** — `sensor.tabet_stue_car_range_remaining` — `unknown`
- **sensor.tabet_stue_car_speed** — `sensor.tabet_stue_car_speed` — `unknown`
- **Tabet stue Charger type** — `sensor.tabet_stue_charger_type` — `ac`
- **sensor.tabet_stue_current_time_zone** — `sensor.tabet_stue_current_time_zone` — `unknown`
- **sensor.tabet_stue_current_version** — `sensor.tabet_stue_current_version` — `unknown`
- **sensor.tabet_stue_detected_activity** — `sensor.tabet_stue_detected_activity` — `unknown`
- **sensor.tabet_stue_do_not_disturb_sensor** — `sensor.tabet_stue_do_not_disturb_sensor` — `unknown`
- **sensor.tabet_stue_external_storage** — `sensor.tabet_stue_external_storage` — `unknown`
- **sensor.tabet_stue_geocoded_location** — `sensor.tabet_stue_geocoded_location` — `unknown`
- **sensor.tabet_stue_high_accuracy_update_interval** — `sensor.tabet_stue_high_accuracy_update_interval` — `unknown`
- **sensor.tabet_stue_internal_storage** — `sensor.tabet_stue_internal_storage` — `unknown`
- **sensor.tabet_stue_ipv6_addresses** — `sensor.tabet_stue_ipv6_addresses` — `unknown`
- **sensor.tabet_stue_last_notification** — `sensor.tabet_stue_last_notification` — `unknown`
- **sensor.tabet_stue_last_reboot** — `sensor.tabet_stue_last_reboot` — `unknown`
- **sensor.tabet_stue_last_removed_notification** — `sensor.tabet_stue_last_removed_notification` — `unknown`
- **sensor.tabet_stue_last_update_trigger** — `sensor.tabet_stue_last_update_trigger` — `unknown`
- **sensor.tabet_stue_last_used_app** — `sensor.tabet_stue_last_used_app` — `unknown`
- **sensor.tabet_stue_media_session** — `sensor.tabet_stue_media_session` — `unknown`
- **sensor.tabet_stue_network_type** — `sensor.tabet_stue_network_type` — `unknown`
- **sensor.tabet_stue_next_alarm** — `sensor.tabet_stue_next_alarm` — `unknown`
- **sensor.tabet_stue_os_version** — `sensor.tabet_stue_os_version` — `unknown`
- **sensor.tabet_stue_public_ip_address** — `sensor.tabet_stue_public_ip_address` — `unknown`
- **sensor.tabet_stue_ringer_mode** — `sensor.tabet_stue_ringer_mode` — `unknown`
- **sensor.tabet_stue_screen_brightness** — `sensor.tabet_stue_screen_brightness` — `unknown`
- **sensor.tabet_stue_screen_off_timeout** — `sensor.tabet_stue_screen_off_timeout` — `unknown`
- **sensor.tabet_stue_screen_orientation** — `sensor.tabet_stue_screen_orientation` — `unknown`
- **sensor.tabet_stue_screen_rotation** — `sensor.tabet_stue_screen_rotation` — `unknown`
- **sensor.tabet_stue_security_patch** — `sensor.tabet_stue_security_patch` — `unknown`
- **sensor.tabet_stue_sleep_confidence** — `sensor.tabet_stue_sleep_confidence` — `unknown`
- **sensor.tabet_stue_sleep_segment** — `sensor.tabet_stue_sleep_segment` — `unknown`
- **sensor.tabet_stue_total_rx_gb** — `sensor.tabet_stue_total_rx_gb` — `unknown`
- **sensor.tabet_stue_total_tx_gb** — `sensor.tabet_stue_total_tx_gb` — `unknown`
- **sensor.tabet_stue_volume_level_accessibility** — `sensor.tabet_stue_volume_level_accessibility` — `unknown`
- **sensor.tabet_stue_volume_level_alarm** — `sensor.tabet_stue_volume_level_alarm` — `unknown`
- **sensor.tabet_stue_volume_level_call** — `sensor.tabet_stue_volume_level_call` — `unknown`
- **sensor.tabet_stue_volume_level_dtmf** — `sensor.tabet_stue_volume_level_dtmf` — `unknown`
- **sensor.tabet_stue_volume_level_music** — `sensor.tabet_stue_volume_level_music` — `unknown`
- **sensor.tabet_stue_volume_level_notification** — `sensor.tabet_stue_volume_level_notification` — `unknown`
- **sensor.tabet_stue_volume_level_ringer** — `sensor.tabet_stue_volume_level_ringer` — `unknown`
- **sensor.tabet_stue_volume_level_system** — `sensor.tabet_stue_volume_level_system` — `unknown`
- **sensor.tabet_stue_wifi_bssid** — `sensor.tabet_stue_wifi_bssid` — `unknown`
- **sensor.tabet_stue_wifi_connection** — `sensor.tabet_stue_wifi_connection` — `unknown`
- **sensor.tabet_stue_wifi_frequency** — `sensor.tabet_stue_wifi_frequency` — `unknown`
- **sensor.tabet_stue_wifi_ip_address** — `sensor.tabet_stue_wifi_ip_address` — `unknown`
- **sensor.tabet_stue_wifi_link_speed** — `sensor.tabet_stue_wifi_link_speed` — `unknown`
- **sensor.tabet_stue_wifi_signal_strength** — `sensor.tabet_stue_wifi_signal_strength` — `unknown`
- **sensor.terminal_ssh_cpu_procent** — `sensor.terminal_ssh_cpu_procent` — `unknown`
- **sensor.terminal_ssh_hukommelsesprocent** — `sensor.terminal_ssh_hukommelsesprocent` — `unknown`
- **sensor.terminal_ssh_nyeste_version** — `sensor.terminal_ssh_nyeste_version` — `unknown`
- **sensor.terminal_ssh_version** — `sensor.terminal_ssh_version` — `unknown`
- **sensor.veerst_baekke_bornehave_mollebo_silke** — `sensor.veerst_baekke_bornehave_mollebo_silke` — `unknown`
- **XPED-0060370B54C3 Estimated distance** — `sensor.xped_0060370b54c3_estimated_distance` — `unavailable`
- **sensor.xped_0060370b54c3_power** — `sensor.xped_0060370b54c3_power` — `unknown`
- **sensor.xped_0060370b54c3_signalstyrke** — `sensor.xped_0060370b54c3_signalstyrke` — `unknown`
- **sensor.xped_0060370b54c3_vendor** — `sensor.xped_0060370b54c3_vendor` — `unknown`
- **sensor.zigbee2mqtt_bridge_coordinator_version** — `sensor.zigbee2mqtt_bridge_coordinator_version` — `unknown`
- **sensor.zigbee2mqtt_bridge_network_map** — `sensor.zigbee2mqtt_bridge_network_map` — `unknown`
- **Zigbee2MQTT Bridge Version** — `sensor.zigbee2mqtt_bridge_version` — `2.9.2`

## stt

- **Google AI STT** — `stt.google_ai_stt` — `unknown`
- **Home Assistant Cloud** — `stt.home_assistant_cloud` — `unknown`
- **OpenAI STT** — `stt.openai_stt` — `unknown`

## switch

- **switch.adano_robotic_mower_pre_release** — `switch.adano_robotic_mower_pre_release` — `unknown`
- **switch.adaptive_lighting_pre_release** — `switch.adaptive_lighting_pre_release` — `unknown`
- **switch.atomic_calendar_revive_pre_release** — `switch.atomic_calendar_revive_pre_release` — `unknown`
- **switch.aula_pre_release** — `switch.aula_pre_release` — `unknown`
- **switch.bubble_card_pre_release** — `switch.bubble_card_pre_release` — `unknown`
- **switch.button_card_pre_release** — `switch.button_card_pre_release` — `unknown`
- **switch.card_mod_pre_release** — `switch.card_mod_pre_release` — `unknown`
- **switch.continuously_casting_dashboard_pre_release** — `switch.continuously_casting_dashboard_pre_release` — `unknown`
- **switch.dwains_dashboard_pre_release** — `switch.dwains_dashboard_pre_release` — `unknown`
- **switch.file_editor** — `switch.file_editor` — `unknown`
- **switch.frigate** — `switch.frigate` — `unknown`
- **switch.frigate_pre_release** — `switch.frigate_pre_release` — `unknown`
- **switch.google_assistant_sdk_custom_pre_release** — `switch.google_assistant_sdk_custom_pre_release` — `unknown`
- **switch.group_element_pre_release** — `switch.group_element_pre_release` — `unknown`
- **switch.ha_floorplan_your_imagination_almost_defines_the_limits_pre_release** — `switch.ha_floorplan_your_imagination_almost_defines_the_limits_pre_release` — `unknown`
- **switch.hacs_pre_release** — `switch.hacs_pre_release` — `unknown`
- **switch.hikvision_nvr_ip_camera_pre_release** — `switch.hikvision_nvr_ip_camera_pre_release` — `unknown`
- **switch.home_assistant_matter_hub** — `switch.home_assistant_matter_hub` — `unknown`
- **switch.home_assistant_skyconnect_9650e525_beta_firmware_updates** — `switch.home_assistant_skyconnect_9650e525_beta_firmware_updates` — `unknown`
- **Indkorelse Detect** — `switch.indkorelse_detect` — `on`
- **switch.indkorelse_improve_contrast** — `switch.indkorelse_improve_contrast` — `unknown`
- **Indkorelse Motion** — `switch.indkorelse_motion` — `on`
- **switch.indkorelse_object_descriptions** — `switch.indkorelse_object_descriptions` — `unknown`
- **Indkorelse Recordings** — `switch.indkorelse_recordings` — `on`
- **Indkorelse Review Alerts** — `switch.indkorelse_review_alerts` — `on`
- **switch.indkorelse_review_descriptions** — `switch.indkorelse_review_descriptions` — `unknown`
- **Indkorelse Review Detections** — `switch.indkorelse_review_detections` — `on`
- **Indkorelse Snapshots** — `switch.indkorelse_snapshots` — `on`
- **køkken spot 1 Do not disturb** — `switch.kokken_spot_1_do_not_disturb` — `off`
- **Køkken spot 2 Do not disturb** — `switch.kokken_spot_2_do_not_disturb` — `off`
- **Køkken spot 3 Do not disturb** — `switch.kokken_spot_3_do_not_disturb` — `off`
- **lampe de små pære 1 Do not disturb** — `switch.lampe_de_sma_paere_1_do_not_disturb` — `off`
- **lampe de små pære 2 Do not disturb** — `switch.lampe_de_sma_paere_2_do_not_disturb` — `off`
- **lampe de små pære 3 Do not disturb** — `switch.lampe_de_sma_paere_3_do_not_disturb` — `off`
- **switch.layout_card_pre_release** — `switch.layout_card_pre_release` — `unknown`
- **switch.local_tuya_pre_release** — `switch.local_tuya_pre_release` — `unknown`
- **switch.lovelace_home_feed_card_pre_release** — `switch.lovelace_home_feed_card_pre_release` — `unknown`
- **switch.mosquitto_broker** — `switch.mosquitto_broker` — `unknown`
- **switch.mqtt_explorer** — `switch.mqtt_explorer` — `unknown`
- **switch.mushroom_pre_release** — `switch.mushroom_pre_release` — `unknown`
- **switch.music_assistant_server** — `switch.music_assistant_server` — `unknown`
- **switch.node_red** — `switch.node_red` — `unknown`
- **switch.silicon_labs_flasher** — `switch.silicon_labs_flasher` — `unknown`
- **switch.silicon_labs_multiprotocol** — `switch.silicon_labs_multiprotocol` — `unknown`
- **switch.studio_code_server** — `switch.studio_code_server` — `unknown`
- **switch.tapo_cameras_control_pre_release** — `switch.tapo_cameras_control_pre_release` — `unknown`
- **switch.terminal_ssh** — `switch.terminal_ssh` — `unknown`
- **switch.themable_grid_pre_release** — `switch.themable_grid_pre_release` — `unknown`
- **switch.tp_link_deco_pre_release** — `switch.tp_link_deco_pre_release` — `unknown`
- **Wake on LAN** — `switch.wake_on_lan` — `off`
- **switch.week_planner_card_pre_release** — `switch.week_planner_card_pre_release` — `unknown`
- **Zigbee2MQTT Bridge Permit join** — `switch.zigbee2mqtt_bridge_permit_join` — `off`

## todo

- **Indkøbsliste** — `todo.indkobsliste` — `0`

## tts

- **Google AI TTS** — `tts.google_ai_tts` — `2026-03-02T03:07:54.381201+00:00`
- **Google Translate en com** — `tts.google_en_com` — `unknown`
- **Home Assistant Cloud** — `tts.home_assistant_cloud` — `unknown`
- **OpenAI TTS** — `tts.openai_tts` — `unknown`

## update

- **Adano robotic mower Update** — `update.adano_robotic_mower_update` — `off`
- **update.adaptive_lighting_update** — `update.adaptive_lighting_update` — `unknown`
- **Atomic Calendar Revive Update** — `update.atomic_calendar_revive_update` — `off`
- **Aula Update** — `update.aula_update` — `off`
- **Bubble Card Update** — `update.bubble_card_update` — `off`
- **button-card Update** — `update.button_card_update` — `off`
- **card-mod Update** — `update.card_mod_update` — `off`
- **Continuously Casting Dashboard Update** — `update.continuously_casting_dashboard_update` — `off`
- **Dwains Dashboard Update** — `update.dwains_dashboard_update` — `off`
- **File editor Opdatering** — `update.file_editor_update` — `off`
- **Frigate Opdatering** — `update.frigate_opdatering` — `off`
- **Frigate Server** — `update.frigate_server` — `on`
- **Frigate Update** — `update.frigate_update` — `off`
- **Google Assistant SDK Custom Update** — `update.google_assistant_sdk_custom_update` — `off`
- **Group Element Update** — `update.group_element_update` — `off`
- **ha-floorplan 🖌🎨 | Your imagination (almost) defines the limits Update** — `update.ha_floorplan_your_imagination_almost_defines_the_limits_update` — `off`
- **HACS Update** — `update.hacs_update` — `off`
- **Hikvision NVR / IP Camera Update** — `update.hikvision_nvr_ip_camera_update` — `off`
- **Home Assistant Core Opdatering** — `update.home_assistant_core_update` — `off`
- **Home-Assistant-Matter-Hub Opdatering** — `update.home_assistant_matter_hub_opdatering` — `off`
- **Home Assistant Operating System Opdatering** — `update.home_assistant_operating_system_update` — `off`
- **Home Assistant SkyConnect (9650e525) Firmware** — `update.home_assistant_skyconnect_9650e525_firmware` — `unknown`
- **Home Assistant Supervisor Opdatering** — `update.home_assistant_supervisor_update` — `off`
- **layout-card Update** — `update.layout_card_update` — `off`
- **Local Tuya Update** — `update.local_tuya_update` — `off`
- **Lovelace Home Feed Card Update** — `update.lovelace_home_feed_card_update` — `off`
- **Mosquitto broker Opdatering** — `update.mosquitto_broker_update` — `off`
- **MQTT Explorer Opdatering** — `update.mqtt_explorer_update` — `off`
- **Mushroom Update** — `update.mushroom_update` — `off`
- **Music Assistant Opdatering** — `update.music_assistant_server_update` — `off`
- **Node-RED Opdatering** — `update.node_red_update` — `off`
- **Silicon Labs Flasher Opdatering** — `update.silicon_labs_flasher_update` — `off`
- **Silicon Labs Multiprotocol Opdatering** — `update.silicon_labs_multiprotocol_update` — `off`
- **Studio Code Server Opdatering** — `update.studio_code_server_opdatering` — `off`
- **Tapo: Cameras Control Update** — `update.tapo_cameras_control_update` — `off`
- **Terminal & SSH Opdatering** — `update.terminal_ssh_update` — `off`
- **themable-grid Update** — `update.themable_grid_update` — `off`
- **TP-Link Deco Update** — `update.tp_link_deco_update` — `off`
- **Week planner card Update** — `update.week_planner_card_update` — `off`

## weather

- **Forecast Hjem** — `weather.forecast_hjem` — `cloudy`

## zone

- **Bække Skole** — `zone.baekke_skole` — `0`
- **Daglig Brugsen Bække** — `zone.daglig_brugsen_baekke` — `0`
- **Farmor's hus** — `zone.farmor_s_hus` — `0`
- **Hærvejshallen** — `zone.haervejshallen` — `0`
- **Hos Jim** — `zone.hos_jim` — `0`
- **Møllevang Børnehave** — `zone.mollevang_bornehave` — `0`
- **Sandersvig Camping** — `zone.sandersvig_camping` — `0`
