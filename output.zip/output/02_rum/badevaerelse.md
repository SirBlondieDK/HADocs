# Badeværelse

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Bevægelses sensor badeværelse Tilstedeværelse** — `binary_sensor.bevaegelses_sensor_badevaerelse_occupancy` — `off`

## button

- **Badeværelse Favorite current song** — `button.badevaerelse_favorite_current_song` — `unknown`

## light

- **Lys badeværelse** — `light.badevaerelse` — `off`
- **Badeværelse spot 1** — `light.badevaerelse_spot_1` — `off`
- **Badeværelse spot 2** — `light.badevaerelse_spot_2` — `off`
- **Badeværelse spot 3** — `light.badevaerelse_spot_3` — `off`
- **Badeværelse spot 4** — `light.badevaerelse_spot_4` — `off`
- **Badeværelse spot 5** — `light.badevaerelse_spot_5` — `off`

## media_player

- **Google Home Badeværelse** — `media_player.badevaerelse` — `off`
- **Badeværelse** — `media_player.badevaerelse_2` — `idle`

## number

- **Bevægelses sensor badeværelse Illuminance interval** — `number.bevaegelses_sensor_badevaerelse_illuminance_interval` — `60`

## select

- **select.0xe8ca50ddf96c0000_effect** — `select.0xe8ca50ddf96c0000_effect` — `unknown`
- **select.0xe8ca50de41110000_effect** — `select.0xe8ca50de41110000_effect` — `unknown`
- **select.0xe8ca50de7c1c0000_effect** — `select.0xe8ca50de7c1c0000_effect` — `unknown`
- **select.0xe8ca50deb78c0000_effect** — `select.0xe8ca50deb78c0000_effect` — `unknown`
- **Badeværelse spot 1 Color power on behavior** — `select.badevaerelse_spot_1_color_power_on_behavior` — `unknown`
- **Badeværelse spot 1 Power-on behavior** — `select.badevaerelse_spot_1_power_on_behavior` — `unknown`
- **Badeværelse spot 2 Color power on behavior** — `select.badevaerelse_spot_2_color_power_on_behavior` — `unknown`
- **Badeværelse spot 2 Power-on behavior** — `select.badevaerelse_spot_2_power_on_behavior` — `unknown`
- **Badeværelse spot 3 Color power on behavior** — `select.badevaerelse_spot_3_color_power_on_behavior` — `unknown`
- **select.badevaerelse_spot_3_effect** — `select.badevaerelse_spot_3_effect` — `unknown`
- **Badeværelse spot 3 Power-on behavior** — `select.badevaerelse_spot_3_power_on_behavior` — `unknown`
- **Badeværelse spot 4 Color power on behavior** — `select.badevaerelse_spot_4_color_power_on_behavior` — `unknown`
- **Badeværelse spot 4 Power-on behavior** — `select.badevaerelse_spot_4_power_on_behavior` — `unknown`
- **Badeværelse spot 5 Color power on behavior** — `select.badevaerelse_spot_5_color_power_on_behavior` — `unknown`
- **Badeværelse spot 5 Power-on behavior** — `select.badevaerelse_spot_5_power_on_behavior` — `unknown`
- **Bevægelses sensor badeværelse Keep time** — `select.bevaegelses_sensor_badevaerelse_keep_time` — `30`
- **Bevægelses sensor badeværelse Sensitivity** — `select.bevaegelses_sensor_badevaerelse_sensitivity` — `high`

## sensor

- **sensor.0xa4c138b01f675fef_last_seen** — `sensor.0xa4c138b01f675fef_last_seen` — `unknown`
- **sensor.0xa4c138b01f675fef_linkquality** — `sensor.0xa4c138b01f675fef_linkquality` — `unknown`
- **sensor.0xe8ca50ddf96c0000_last_seen** — `sensor.0xe8ca50ddf96c0000_last_seen` — `unknown`
- **sensor.0xe8ca50ddf96c0000_linkquality** — `sensor.0xe8ca50ddf96c0000_linkquality` — `unknown`
- **sensor.0xe8ca50de41110000_last_seen** — `sensor.0xe8ca50de41110000_last_seen` — `unknown`
- **sensor.0xe8ca50de41110000_linkquality** — `sensor.0xe8ca50de41110000_linkquality` — `unknown`
- **sensor.0xe8ca50de7c1c0000_last_seen** — `sensor.0xe8ca50de7c1c0000_last_seen` — `unknown`
- **sensor.0xe8ca50de7c1c0000_linkquality** — `sensor.0xe8ca50de7c1c0000_linkquality` — `unknown`
- **sensor.0xe8ca50deb78c0000_last_seen** — `sensor.0xe8ca50deb78c0000_last_seen` — `unknown`
- **sensor.0xe8ca50deb78c0000_linkquality** — `sensor.0xe8ca50deb78c0000_linkquality` — `unknown`
- **sensor.badevaerelse_spot_3_last_seen** — `sensor.badevaerelse_spot_3_last_seen` — `unknown`
- **sensor.badevaerelse_spot_3_linkquality** — `sensor.badevaerelse_spot_3_linkquality` — `unknown`
- **Bevægelses sensor badeværelse Batteri** — `sensor.bevaegelses_sensor_badevaerelse_battery` — `90`
- **Bevægelses sensor badeværelse Belysningsstyrke** — `sensor.bevaegelses_sensor_badevaerelse_illuminance` — `0`

## switch

- **Badeværelse spot 1 Do not disturb** — `switch.badevaerelse_spot_1_do_not_disturb` — `off`
- **Badeværelse spot 2 Do not disturb** — `switch.badevaerelse_spot_2_do_not_disturb` — `off`
- **Badeværelse spot 3 Do not disturb** — `switch.badevaerelse_spot_3_do_not_disturb` — `off`
- **Badeværelse spot 4 Do not disturb** — `switch.badevaerelse_spot_4_do_not_disturb` — `off`
- **Badeværelse spot 5 Do not disturb** — `switch.badevaerelse_spot_5_do_not_disturb` — `off`
