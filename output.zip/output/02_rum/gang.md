# Gang

Generated: 2026-07-05 00:57:13

## light

- **Lampe gang** — `light.lampe_gang` — `off`

## select

- **select.0xa4c1389de2ac12d0_effect** — `select.0xa4c1389de2ac12d0_effect` — `unknown`
- **Lampe gang Color power on behavior** — `select.lampe_gang_color_power_on_behavior` — `unknown`

## sensor

- **sensor.0xa4c1389de2ac12d0_last_seen** — `sensor.0xa4c1389de2ac12d0_last_seen` — `unknown`
- **sensor.0xa4c1389de2ac12d0_linkquality** — `sensor.0xa4c1389de2ac12d0_linkquality` — `unknown`

## switch

- **Lampe gang Do not disturb** — `switch.lampe_gang_do_not_disturb` — `off`
