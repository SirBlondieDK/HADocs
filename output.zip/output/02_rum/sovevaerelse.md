# Soveværelse

Generated: 2026-07-05 00:57:13

## automation

- **Kontakt Seng** — `automation.kontakt_sovevaerelse` — `on`

## binary_sensor

- **WLED Firmware** — `binary_sensor.wled_firmware_2` — `unavailable`

## button

- **Soveværelse hub Favorite current song** — `button.sovevaerelse_hub_favorite_current_song` — `unknown`
- **WLED Genstart** — `button.wled_genstart_2` — `unavailable`

## device_tracker

- **WLED Ledsove** — `device_tracker.kitchen_deco_ledsove` — `not_home`

## light

- **Loftlampe soveværelse** — `light.loftlampe_sovevaerelse` — `off`
- **Natlampe** — `light.natlampe` — `off`
- **Natlampe 2** — `light.natlampe_2` — `off`
- **WLED** — `light.wled_2` — `unavailable`
- **WLED Main** — `light.wled_main` — `unavailable`
- **WLED Segment 1** — `light.wled_segment_1` — `unavailable`
- **WLED Segment 2** — `light.wled_segment_2` — `unavailable`
- **WLED Segment 3** — `light.wled_segment_3` — `unavailable`
- **WLED Segment 4** — `light.wled_segment_4` — `unavailable`
- **WLED Segment 5** — `light.wled_segment_5` — `unavailable`
- **WLED Segment 6** — `light.wled_segment_6` — `unavailable`
- **WLED Segment 7** — `light.wled_segment_7` — `unavailable`

## media_player

- **Soveværelse** — `media_player.sovevaerelse` — `unavailable`
- **Soveværelse hub** — `media_player.sovevaerelse_hub` — `off`
- **Soveværelse hub** — `media_player.sovevaerelse_hub_2` — `idle`

## number

- **WLED Intensity** — `number.wled_intensity_2` — `unavailable`
- **WLED Segment 1 intensity** — `number.wled_segment_1_intensity` — `unavailable`
- **WLED Segment 1 speed** — `number.wled_segment_1_speed` — `unavailable`
- **WLED Segment 2 intensity** — `number.wled_segment_2_intensity` — `unavailable`
- **WLED Segment 2 speed** — `number.wled_segment_2_speed` — `unavailable`
- **WLED Segment 3 intensity** — `number.wled_segment_3_intensity` — `unavailable`
- **WLED Segment 3 speed** — `number.wled_segment_3_speed` — `unavailable`
- **WLED Segment 4 intensity** — `number.wled_segment_4_intensity` — `unavailable`
- **WLED Segment 4 speed** — `number.wled_segment_4_speed` — `unavailable`
- **WLED Segment 5 intensity** — `number.wled_segment_5_intensity` — `unavailable`
- **WLED Segment 5 speed** — `number.wled_segment_5_speed` — `unavailable`
- **WLED Segment 6 intensity** — `number.wled_segment_6_intensity` — `unavailable`
- **WLED Segment 6 speed** — `number.wled_segment_6_speed` — `unavailable`
- **WLED Segment 7 intensity** — `number.wled_segment_7_intensity` — `unavailable`
- **WLED Segment 7 speed** — `number.wled_segment_7_speed` — `unavailable`
- **WLED Speed** — `number.wled_speed_2` — `unavailable`

## select

- **select.0xa4c1388d5e4bed62_effect** — `select.0xa4c1388d5e4bed62_effect` — `unknown`
- **select.0xe8ca50ddee080000_effect** — `select.0xe8ca50ddee080000_effect` — `unknown`
- **select.0xe8ca50de90a20000_effect** — `select.0xe8ca50de90a20000_effect` — `unknown`
- **Loftlampe soveværelse Color power on behavior** — `select.loftlampe_sovevaerelse_color_power_on_behavior` — `unknown`
- **Natlampe 2 Color power on behavior** — `select.natlampe_2_color_power_on_behavior` — `unknown`
- **Natlampe 2 Power-on behavior** — `select.natlampe_2_power_on_behavior` — `on`
- **Natlampe Color power on behavior** — `select.natlampe_color_power_on_behavior` — `unknown`
- **Natlampe Power-on behavior** — `select.natlampe_power_on_behavior` — `on`
- **WLED Color palette** — `select.wled_color_palette_2` — `unavailable`
- **WLED Live override** — `select.wled_live_override_2` — `unavailable`
- **WLED Playlist** — `select.wled_playlist_2` — `unavailable`
- **WLED Preset** — `select.wled_preset_2` — `unavailable`
- **WLED Segment 1 color palette** — `select.wled_segment_1_color_palette` — `unavailable`
- **WLED Segment 2 color palette** — `select.wled_segment_2_color_palette` — `unavailable`
- **WLED Segment 3 color palette** — `select.wled_segment_3_color_palette` — `unavailable`
- **WLED Segment 4 color palette** — `select.wled_segment_4_color_palette` — `unavailable`
- **WLED Segment 5 color palette** — `select.wled_segment_5_color_palette` — `unavailable`
- **WLED Segment 6 color palette** — `select.wled_segment_6_color_palette` — `unavailable`
- **WLED Segment 7 color palette** — `select.wled_segment_7_color_palette` — `unavailable`

## sensor

- **sensor.0xa4c1388d5e4bed62_last_seen** — `sensor.0xa4c1388d5e4bed62_last_seen` — `unknown`
- **sensor.0xa4c1388d5e4bed62_linkquality** — `sensor.0xa4c1388d5e4bed62_linkquality` — `unknown`
- **sensor.0xe8ca50ddee080000_last_seen** — `sensor.0xe8ca50ddee080000_last_seen` — `unknown`
- **sensor.0xe8ca50ddee080000_linkquality** — `sensor.0xe8ca50ddee080000_linkquality` — `unknown`
- **sensor.0xe8ca50de90a20000_last_seen** — `sensor.0xe8ca50de90a20000_last_seen` — `unknown`
- **sensor.0xe8ca50de90a20000_linkquality** — `sensor.0xe8ca50de90a20000_linkquality` — `unknown`
- **Kontakt over seng Action** — `sensor.kontakt_over_seng_action` — `unavailable`
- **sensor.kontakt_over_seng_last_seen** — `sensor.kontakt_over_seng_last_seen` — `unknown`
- **sensor.kontakt_over_seng_linkquality** — `sensor.kontakt_over_seng_linkquality` — `unknown`
- **WLED Estimated current** — `sensor.wled_estimated_current_2` — `unavailable`
- **sensor.wled_free_memory_2** — `sensor.wled_free_memory_2` — `unknown`
- **WLED IP** — `sensor.wled_ip_2` — `unavailable`
- **WLED LED count** — `sensor.wled_led_count_2` — `unavailable`
- **WLED Max current** — `sensor.wled_max_current_2` — `unavailable`
- **sensor.wled_uptime_2** — `sensor.wled_uptime_2` — `unknown`
- **sensor.wled_wi_fi_bssid_2** — `sensor.wled_wi_fi_bssid_2` — `unknown`
- **sensor.wled_wi_fi_channel_2** — `sensor.wled_wi_fi_channel_2` — `unknown`
- **sensor.wled_wi_fi_rssi_2** — `sensor.wled_wi_fi_rssi_2` — `unknown`
- **sensor.wled_wi_fi_signal_2** — `sensor.wled_wi_fi_signal_2` — `unknown`

## switch

- **Loftlampe soveværelse Do not disturb** — `switch.loftlampe_sovevaerelse_do_not_disturb` — `off`
- **Natlampe 2 Do not disturb** — `switch.natlampe_2_do_not_disturb` — `off`
- **Natlampe Do not disturb** — `switch.natlampe_do_not_disturb` — `off`
- **WLED Freeze** — `switch.wled_freeze_2` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_2` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_2` — `unavailable`
- **WLED Segment 1 reverse** — `switch.wled_segment_1_reverse` — `unavailable`
- **WLED Segment 2 reverse** — `switch.wled_segment_2_reverse` — `unavailable`
- **WLED Segment 3 reverse** — `switch.wled_segment_3_reverse` — `unavailable`
- **WLED Segment 4 reverse** — `switch.wled_segment_4_reverse` — `unavailable`
- **WLED Segment 5 reverse** — `switch.wled_segment_5_reverse` — `unavailable`
- **WLED Segment 6 reverse** — `switch.wled_segment_6_reverse` — `unavailable`
- **WLED Segment 7 reverse** — `switch.wled_segment_7_reverse` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_2` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_2` — `unavailable`

## update

- **WLED Firmware** — `update.wled_firmware_2` — `unavailable`
