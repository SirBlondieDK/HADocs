# Have

Generated: 2026-07-05 00:57:13

## binary_sensor

- **Robot plæneklipper Dock** — `binary_sensor.robot_plaeneklipper_dock` — `off`
- **Robot plæneklipper Multizone** — `binary_sensor.robot_plaeneklipper_multizone` — `off`
- **Robot plæneklipper Multizone auto** — `binary_sensor.robot_plaeneklipper_multizone_auto` — `off`
- **Robot plæneklipper Online** — `binary_sensor.robot_plaeneklipper_online` — `off`
- **Robot plæneklipper Regn sensor aktiv** — `binary_sensor.robot_plaeneklipper_regn_sensor_aktiv` — `on`

## button

- **Robot plæneklipper Hjem** — `button.robot_plaeneklipper_hjem` — `unknown`
- **Robot plæneklipper Klip kant** — `button.robot_plaeneklipper_klip_kant` — `unknown`
- **Robot plæneklipper Pause** — `button.robot_plaeneklipper_pause` — `unknown`
- **Robot plæneklipper Start** — `button.robot_plaeneklipper_start` — `2026-04-29T09:48:47.245783+00:00`

## device_tracker

- **Robot plæneklipper Robot lokation** — `device_tracker.robot_plaeneklipper_robot_lokation` — `unknown`

## lawn_mower

- **Robot plæneklipper** — `lawn_mower.robot_plaeneklipper` — `Standby`

## number

- **Robot plæneklipper Regn forsinkelse** — `number.robot_plaeneklipper_regn_forsinkelse` — `180`
- **Robot plæneklipper Zone 1 prioritet** — `number.robot_plaeneklipper_zone_1_prioritet` — `25`
- **Robot plæneklipper Zone 1 start** — `number.robot_plaeneklipper_zone_1_start` — `0`
- **Robot plæneklipper Zone 2 prioritet** — `number.robot_plaeneklipper_zone_2_prioritet` — `25`
- **Robot plæneklipper Zone 2 start** — `number.robot_plaeneklipper_zone_2_start` — `25`
- **Robot plæneklipper Zone 3 prioritet** — `number.robot_plaeneklipper_zone_3_prioritet` — `25`
- **Robot plæneklipper Zone 3 start** — `number.robot_plaeneklipper_zone_3_start` — `50`
- **Robot plæneklipper Zone 4 prioritet** — `number.robot_plaeneklipper_zone_4_prioritet` — `25`
- **Robot plæneklipper Zone 4 start** — `number.robot_plaeneklipper_zone_4_start` — `75`

## sensor

- **Robot plæneklipper Aktuel arbejdstid** — `sensor.robot_plaeneklipper_aktuel_arbejdstid` — `0`
- **Robot plæneklipper Batteri** — `sensor.robot_plaeneklipper_batteri` — `33`
- **Robot plæneklipper Fejl** — `sensor.robot_plaeneklipper_fejl` — `normal`
- **Robot plæneklipper Fejlkode** — `sensor.robot_plaeneklipper_fejlkode` — `0`
- **Robot plæneklipper Regn sensor** — `sensor.robot_plaeneklipper_regn_sensor` — `Dry`
- **Robot plæneklipper Regn sensor forsinkelse** — `sensor.robot_plaeneklipper_regn_sensor_forsinkelse` — `180`
- **Robot plæneklipper Regn sensor nedtæller** — `sensor.robot_plaeneklipper_regn_sensor_nedtaeller` — `180`
- **Robot plæneklipper Robot status** — `sensor.robot_plaeneklipper_robot_status` — `Standby`
- **Robot plæneklipper Status fejl** — `sensor.robot_plaeneklipper_status_fejl` — ``
- **Robot plæneklipper Tidsstyrring** — `sensor.robot_plaeneklipper_tidsstyrring` — `Schedule`
- **Robot plæneklipper Wifi styrke** — `sensor.robot_plaeneklipper_wifi_styrke` — `0`
- **Robot plæneklipper Zone 1 start** — `sensor.robot_plaeneklipper_zone_1_start` — `0`
- **Robot plæneklipper Zone 2 start** — `sensor.robot_plaeneklipper_zone_2_start` — `25`
- **Robot plæneklipper Zone 3 start** — `sensor.robot_plaeneklipper_zone_3_start` — `50`
- **Robot plæneklipper Zone 4 start** — `sensor.robot_plaeneklipper_zone_4_start` — `75`

## switch

- **Robot plæneklipper Multizone** — `switch.robot_plaeneklipper_multizone` — `off`
- **Robot plæneklipper Multizone auto** — `switch.robot_plaeneklipper_multizone_auto` — `off`
- **Robot plæneklipper Regn sensor** — `switch.robot_plaeneklipper_regn_sensor` — `on`
- **Robot plæneklipper Tidsstyrring** — `switch.robot_plaeneklipper_tidsstyrring` — `on`

## text

- **Robot plæneklipper Ugeplan fredag** — `text.robot_plaeneklipper_ugeplan_fredag` — `09:00 - 20:00 Trim`
- **Robot plæneklipper Ugeplan lørdag** — `text.robot_plaeneklipper_ugeplan_lordag` — `00:00 - 00:00`
- **Robot plæneklipper Ugeplan mandag** — `text.robot_plaeneklipper_ugeplan_mandag` — `09:00 - 20:00 Trim`
- **Robot plæneklipper Ugeplan onsdag** — `text.robot_plaeneklipper_ugeplan_onsdag` — `09:00 - 20:00 Trim`
- **Robot plæneklipper Ugeplan søndag** — `text.robot_plaeneklipper_ugeplan_sondag` — `09:00 - 20:00 Trim`
- **Robot plæneklipper Ugeplan tirsdag** — `text.robot_plaeneklipper_ugeplan_tirsdag` — `00:00 - 00:00`
- **Robot plæneklipper Ugeplan torsdag** — `text.robot_plaeneklipper_ugeplan_torsdag` — `00:00 - 00:00`
