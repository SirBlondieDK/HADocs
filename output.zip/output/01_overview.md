# 01 Overview

Generated: 2026-07-05 01:49:34

## Health Score: `54/100`

- 4 physical devices have serious problems (-24)
- 16 physical devices have warnings (-18)
- 23 physical devices have no area (-2)
- 29 duplicate names within same domain (-2)
- 267 ignored diagnostic/system entities are unknown/unavailable

## Core model

- Areas: `19`
- Devices: `189`
- Physical devices: `84`
- Virtual devices: `51`
- System devices: `54`
- Entities: `1620`
- Important entities: `201`
- Diagnostic entities: `42`
- Ignored entities: `393`
- Ignored unknown/unavailable entities: `267`
- Integrations: `49`