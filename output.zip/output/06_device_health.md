# 06 Device Health

Generated: 2026-07-05 01:49:34

## Kaffe hjørnet

- Status: `healthy`
- Score: `90/100`
- Area ID: `kokken`
- Entity count: `13`

### Reasons

- 5 relevant entities unknown

## Deco Køkken

- Status: `healthy`
- Score: `92/100`
- Area ID: `server_rum`
- Entity count: `19`

### Reasons

- 4 relevant entities unknown

## Deco Stue

- Status: `healthy`
- Score: `92/100`
- Area ID: `server_rum`
- Entity count: `20`

### Reasons

- 4 relevant entities unknown

## Diskokugle

- Status: `healthy`
- Score: `92/100`
- Area ID: `stue`
- Entity count: `8`

### Reasons

- 4 relevant entities unknown

## Facadelys

- Status: `healthy`
- Score: `92/100`
- Area ID: `udendors`
- Entity count: `8`

### Reasons

- 4 relevant entities unknown

## Strøm til Led

- Status: `healthy`
- Score: `92/100`
- Area ID: `loft`
- Entity count: `8`

### Reasons

- 4 relevant entities unknown

## Computer

- Status: `healthy`
- Score: `94/100`
- Area ID: `computer_hjorne`
- Entity count: `6`

### Reasons

- 3 relevant entities unknown

## GVH5075_22BD

- Status: `healthy`
- Score: `94/100`
- Area ID: `_uden_område`
- Entity count: `5`

### Reasons

- 3 relevant entities unknown

## Spillemaskine

- Status: `healthy`
- Score: `94/100`
- Area ID: `stue`
- Entity count: `6`

### Reasons

- 3 relevant entities unknown

## Zigbee2MQTT Bridge

- Status: `healthy`
- Score: `94/100`
- Area ID: `_uden_område`
- Entity count: `8`

### Reasons

- 3 relevant entities unknown

## Kabelskinne

- Status: `healthy`
- Score: `96/100`
- Area ID: `de_sma_s_vaerelse`
- Entity count: `6`

### Reasons

- 2 relevant entities unknown

## Kontakt Rumdeler

- Status: `healthy`
- Score: `96/100`
- Area ID: `_uden_område`
- Entity count: `3`

### Reasons

- 1 relevant entities unavailable

## Kontakt over seng

- Status: `healthy`
- Score: `96/100`
- Area ID: `sovevaerelse`
- Entity count: `3`

### Reasons

- 1 relevant entities unavailable

## Lampe Sofabord

- Status: `healthy`
- Score: `96/100`
- Area ID: `stue`
- Entity count: `4`

### Reasons

- 2 relevant entities unknown

## WiZ RGBWW Tunable 0123AC

- Status: `healthy`
- Score: `96/100`
- Area ID: `stue`
- Entity count: `4`

### Reasons

- 2 relevant entities unknown

## kontakt stue

- Status: `healthy`
- Score: `96/100`
- Area ID: `stue`
- Entity count: `3`

### Reasons

- 1 relevant entities unavailable

## H5075 22BD

- Status: `healthy`
- Score: `98/100`
- Area ID: `sofia_s_vaerelse`
- Entity count: `4`

### Reasons

- 1 relevant entities unknown

## HP ENVY Inspire 7200 series

- Status: `healthy`
- Score: `98/100`
- Area ID: `computer_hjorne`
- Entity count: `4`

### Reasons

- 1 relevant entities unknown

## Kontakt Køkken

- Status: `healthy`
- Score: `98/100`
- Area ID: `kokken`
- Entity count: `3`

### Reasons

- 1 relevant entities unknown

## Kontakt Sebastian

- Status: `healthy`
- Score: `98/100`
- Area ID: `sebastian_s_vaerelse`
- Entity count: `3`

### Reasons

- 1 relevant entities unknown

## Kontakt de smås værelse

- Status: `healthy`
- Score: `98/100`
- Area ID: `de_sma_s_vaerelse`
- Entity count: `3`

### Reasons

- 1 relevant entities unknown

## Kontakt sofia

- Status: `healthy`
- Score: `98/100`
- Area ID: `sofia_s_vaerelse`
- Entity count: `3`

### Reasons

- 1 relevant entities unknown

## Robot plæneklipper

- Status: `healthy`
- Score: `98/100`
- Area ID: `have`
- Entity count: `46`

### Reasons

- 1 relevant entities unknown

## Badeværelse spot 1

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `7`

## Badeværelse spot 2

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `7`

## Badeværelse spot 3

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `7`

## Badeværelse spot 4

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `7`

## Badeværelse spot 5

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `7`

## Bevægelses sensor badeværelse

- Status: `healthy`
- Score: `100/100`
- Area ID: `badevaerelse`
- Entity count: `8`

## Fjernsyn

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `2`

## Fjernsyn Stue

- Status: `healthy`
- Score: `100/100`
- Area ID: `stue`
- Entity count: `1`

## Foran

- Status: `healthy`
- Score: `100/100`
- Area ID: `udendors`
- Entity count: `6`

## HADashboard

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## Køkken spot 2

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `7`

## Køkken spot 3

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `7`

## Lampe gang

- Status: `healthy`
- Score: `100/100`
- Area ID: `gang`
- Entity count: `6`

## Lampe spisebord

- Status: `healthy`
- Score: `100/100`
- Area ID: `kokken`
- Entity count: `6`

## Lille Lampe

- Status: `healthy`
- Score: `100/100`
- Area ID: `stue`
- Entity count: `7`

## Loftlampe Køkken

- Status: `healthy`
- Score: `100/100`
- Area ID: `kokken`
- Entity count: `6`

## Loftlampe Sebastian

- Status: `healthy`
- Score: `100/100`
- Area ID: `sebastian_s_vaerelse`
- Entity count: `6`

## Loftlampe Sofia

- Status: `healthy`
- Score: `100/100`
- Area ID: `sofia_s_vaerelse`
- Entity count: `6`

## Loftlampe Stue

- Status: `healthy`
- Score: `100/100`
- Area ID: `stue`
- Entity count: `6`

## Loftlampe bryggers

- Status: `healthy`
- Score: `100/100`
- Area ID: `bryggers`
- Entity count: `6`

## Loftlampe soveværelse

- Status: `healthy`
- Score: `100/100`
- Area ID: `sovevaerelse`
- Entity count: `6`

## Natlampe

- Status: `healthy`
- Score: `100/100`
- Area ID: `sovevaerelse`
- Entity count: `7`

## Natlampe 2

- Status: `healthy`
- Score: `100/100`
- Area ID: `sovevaerelse`
- Entity count: `7`

## Storage (local)

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `7`

## Storage (local-lvm)

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `7`

## Temp stue

- Status: `healthy`
- Score: `100/100`
- Area ID: `stue`
- Entity count: `13`

## Usb kontakt stue 1

- Status: `healthy`
- Score: `100/100`
- Area ID: `stue`
- Entity count: `5`

## Wake on LAN 24:41:8c:93:d0:ff

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `2`

## adguard

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## d5369777-music-assistant

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `1`

## frigate

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## homeassistant

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `20`

## hp-mini

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `18`

## husets Multimedie 

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `1`

## jellyfin

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## køkken spot 1

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `7`

## lampe de små pære 1

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `6`

## lampe de små pære 2

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `6`

## lampe de små pære 3

- Status: `healthy`
- Score: `100/100`
- Area ID: `_uden_område`
- Entity count: `6`

## proxy

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## zigbee2mqtt

- Status: `healthy`
- Score: `100/100`
- Area ID: `server_rum`
- Entity count: `16`

## WLED

- Status: `problem`
- Score: `20/100`
- Area ID: `de_sma_s_vaerelse`
- Entity count: `26`

### Reasons

- 8 relevant entities unavailable
- 5 relevant entities unknown

## Stue

- Status: `problem`
- Score: `22/100`
- Area ID: `stue`
- Entity count: `62`

### Reasons

- 10 relevant entities unavailable
- 4 relevant entities unknown

## WLED

- Status: `problem`
- Score: `22/100`
- Area ID: `sovevaerelse`
- Entity count: `62`

### Reasons

- 10 relevant entities unavailable
- 4 relevant entities unknown

## Sebastian wall display 

- Status: `problem`
- Score: `50/100`
- Area ID: `_uden_område`
- Entity count: `88`

### Reasons

- 74 relevant entities unknown
- sensor.sebastian_wall_display_battery_level battery critical (3.0%)

## Ringklokke

- Status: `warning`
- Score: `65/100`
- Area ID: `hoveddor`
- Entity count: `82`

### Reasons

- 35 relevant entities unknown

## Sofia wall display 

- Status: `warning`
- Score: `65/100`
- Area ID: `_uden_område`
- Entity count: `88`

### Reasons

- 74 relevant entities unknown

## Tabet stue

- Status: `warning`
- Score: `65/100`
- Area ID: `_uden_område`
- Entity count: `88`

### Reasons

- 74 relevant entities unknown

## Car Area

- Status: `warning`
- Score: `76/100`
- Area ID: `_uden_område`
- Entity count: `12`

### Reasons

- 6 relevant entities unavailable

## Carport

- Status: `warning`
- Score: `76/100`
- Area ID: `carport`
- Entity count: `36`

### Reasons

- 6 relevant entities unknown

## Frigate

- Status: `warning`
- Score: `76/100`
- Area ID: `_uden_område`
- Entity count: `9`

### Reasons

- 6 relevant entities unknown

## Indkorelse

- Status: `warning`
- Score: `76/100`
- Area ID: `_uden_område`
- Entity count: `36`

### Reasons

- 6 relevant entities unknown

## Spot Hoveddør 1

- Status: `warning`
- Score: `76/100`
- Area ID: `carport`
- Entity count: `7`

### Reasons

- 2 relevant entities unavailable

## Spot Hoveddør 2

- Status: `warning`
- Score: `76/100`
- Area ID: `carport`
- Entity count: `7`

### Reasons

- 2 relevant entities unavailable

## Terasse

- Status: `warning`
- Score: `76/100`
- Area ID: `terressen`
- Entity count: `36`

### Reasons

- 6 relevant entities unknown

## Deco loft

- Status: `warning`
- Score: `86/100`
- Area ID: `server_rum`
- Entity count: `41`

### Reasons

- 7 relevant entities unknown

## Pool

- Status: `warning`
- Score: `86/100`
- Area ID: `terressen`
- Entity count: `5`

### Reasons

- 2 relevant entities unavailable
- 3 relevant entities unknown

## S2eb7335ec69640c3C 94BC

- Status: `warning`
- Score: `86/100`
- Area ID: `_uden_område`
- Entity count: `5`

### Reasons

- 2 relevant entities unavailable
- 3 relevant entities unknown

## Saphe Drive Pro 710C

- Status: `warning`
- Score: `86/100`
- Area ID: `_uden_område`
- Entity count: `5`

### Reasons

- 2 relevant entities unavailable
- 3 relevant entities unknown

## Saphe Drive Pro F81F

- Status: `warning`
- Score: `86/100`
- Area ID: `_uden_område`
- Entity count: `5`

### Reasons

- 2 relevant entities unavailable
- 3 relevant entities unknown

## XPED-0060370B54C3

- Status: `warning`
- Score: `86/100`
- Area ID: `_uden_område`
- Entity count: `5`

### Reasons

- 2 relevant entities unavailable
- 3 relevant entities unknown
