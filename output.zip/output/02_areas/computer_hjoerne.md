# Computer hjørne

Generated: 2026-07-05 01:49:34

## Devices

- **Computer** — `physical` — 6 entities
- **HP ENVY Inspire 7200 series** — `physical` — 4 entities

## Important entities
