# Soveværelse

Generated: 2026-07-05 01:49:34

## Devices

- **Kontakt over seng** — `physical` — 3 entities
- **Loftlampe soveværelse** — `physical` — 6 entities
- **Natlampe** — `physical` — 7 entities
- **Natlampe 2** — `physical` — 7 entities
- **Soveværelse** — `virtual` — 1 entities
- **Soveværelse hub** — `virtual` — 1 entities
- **Soveværelse hub** — `virtual` — 2 entities
- **WLED** — `physical` — 62 entities

## Important entities

- **WLED Ledsove** — `device_tracker.kitchen_deco_ledsove` — `not_home`
- **Loftlampe soveværelse** — `light.loftlampe_sovevaerelse` — `off`
- **Natlampe** — `light.natlampe` — `off`
- **Natlampe 2** — `light.natlampe_2` — `off`
- **WLED** — `light.wled_2` — `unavailable`
- **WLED Main** — `light.wled_main` — `unavailable`
- **Soveværelse** — `media_player.sovevaerelse` — `unavailable`
- **Soveværelse hub** — `media_player.sovevaerelse_hub` — `off`
- **Loftlampe soveværelse Do not disturb** — `switch.loftlampe_sovevaerelse_do_not_disturb` — `off`
- **Natlampe 2 Do not disturb** — `switch.natlampe_2_do_not_disturb` — `off`
- **Natlampe Do not disturb** — `switch.natlampe_do_not_disturb` — `off`
- **WLED Freeze** — `switch.wled_freeze_2` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_2` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_2` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_2` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_2` — `unavailable`