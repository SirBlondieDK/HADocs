# 02 Areas

Generated: 2026-07-05 01:49:34

- [Badeværelse](badevaerelse.md) — 8 devices, 47 entities
- [Bryggers](bryggers.md) — 3 devices, 9 entities
- [Carport](carport.md) — 3 devices, 51 entities
- [Computer hjørne](computer_hjoerne.md) — 2 devices, 10 entities
- [De små's værelse](de_smaa_s_vaerelse.md) — 5 devices, 44 entities
- [Gang](gang.md) — 1 devices, 6 entities
- [Have](have.md) — 1 devices, 46 entities
- [Hoveddør](hoveddoer.md) — 1 devices, 82 entities
- [Julelys](julelys.md) — 0 devices, 0 entities
- [Køkken](koekken.md) — 6 devices, 33 entities
- [Loft](loft.md) — 1 devices, 8 entities
- [Sebastian's værelse](sebastian_s_vaerelse.md) — 3 devices, 12 entities
- [Server rum](server_rum.md) — 14 devices, 244 entities
- [Sofia's værelse](sofia_s_vaerelse.md) — 5 devices, 19 entities
- [Soveværelse](sovevaerelse.md) — 8 devices, 90 entities
- [Stue](stue.md) — 15 devices, 127 entities
- [Uden område](uden_omraade.md) — 109 devices, 737 entities
- [Udendørs](udendoers.md) — 2 devices, 14 entities
- [terrasse](terrasse.md) — 2 devices, 41 entities