# Gang

Generated: 2026-07-05 01:49:34

## Devices

- **Lampe gang** — `physical` — 6 entities

## Important entities

- **Lampe gang** — `light.lampe_gang` — `off`
- **Lampe gang Do not disturb** — `switch.lampe_gang_do_not_disturb` — `off`