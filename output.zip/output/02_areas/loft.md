# Loft

Generated: 2026-07-05 01:49:34

## Devices

- **Strøm til Led** — `physical` — 8 entities

## Important entities
