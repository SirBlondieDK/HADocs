# Udendørs

Generated: 2026-07-05 01:49:34

## Devices

- **Facadelys** — `physical` — 8 entities
- **Foran** — `physical` — 6 entities

## Important entities
