# Køkken

Generated: 2026-07-05 01:49:34

## Devices

- **Kaffe hjørnet** — `physical` — 13 entities
- **Kontakt Køkken** — `physical` — 3 entities
- **Køkken** — `virtual` — 1 entities
- **Køkken** — `virtual` — 2 entities
- **Lampe spisebord** — `physical` — 6 entities
- **Loftlampe Køkken** — `physical` — 6 entities

## Important entities

- **Lampe spisebord** — `light.lampe_spisebord` — `on`
- **Loftlampe Køkken** — `light.loftlampe_kokken` — `on`
- **Køkken** — `media_player.kokken` — `off`
- **Lampe spisebord Do not disturb** — `switch.lampe_spisebord_do_not_disturb` — `off`
- **Loftlampe Køkken Do not disturb** — `switch.loftlampe_kokken_do_not_disturb` — `off`