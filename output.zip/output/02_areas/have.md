# Have

Generated: 2026-07-05 01:49:34

## Devices

- **Robot plæneklipper** — `physical` — 46 entities

## Important entities
