# Badeværelse

Generated: 2026-07-05 01:49:34

## Devices

- **Badeværelse** — `virtual` — 2 entities
- **Badeværelse spot 1** — `physical` — 7 entities
- **Badeværelse spot 2** — `physical` — 7 entities
- **Badeværelse spot 3** — `physical` — 7 entities
- **Badeværelse spot 4** — `physical` — 7 entities
- **Badeværelse spot 5** — `physical` — 7 entities
- **Bevægelses sensor badeværelse** — `physical` — 8 entities
- **Google Home Badeværelse** — `virtual` — 1 entities

## Important entities

- **Badeværelse spot 1** — `light.badevaerelse_spot_1` — `off`
- **Badeværelse spot 2** — `light.badevaerelse_spot_2` — `off`
- **Badeværelse spot 3** — `light.badevaerelse_spot_3` — `off`
- **Badeværelse spot 4** — `light.badevaerelse_spot_4` — `off`
- **Badeværelse spot 5** — `light.badevaerelse_spot_5` — `off`
- **Google Home Badeværelse** — `media_player.badevaerelse` — `off`
- **Bevægelses sensor badeværelse Batteri** — `sensor.bevaegelses_sensor_badevaerelse_battery` — `90`
- **Badeværelse spot 1 Do not disturb** — `switch.badevaerelse_spot_1_do_not_disturb` — `off`
- **Badeværelse spot 2 Do not disturb** — `switch.badevaerelse_spot_2_do_not_disturb` — `off`
- **Badeværelse spot 3 Do not disturb** — `switch.badevaerelse_spot_3_do_not_disturb` — `off`
- **Badeværelse spot 4 Do not disturb** — `switch.badevaerelse_spot_4_do_not_disturb` — `off`
- **Badeværelse spot 5 Do not disturb** — `switch.badevaerelse_spot_5_do_not_disturb` — `off`