# Bryggers

Generated: 2026-07-05 01:49:34

## Devices

- **Bryggers** — `virtual` — 1 entities
- **Bryggers** — `virtual` — 2 entities
- **Loftlampe bryggers** — `physical` — 6 entities

## Important entities

- **Loftlampe bryggers** — `light.loftlampe_bryggers` — `off`
- **Bryggers** — `media_player.bryggers` — `off`
- **Loftlampe bryggers Do not disturb** — `switch.loftlampe_bryggers_do_not_disturb` — `off`