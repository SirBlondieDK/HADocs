# terrasse

Generated: 2026-07-05 01:49:34

## Devices

- **Pool** — `physical` — 5 entities
- **Terasse** — `physical` — 36 entities

## Important entities

- **Terasse Motion** — `binary_sensor.terasse_motion` — `off`
- **Terasse** — `camera.terasse` — `recording`
- **sensor.terasse_camera_fps** — `sensor.terasse_camera_fps` — `unknown`
- **sensor.terasse_detection_fps** — `sensor.terasse_detection_fps` — `unknown`