# Sofia's værelse

Generated: 2026-07-05 01:49:34

## Devices

- **H5075 22BD** — `physical` — 4 entities
- **Kontakt sofia** — `physical` — 3 entities
- **Loftlampe Sofia** — `physical` — 6 entities
- **Sofias værelse** — `virtual` — 1 entities
- **Sofias værelse** — `virtual` — 2 entities

## Important entities

- **Loftlampe Sofia** — `light.loftlampe_sofia` — `on`
- **Sofias værelse** — `media_player.sofias_vaerelse` — `off`
- **Loftlampe Sofia Do not disturb** — `switch.loftlampe_sofia_do_not_disturb` — `off`