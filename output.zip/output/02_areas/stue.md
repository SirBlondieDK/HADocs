# Stue

Generated: 2026-07-05 01:49:34

## Devices

- **Diskokugle** — `physical` — 8 entities
- **Fjernsyn Stue** — `physical` — 1 entities
- **Lampe Sofabord** — `physical` — 4 entities
- **Lille Lampe** — `physical` — 7 entities
- **Loftlampe Stue** — `physical` — 6 entities
- **Spillemaskine** — `physical` — 6 entities
- **Stue** — `virtual` — 1 entities
- **Stue** — `physical` — 62 entities
- **Stue** — `virtual` — 2 entities
- **Temp stue** — `physical` — 13 entities
- **Usb kontakt stue 1** — `physical` — 5 entities
- **WiZ RGBWW Tunable 0123AC** — `physical` — 4 entities
- **kontakt stue** — `physical` — 3 entities
- **stue højttaler** — `virtual` — 1 entities
- **stue højttaler** — `virtual` — 2 entities

## Important entities

- **Stue wledmic** — `device_tracker.kitchen_deco_wledmic` — `not_home`
- **Lille Lampe** — `light.lille_lampe` — `off`
- **Loftlampe Stue** — `light.loftlampe_stue` — `off`
- **Led Stue** — `light.wled` — `unavailable`
- **Stue Main** — `light.wled_main_2` — `unavailable`
- **Fjernsyn Stue** — `media_player.fjernsyn_stue` — `off`
- **Stue** — `media_player.stue` — `off`
- **stue højttaler** — `media_player.stue_hojttaler` — `off`
- **Temp stue Batteri** — `sensor.temp_stue_battery` — `100`
- **Lille Lampe Do not disturb** — `switch.lille_lampe_do_not_disturb` — `off`
- **Loftlampe Stue Do not disturb** — `switch.loftlampe_stue_do_not_disturb` — `off`
- **Stue Freeze** — `switch.stue_freeze` — `unavailable`
- **Lysende rose** — `switch.usb_kontakt_stue_1_center` — `off`
- **USB kontakt 1** — `switch.usb_kontakt_stue_1_left` — `off`
- **The Black Pearl** — `switch.usb_kontakt_stue_1_right` — `off`
- **Stue Nightlight** — `switch.wled_nightlight` — `unavailable`
- **Stue Reverse** — `switch.wled_reverse` — `unavailable`
- **Stue Sync receive** — `switch.wled_sync_receive` — `unavailable`
- **Stue Sync send** — `switch.wled_sync_send` — `unavailable`