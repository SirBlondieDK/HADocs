# De små's værelse

Generated: 2026-07-05 01:49:34

## Devices

- **De smås værelse** — `virtual` — 1 entities
- **De smås værelse** — `virtual` — 2 entities
- **Kabelskinne** — `physical` — 6 entities
- **Kontakt de smås værelse** — `physical` — 3 entities
- **WLED** — `physical` — 26 entities

## Important entities

- **WLED Ledss** — `device_tracker.kitchen_deco_ledss` — `not_home`
- **Led ved de små** — `light.wled_3` — `unavailable`
- **De smås værelse** — `media_player.de_smas_vaerelse` — `off`
- **WLED Freeze** — `switch.wled_freeze` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_3` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_3` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_3` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_3` — `unavailable`