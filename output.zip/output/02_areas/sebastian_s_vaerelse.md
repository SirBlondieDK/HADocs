# Sebastian's værelse

Generated: 2026-07-05 01:49:34

## Devices

- **Kontakt Sebastian** — `physical` — 3 entities
- **Loftlampe Sebastian** — `physical` — 6 entities
- **Sebastian** — `virtual` — 1 entities

## Important entities

- **Loftlampe Sebastian** — `light.loftlampe_sebastian` — `off`
- **Sebastian** — `media_player.sebastian` — `off`
- **Loftlampe Sebastian Do not disturb** — `switch.loftlampe_sebastian_do_not_disturb` — `off`