# Hoveddør

Generated: 2026-07-05 01:49:34

## Devices

- **Ringklokke** — `physical` — 82 entities

## Important entities

- **Ringklokke** — `camera.ringklokke_hd_stream_direct` — `idle`
- **camera.ringklokke_sd_stream_direct** — `camera.ringklokke_sd_stream_direct` — `unknown`
- **Ringklokke Battery** — `sensor.ringklokke_battery` — `100`