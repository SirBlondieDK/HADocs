# Carport

Generated: 2026-07-05 01:49:34

## Devices

- **Carport** — `physical` — 36 entities
- **Spot Hoveddør 1** — `physical` — 7 entities
- **Spot Hoveddør 2** — `physical` — 7 entities

## Important entities

- **Carport Motion** — `binary_sensor.carport_motion` — `off`
- **Carport** — `camera.carport` — `recording`
- **Spot Hoveddør 1** — `light.spot_hoveddor_1` — `unavailable`
- **Spot Hoveddør 2** — `light.spot_hoveddor_2` — `unavailable`
- **sensor.carport_camera_fps** — `sensor.carport_camera_fps` — `unknown`
- **sensor.carport_detection_fps** — `sensor.carport_detection_fps` — `unknown`
- **Spot Hoveddør 1 Do not disturb** — `switch.spot_hoveddor_1_do_not_disturb` — `unavailable`
- **Spot Hoveddør 2 Do not disturb** — `switch.spot_hoveddor_2_do_not_disturb` — `unavailable`