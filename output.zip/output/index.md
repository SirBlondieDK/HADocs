# My Smart Home - Documentation

Generated: 2026-07-05 00:57:13

## Health Score: `42/100`

## Reports

- [01 Overview](01_oversigt.md)
- [02 Areas](02_rum/index.md)
- [03 Devices](03_enheder/index.md)
- [04 Integrations](04_integrationer.md)
- [05 Server Room](05_serverrum.md)
- [06 Network](06_netvaerk.md)
- [07 Problems and cleanup](07_problemer.md)
- [08 Dashboard whitelist](08_dashboard_whitelist.md)
- [09 Batteries](09_batterier.md)
- [10 Architecture](10_arkitektur.md)
- [11 Health Score details](11_health_score.md)
- [CSV data](csv/entities.csv)