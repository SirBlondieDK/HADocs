# My Smart Home - Documentation

Generated: 2026-07-05 01:49:34

## Health Score: `54/100`

## Reports

- [01 Overview](01_overview.md)
- [02 Areas](02_areas/index.md)
- [03 Devices](03_devices/index.md)
- [04 Integrations](04_integrations.md)
- [05 Integration Health](05_integration_health.md)
- [06 Device Health](06_device_health.md)
- [07 Recommendations](07_recommendations.md)
- [08 Problems and cleanup](08_problems.md)
- [09 Rule Matches](09_rule_matches.md)
- [10 Dashboard whitelist](10_dashboard_whitelist.md)
- [11 Architecture](11_architecture.md)
- [CSV entities](csv/entities.csv)
- [CSV devices](csv/devices.csv)