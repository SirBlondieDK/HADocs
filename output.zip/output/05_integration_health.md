# 05 Integration Health

Generated: 2026-07-05 01:49:34

## adano

- Score: `80/100`
- Relevant entities: `46`
- Relevant unknown/unavailable: `4`

## aula

- Score: `90/100`
- Relevant entities: `11`
- Relevant unknown/unavailable: `2`

## automation

- Score: `95/100`
- Relevant entities: `18`
- Relevant unknown/unavailable: `1`

## backup

- Score: `100/100`
- Relevant entities: `5`
- Relevant unknown/unavailable: `0`

## cast

- Score: `95/100`
- Relevant entities: `20`
- Relevant unknown/unavailable: `1`

## cloud

- Score: `90/100`
- Relevant entities: `3`
- Relevant unknown/unavailable: `2`

## continuously_casting_dashboards

- Score: `45/100`
- Relevant entities: `11`
- Relevant unknown/unavailable: `11`

## dwains_dashboard

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## file

- Score: `95/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `1`

## frigate

- Score: `40/100`
- Relevant entities: `114`
- Relevant unknown/unavailable: `36`

## google

- Score: `90/100`
- Relevant entities: `8`
- Relevant unknown/unavailable: `2`

## google_generative_ai_conversation

- Score: `85/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `3`

## google_translate

- Score: `95/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `1`

## govee_ble

- Score: `95/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `1`

## group

- Score: `95/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `1`

## hacs

- Score: `40/100`
- Relevant entities: `46`
- Relevant unknown/unavailable: `24`

## hassio

- Score: `40/100`
- Relevant entities: `91`
- Relevant unknown/unavailable: `77`

## homeassistant_sky_connect

- Score: `90/100`
- Relevant entities: `2`
- Relevant unknown/unavailable: `2`

## ibeacon

- Score: `40/100`
- Relevant entities: `25`
- Relevant unknown/unavailable: `23`

## icloud

- Score: `40/100`
- Relevant entities: `12`
- Relevant unknown/unavailable: `12`

## input_boolean

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## input_button

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## input_datetime

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## input_select

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## input_text

- Score: `95/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `1`

## ipp

- Score: `95/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `1`

## jellyfin

- Score: `100/100`
- Relevant entities: `2`
- Relevant unknown/unavailable: `0`

## met

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## mobile_app

- Score: `40/100`
- Relevant entities: `242`
- Relevant unknown/unavailable: `227`

## mqtt

- Score: `40/100`
- Relevant entities: `142`
- Relevant unknown/unavailable: `79`

## music_assistant

- Score: `40/100`
- Relevant entities: `40`
- Relevant unknown/unavailable: `21`

## openai_conversation

- Score: `80/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `4`

## person

- Score: `90/100`
- Relevant entities: `4`
- Relevant unknown/unavailable: `2`

## proxmoxve

- Score: `100/100`
- Relevant entities: `48`
- Relevant unknown/unavailable: `0`

## schedule

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## script

- Score: `100/100`
- Relevant entities: `11`
- Relevant unknown/unavailable: `0`

## shelly

- Score: `40/100`
- Relevant entities: `24`
- Relevant unknown/unavailable: `21`

## shopping_list

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## spotify

- Score: `100/100`
- Relevant entities: `0`
- Relevant unknown/unavailable: `0`

## sun

- Score: `85/100`
- Relevant entities: `9`
- Relevant unknown/unavailable: `3`

## switch_as_x

- Score: `100/100`
- Relevant entities: `1`
- Relevant unknown/unavailable: `0`

## tapo_control

- Score: `40/100`
- Relevant entities: `67`
- Relevant unknown/unavailable: `35`

## tplink

- Score: `70/100`
- Relevant entities: `13`
- Relevant unknown/unavailable: `6`

## tplink_deco

- Score: `40/100`
- Relevant entities: `89`
- Relevant unknown/unavailable: `15`

## tuya

- Score: `40/100`
- Relevant entities: `22`
- Relevant unknown/unavailable: `13`

## wake_on_lan

- Score: `100/100`
- Relevant entities: `2`
- Relevant unknown/unavailable: `0`

## wiz

- Score: `70/100`
- Relevant entities: `8`
- Relevant unknown/unavailable: `6`

## wled

- Score: `40/100`
- Relevant entities: `53`
- Relevant unknown/unavailable: `53`

## zone

- Score: `100/100`
- Relevant entities: `7`
- Relevant unknown/unavailable: `0`
