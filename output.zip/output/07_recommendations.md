# 07 Recommendations

Generated: 2026-07-05 01:49:34

## Fix device: WLED

- Priority: `★★★★★`
- Reason: 8 relevant entities unavailable; 5 relevant entities unknown
- Estimated score gain: `+6`

## Fix device: Stue

- Priority: `★★★★★`
- Reason: 10 relevant entities unavailable; 4 relevant entities unknown
- Estimated score gain: `+6`

## Fix device: WLED

- Priority: `★★★★★`
- Reason: 10 relevant entities unavailable; 4 relevant entities unknown
- Estimated score gain: `+6`

## Fix device: Sebastian wall display 

- Priority: `★★★★★`
- Reason: 74 relevant entities unknown; sensor.sebastian_wall_display_battery_level battery critical (3.0%)
- Estimated score gain: `+6`

## Check device: Tabet stue

- Priority: `★★★★☆`
- Reason: 74 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Sofia wall display 

- Priority: `★★★★☆`
- Reason: 74 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Ringklokke

- Priority: `★★★★☆`
- Reason: 35 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Frigate

- Priority: `★★★★☆`
- Reason: 6 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Indkorelse

- Priority: `★★★★☆`
- Reason: 6 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Carport

- Priority: `★★★★☆`
- Reason: 6 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Terasse

- Priority: `★★★★☆`
- Reason: 6 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Car Area

- Priority: `★★★★☆`
- Reason: 6 relevant entities unavailable
- Estimated score gain: `+2`

## Check device: Spot Hoveddør 1

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable
- Estimated score gain: `+2`

## Check device: Spot Hoveddør 2

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable
- Estimated score gain: `+2`

## Check device: Pool

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable; 3 relevant entities unknown
- Estimated score gain: `+2`

## Check device: S2eb7335ec69640c3C 94BC

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable; 3 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Saphe Drive Pro F81F

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable; 3 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Saphe Drive Pro 710C

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable; 3 relevant entities unknown
- Estimated score gain: `+2`

## Check device: XPED-0060370B54C3

- Priority: `★★★★☆`
- Reason: 2 relevant entities unavailable; 3 relevant entities unknown
- Estimated score gain: `+2`

## Check device: Deco loft

- Priority: `★★★★☆`
- Reason: 7 relevant entities unknown
- Estimated score gain: `+2`

## Assign 23 physical devices to areas

- Priority: `★★★☆☆`
- Reason: Physical devices without areas are harder to document, analyze, and place on dashboards.
- Estimated score gain: `+2`

## Review 29 duplicate names within the same domain

- Priority: `★★☆☆☆`
- Reason: Duplicate names can make dashboards, automations, and documentation harder to understand.
- Estimated score gain: `+2`
