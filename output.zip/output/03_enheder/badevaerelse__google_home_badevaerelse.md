# Google Home Badeværelse

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Hardware: ``
- Software: ``
- Device ID: `6b9097076304a7ed22db715dfb348c71`

## Entities

- `media_player.badevaerelse` — `off`