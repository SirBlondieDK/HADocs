# MQTT Explorer

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Gollum add-on repository for Home Assistant`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `browser-1.0.3`
- Device ID: `39e6f457e92dbecaf6d245f03c6fac54`
- Configuration URL: `homeassistant://hassio/addon/9cf1ea8f_mqtt_explorer`

## Entities

- `binary_sensor.mqtt_explorer_korer` — `unknown`
- `sensor.mqtt_explorer_cpu_procent` — `unknown`
- `sensor.mqtt_explorer_hukommelsesprocent` — `unknown`
- `sensor.mqtt_explorer_nyeste_version` — `unknown`
- `sensor.mqtt_explorer_version` — `unknown`
- `switch.mqtt_explorer` — `unknown`
- `update.mqtt_explorer_update` — `off`