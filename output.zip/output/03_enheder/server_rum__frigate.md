# frigate

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `e0e506f5ebed5e55b32c613440ff172d`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/106`

## Entities

- `binary_sensor.frigate_status` — `on`
- `button.frigate_create_snapshot` — `unknown`
- `button.frigate_genstart` — `unknown`
- `button.frigate_start` — `unknown`
- `button.frigate_stop` — `unknown`
- `sensor.frigate_cpu_usage` — `21.9263081653211`
- `sensor.frigate_disk_usage` — `10.7278251647949`
- `sensor.frigate_max_cpu` — `4`
- `sensor.frigate_max_disk_usage` — `19.5181427001953`
- `sensor.frigate_max_memory_usage` — `4.0`
- `sensor.frigate_memory_usage` — `0.656719207763672`
- `sensor.frigate_memory_usage_percentage` — `16.4179801940918`
- `sensor.frigate_network_input` — `128.267546872608`
- `sensor.frigate_network_output` — `2.93577069230378`
- `sensor.frigate_status_2` — `running`
- `sensor.frigate_uptime_2` — `13.3597222222222`