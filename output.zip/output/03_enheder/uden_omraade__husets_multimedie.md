# husets Multimedie 

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Jellyfin`
- Model: ``
- Hardware: ``
- Software: `10.11.11`
- Device ID: `a1ded345118c080497725e5a8e7de1c1`

## Entities

- `sensor.husets_multimedie_active_clients` — `0`