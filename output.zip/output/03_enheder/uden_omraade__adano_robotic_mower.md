# Adano robotic mower

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Sdahl1234`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `4d55e7fac716ca0906b49325b98fb1e4`
- Configuration URL: `homeassistant://hacs/repository/754097377`

## Entities

- `switch.adano_robotic_mower_pre_release` — `unknown`
- `update.adano_robotic_mower_update` — `off`