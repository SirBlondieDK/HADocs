# Sofias værelse

Generated: 2026-07-05 00:57:13

- Area: `Sofia's værelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Hardware: ``
- Software: ``
- Device ID: `06c50dc4caaac4aafcc9856465ac229a`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/5387e3a1-b141-2fe3-d8d9-7f8209f411fb`

## Entities

- `button.sofias_vaerelse_favorite_current_song` — `unknown`
- `media_player.sofias_vaerelse_2` — `idle`