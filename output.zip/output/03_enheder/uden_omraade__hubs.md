# hubs

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `6f383fa19efbe849ebbc5aa7b47dab4f`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/fcf87931-5438-49b6-a42e-34785d715755`

## Entities

- `button.hubs_favorite_current_song` — `unknown`
- `media_player.hubs_2` — `off`