# Loftlampe Sebastian

Generated: 2026-07-05 00:57:13

- Area: `Sebastian's værelse`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `fd51e9842c76d3e69b19aae10205edf2`

## Entities

- `light.loftlampe_sebastian` — `off`
- `select.0xa4c1383c67fc69da_effect` — `unknown`
- `select.loftlampe_sebastian_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1383c67fc69da_last_seen` — `unknown`
- `sensor.0xa4c1383c67fc69da_linkquality` — `unknown`
- `switch.loftlampe_sebastian_do_not_disturb` — `off`