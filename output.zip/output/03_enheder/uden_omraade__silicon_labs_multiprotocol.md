# Silicon Labs Multiprotocol

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `2.4.5`
- Device ID: `25241c569755a55bb1b99e50842e321f`
- Configuration URL: `homeassistant://hassio/addon/core_silabs_multiprotocol`

## Entities

- `binary_sensor.silicon_labs_multiprotocol_korer` — `unknown`
- `sensor.silicon_labs_multiprotocol_cpu_procent` — `unknown`
- `sensor.silicon_labs_multiprotocol_hukommelsesprocent` — `unknown`
- `sensor.silicon_labs_multiprotocol_nyeste_version` — `unknown`
- `sensor.silicon_labs_multiprotocol_version` — `unknown`
- `switch.silicon_labs_multiprotocol` — `unknown`
- `update.silicon_labs_multiprotocol_update` — `off`