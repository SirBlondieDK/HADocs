# højttaler gruppe 1

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `afe69b15a8f5b732e6831a5d8b338e02`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/4b43766e-2d57-43ef-9d76-70b553ec58cc`

## Entities

- `button.hojttaler_gruppe_1_favorite_current_song` — `unknown`
- `media_player.hojttaler_gruppe_1_2` — `off`