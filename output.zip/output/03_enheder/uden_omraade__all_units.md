# All Units

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `8ea2829a76e68997931a75cc580f81ef`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/f8aeeffa-bcc6-4efe-8c5a-ddadf3c0312a`

## Entities

- `button.all_units_favorite_current_song` — `unknown`
- `media_player.all_units_2` — `off`