# Lovelace Home Feed Card

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `gadgetchnnel`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `afff08ccde13fa33759d36f0a03309b7`
- Configuration URL: `homeassistant://hacs/repository/174016256`

## Entities

- `switch.lovelace_home_feed_card_pre_release` — `unknown`
- `update.lovelace_home_feed_card_update` — `off`