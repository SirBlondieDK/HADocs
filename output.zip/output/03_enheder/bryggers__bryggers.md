# Bryggers

Generated: 2026-07-05 00:57:13

- Area: `Bryggers`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Hardware: ``
- Software: ``
- Device ID: `6272534bb1d48d3062c8e7c8a5eb0ec6`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/84bbc0f7-06a2-607d-2343-2a529264808a`

## Entities

- `button.bryggers_favorite_current_song` — `unknown`
- `media_player.bryggers_2` — `idle`