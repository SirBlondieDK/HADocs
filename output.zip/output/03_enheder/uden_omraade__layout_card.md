# layout-card

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `thomasloven`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `2e1a34ed585cc0a8bdf39c91d0f0a479`
- Configuration URL: `homeassistant://hacs/repository/156434866`

## Entities

- `switch.layout_card_pre_release` — `unknown`
- `update.layout_card_update` — `off`