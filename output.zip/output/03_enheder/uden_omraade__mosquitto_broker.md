# Mosquitto broker

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `7.1.0`
- Device ID: `56cb31845cb4721abf97979b727e12e1`
- Configuration URL: `homeassistant://hassio/addon/core_mosquitto`

## Entities

- `binary_sensor.mosquitto_broker_korer` — `unknown`
- `sensor.mosquitto_broker_cpu_procent` — `unknown`
- `sensor.mosquitto_broker_hukommelsesprocent` — `unknown`
- `sensor.mosquitto_broker_nyeste_version` — `unknown`
- `sensor.mosquitto_broker_version` — `unknown`
- `switch.mosquitto_broker` — `unknown`
- `update.mosquitto_broker_update` — `off`