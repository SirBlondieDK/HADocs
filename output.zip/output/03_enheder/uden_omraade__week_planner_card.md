# Week planner card

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `FamousWolf`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `04c9206697a90ce0e0ccf207afcaef60`
- Configuration URL: `homeassistant://hacs/repository/771728766`

## Entities

- `switch.week_planner_card_pre_release` — `unknown`
- `update.week_planner_card_update` — `off`