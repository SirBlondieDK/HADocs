# Spotify Bent Christiansen

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Spotify AB`
- Model: `Spotify premium`
- Hardware: ``
- Software: ``
- Device ID: `42ba5bc53f7890c22c2615ea24853187`
- Configuration URL: `https://open.spotify.com`

## Entities

- `media_player.spotify_bent_christiansen` — `idle`
- `sensor.spotify_bent_christiansen_song_acousticness` — `unknown`
- `sensor.spotify_bent_christiansen_song_danceability` — `unknown`
- `sensor.spotify_bent_christiansen_song_energy` — `unknown`
- `sensor.spotify_bent_christiansen_song_instrumentalness` — `unknown`
- `sensor.spotify_bent_christiansen_song_key` — `unknown`
- `sensor.spotify_bent_christiansen_song_liveness` — `unknown`
- `sensor.spotify_bent_christiansen_song_mode` — `unknown`
- `sensor.spotify_bent_christiansen_song_speechiness` — `unknown`
- `sensor.spotify_bent_christiansen_song_tempo` — `unavailable`
- `sensor.spotify_bent_christiansen_song_time_signature` — `unknown`
- `sensor.spotify_bent_christiansen_song_valence` — `unknown`