# Soveværelse

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `Google Inc.`
- Model: `Chromecast`
- Hardware: ``
- Software: ``
- Device ID: `c51ab64f0aa8d21016e84b33c8fa72d8`

## Entities

- `media_player.sovevaerelse` — `unavailable`