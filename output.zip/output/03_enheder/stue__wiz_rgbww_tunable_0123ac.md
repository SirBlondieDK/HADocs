# WiZ RGBWW Tunable 0123AC

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `WiZ`
- Model: `SHRGB`
- Hardware: `ESP20 01BT`
- Software: `1.38.0`
- Device ID: `c25d9c20a58f48bf06226f8fa73f4d49`

## Entities

- `light.wiz_rgbww_tunable_0123ac` — `off`
- `number.wiz_rgbww_tunable_0123ac_effect_speed` — `unavailable`
- `sensor.wiz_rgbww_tunable_0123ac_signalstyrke` — `unknown`
- `sensor.wiz_rgbww_tunable_0123ac_strom` — `unknown`