# Stue

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Google Inc.`
- Model: `Google Nest Hub`
- Hardware: ``
- Software: ``
- Device ID: `6548e52e50d007ea5e0a95e3bbeff7b5`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/60b34298-8841-fd4b-6399-552bf10d2eaa`

## Entities

- `button.stue_favorite_current_song` — `unknown`
- `media_player.stue_2` — `idle`