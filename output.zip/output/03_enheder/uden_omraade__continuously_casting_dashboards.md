# Continuously Casting Dashboards

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Continuously Casting Dashboards`
- Model: `Integration`
- Hardware: ``
- Software: ``
- Device ID: `6e1c9909d6ab6c279b2038dba840ed1f`

## Entities

- `sensor.continuously_casting_dashboards_192_168_68139_status` — `unknown`
- `sensor.continuously_casting_dashboards_192_168_68_139_status` — `unknown`
- `sensor.continuously_casting_dashboards_192_168_68_151_status` — `unknown`
- `sensor.continuously_casting_dashboards_assistant_active` — `unknown`
- `sensor.continuously_casting_dashboards_connected_devices` — `unknown`
- `sensor.continuously_casting_dashboards_disconnected_devices` — `unknown`
- `sensor.continuously_casting_dashboards_media_playing` — `unknown`
- `sensor.continuously_casting_dashboards_other_content` — `unknown`
- `sensor.continuously_casting_dashboards_sovevaerelse_hub_status` — `unknown`
- `sensor.continuously_casting_dashboards_stue_status` — `unknown`
- `sensor.continuously_casting_dashboards_total_devices` — `unknown`