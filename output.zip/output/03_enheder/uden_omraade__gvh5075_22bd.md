# GVH5075_22BD

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `3918e5ab02148026551ebb83424eaf05`

## Entities

- `device_tracker.gvh5075_22bd` — `not_home`
- `sensor.gvh5075_22bd_estimated_distance` — `unavailable`
- `sensor.gvh5075_22bd_power` — `unknown`
- `sensor.gvh5075_22bd_signalstyrke` — `unknown`
- `sensor.gvh5075_22bd_vendor` — `unknown`