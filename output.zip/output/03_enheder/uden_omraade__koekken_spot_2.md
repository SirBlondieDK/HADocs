# Køkken spot 2

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `5caac28e726b2832ab7fe82e1b31781b`

## Entities

- `light.kokken_spot_2` — `on`
- `select.0xe8ca50ddece90000_effect` — `unknown`
- `select.kokken_spot_2_color_power_on_behavior` — `unknown`
- `select.kokken_spot_2_power_on_behavior` — `unknown`
- `sensor.0xe8ca50ddece90000_last_seen` — `unknown`
- `sensor.0xe8ca50ddece90000_linkquality` — `unknown`
- `switch.kokken_spot_2_do_not_disturb` — `off`