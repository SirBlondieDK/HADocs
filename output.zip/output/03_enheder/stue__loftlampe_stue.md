# Loftlampe Stue

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Hardware: `1`
- Software: ``
- Device ID: `7ec64098218b6ed32d086844a73e4f43`

## Entities

- `light.loftlampe_stue` — `off`
- `select.0xa4c13862b3e83b4d_effect` — `unknown`
- `select.loftlampe_stue_color_power_on_behavior` — `unknown`
- `sensor.0xa4c13862b3e83b4d_last_seen` — `unknown`
- `sensor.0xa4c13862b3e83b4d_linkquality` — `unknown`
- `switch.loftlampe_stue_do_not_disturb` — `off`