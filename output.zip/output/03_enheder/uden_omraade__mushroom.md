# Mushroom

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `piitaya`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `7a01680f0a215d00830db37239455e14`
- Configuration URL: `homeassistant://hacs/repository/444350375`

## Entities

- `switch.mushroom_pre_release` — `unknown`
- `update.mushroom_update` — `off`