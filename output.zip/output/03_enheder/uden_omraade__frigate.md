# Frigate

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `29b6c862f9327deb1f2cf0b63ef2efbe`
- Configuration URL: `http://192.168.68.161:5000`

## Entities

- `sensor.frigate_camera_fps` — `unknown`
- `sensor.frigate_coral_inference_speed` — `unknown`
- `sensor.frigate_detection_fps` — `unknown`
- `sensor.frigate_intel_vaapi_gpu_load` — `unknown`
- `sensor.frigate_process_fps` — `unknown`
- `sensor.frigate_skipped_fps` — `unknown`
- `sensor.frigate_status` — `unknown`
- `sensor.frigate_uptime` — `unknown`
- `update.frigate_server` — `on`