# Sebastian

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Hardware: ``
- Software: ``
- Device ID: `4d1885e1ea6847a394efd55965a70252`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/26182a3a-9590-1ecc-d19f-ce45956d6200`

## Entities

- `button.sebastian_favorite_current_song` — `unknown`
- `media_player.sebastian_2` — `idle`