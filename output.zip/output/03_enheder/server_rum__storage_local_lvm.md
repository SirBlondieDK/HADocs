# Storage (local-lvm)

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Storage`
- Hardware: ``
- Software: ``
- Device ID: `16cc5d7eff6894be94591382fe929610`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=storage/hp-mini/local-lvm`

## Entities

- `binary_sensor.storage_local_lvm_storage_active` — `on`
- `binary_sensor.storage_local_lvm_storage_enabled` — `on`
- `binary_sensor.storage_local_lvm_storage_shared` — `off`
- `sensor.storage_local_lvm_available_storage` — `50.3999039065093`
- `sensor.storage_local_lvm_storage_usage_percentage` — `64.4`
- `sensor.storage_local_lvm_total_storage` — `141.65234375`
- `sensor.storage_local_lvm_used_storage` — `91.2524398434907`