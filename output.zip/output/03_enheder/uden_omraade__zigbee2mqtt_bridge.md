# Zigbee2MQTT Bridge

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Zigbee2MQTT`
- Model: `Bridge`
- Hardware: `EmberZNet 8.0.2 [GA]`
- Software: `2.9.2`
- Device ID: `62e70ae105f9f35fab696bcbfeba1034`

## Entities

- `binary_sensor.zigbee2mqtt_bridge_connection_state` — `on`
- `binary_sensor.zigbee2mqtt_bridge_restart_required` — `unknown`
- `button.zigbee2mqtt_bridge_restart` — `unknown`
- `select.zigbee2mqtt_bridge_log_level` — `info`
- `sensor.zigbee2mqtt_bridge_coordinator_version` — `unknown`
- `sensor.zigbee2mqtt_bridge_network_map` — `unknown`
- `sensor.zigbee2mqtt_bridge_version` — `2.9.2`
- `switch.zigbee2mqtt_bridge_permit_join` — `off`