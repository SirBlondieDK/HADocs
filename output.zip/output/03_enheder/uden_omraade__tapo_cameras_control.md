# Tapo: Cameras Control

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `JurajNyiri`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `38ed394a40c8457a2a137adbcd00112a`
- Configuration URL: `homeassistant://hacs/repository/300358676`

## Entities

- `switch.tapo_cameras_control_pre_release` — `unknown`
- `update.tapo_cameras_control_update` — `off`