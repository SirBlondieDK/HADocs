# Badeværelse spot 2

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `eeffeadd74ef3b61241f630899ded29a`

## Entities

- `light.badevaerelse_spot_2` — `off`
- `select.0xe8ca50de41110000_effect` — `unknown`
- `select.badevaerelse_spot_2_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_2_power_on_behavior` — `unknown`
- `sensor.0xe8ca50de41110000_last_seen` — `unknown`
- `sensor.0xe8ca50de41110000_linkquality` — `unknown`
- `switch.badevaerelse_spot_2_do_not_disturb` — `off`