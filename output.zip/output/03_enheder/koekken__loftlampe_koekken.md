# Loftlampe Køkken

Generated: 2026-07-05 00:57:13

- Area: `Køkken`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Hardware: `1`
- Software: ``
- Device ID: `39f70b7e5c8dd5446bf89a1410b4592c`

## Entities

- `light.loftlampe_kokken` — `on`
- `select.0xa4c138b4051e6603_effect` — `unknown`
- `select.loftlampe_kokken_color_power_on_behavior` — `unknown`
- `sensor.0xa4c138b4051e6603_last_seen` — `unknown`
- `sensor.0xa4c138b4051e6603_linkquality` — `unknown`
- `switch.loftlampe_kokken_do_not_disturb` — `off`