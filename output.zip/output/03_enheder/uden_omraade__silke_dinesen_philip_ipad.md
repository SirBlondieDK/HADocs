# Silke Dinesen Philip - iPad

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPad`
- Hardware: ``
- Software: ``
- Device ID: `27e09a0fec909502d28457c716d98277`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.silke_dinesen_philip_ipad_batteri` — `unavailable`