# adguard

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `1538a47b0a5405fc5602098a02d41770`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/101`

## Entities

- `binary_sensor.adguard_status` — `on`
- `button.adguard_create_snapshot` — `unknown`
- `button.adguard_genstart` — `unknown`
- `button.adguard_start` — `unknown`
- `button.adguard_stop` — `unknown`
- `sensor.adguard_cpu_usage` — `0.0858360077545516`
- `sensor.adguard_disk_usage` — `1.26094436645508`
- `sensor.adguard_max_cpu` — `1`
- `sensor.adguard_max_disk_usage` — `1.90024566650391`
- `sensor.adguard_max_memory_usage` — `0.5`
- `sensor.adguard_memory_usage` — `0.0595169067382812`
- `sensor.adguard_memory_usage_percentage` — `11.9033813476562`
- `sensor.adguard_network_input` — `0.302515191957355`
- `sensor.adguard_network_output` — `0.0424216231331229`
- `sensor.adguard_status` — `running`
- `sensor.adguard_uptime` — `51.4761111111111`