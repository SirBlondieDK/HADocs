# hub stue og soveværelse

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `32b6e944ec05cea9d979c11276098f51`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/7d539119-379e-4331-b93a-a27ec92c2b75`

## Entities

- `button.hub_stue_og_sovevaerelse_favorite_current_song` — `unknown`
- `media_player.hub_stue_og_sovevaerelse_2` — `off`