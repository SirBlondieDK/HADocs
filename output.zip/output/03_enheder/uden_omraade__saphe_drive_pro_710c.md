# Saphe Drive Pro 710C

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `ce2f75b6f4fdee3408bc276832b22036`

## Entities

- `device_tracker.saphe_drive_pro_710c` — `unavailable`
- `sensor.saphe_drive_pro_710c_estimated_distance` — `unavailable`
- `sensor.saphe_drive_pro_710c_power` — `unknown`
- `sensor.saphe_drive_pro_710c_signalstyrke` — `unknown`
- `sensor.saphe_drive_pro_710c_vendor` — `unknown`