# kontakt stue

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `9f5681259007b535cd36d388f1f5c6f4`

## Entities

- `sensor.kontakt_stue_action` — `unavailable`
- `sensor.kontakt_stue_last_seen` — `unknown`
- `sensor.kontakt_stue_linkquality` — `unknown`