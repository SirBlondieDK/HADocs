# Facadelys

Generated: 2026-07-05 00:57:13

- Area: `Udendørs`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Hardware: `gen1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Device ID: `7636480556593cf4fe5d45ff9e9e68a2`
- Configuration URL: `http://192.168.68.150:80`

## Entities

- `binary_sensor.shelly1_3494546a3372_cloud` — `unknown`
- `binary_sensor.shelly1_3494546a3372_input` — `unknown`
- `button.facadelys_reboot` — `unknown`
- `sensor.shelly1_3494546a3372_rssi` — `unknown`
- `sensor.shelly1_3494546a3372_uptime` — `unknown`
- `switch.facadelys` — `off`
- `update.shelly1_3494546a3372_beta_firmware` — `unknown`
- `update.shelly1_3494546a3372_firmware` — `unknown`