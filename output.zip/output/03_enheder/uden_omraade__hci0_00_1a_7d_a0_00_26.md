# hci0 (00:1A:7D:A0:00:26)

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Realtek`
- Model: `Bluetooth Radio (0bda:8771)`
- Hardware: `usb:v1D6Bp0246d0555`
- Software: `6.18.37-haos`
- Device ID: `4c60a51f94fd95052311732c25637b61`

## Entities
