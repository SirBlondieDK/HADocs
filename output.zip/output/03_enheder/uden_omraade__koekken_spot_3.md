# Køkken spot 3

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `1b6c740eb39328f1e8a45b6e759ce606`

## Entities

- `light.kokken_spot_3` — `on`
- `select.0xe8ca50ddf9bc0000_effect` — `unknown`
- `select.kokken_spot_3_color_power_on_behavior` — `unknown`
- `select.kokken_spot_3_power_on_behavior` — `unknown`
- `sensor.0xe8ca50ddf9bc0000_last_seen` — `unknown`
- `sensor.0xe8ca50ddf9bc0000_linkquality` — `unknown`
- `switch.kokken_spot_3_do_not_disturb` — `off`