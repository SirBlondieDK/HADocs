# stue højttaler

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Hardware: ``
- Software: ``
- Device ID: `6527312abe1164d9b2f83a9b4a5258b4`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/c43b3de6-deed-0d8b-08fc-324271e7925a`

## Entities

- `button.stue_hojttaler_favorite_current_song` — `unknown`
- `media_player.stue_hojttaler_2` — `idle`