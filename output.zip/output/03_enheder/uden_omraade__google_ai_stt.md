# Google AI STT

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-lite`
- Hardware: ``
- Software: ``
- Device ID: `5364276f7da9818e895c0d29812d613c`

## Entities

- `stt.google_ai_stt` — `unknown`