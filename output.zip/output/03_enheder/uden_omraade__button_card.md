# button-card

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `custom-cards`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `489b4e603646cf81a158fb32104bb980`
- Configuration URL: `homeassistant://hacs/repository/146194325`

## Entities

- `switch.button_card_pre_release` — `unknown`
- `update.button_card_update` — `off`