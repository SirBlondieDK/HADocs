# Sebastian Dinesen Philip - iPhone

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPhone XR`
- Hardware: ``
- Software: ``
- Device ID: `aa66a31ab624cfb4135cbd191e839a2e`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.sebastian_dinesen_philip_iphone_batteri` — `unavailable`