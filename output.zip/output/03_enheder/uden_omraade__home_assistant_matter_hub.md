# Home-Assistant-Matter-Hub

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Addons by riddix`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `2.0.48`
- Device ID: `9b078d42ccbf9075660c3e16747cebde`
- Configuration URL: `homeassistant://hassio/addon/3fd9e6b0_hamh`

## Entities

- `binary_sensor.home_assistant_matter_hub_korer` — `unknown`
- `sensor.home_assistant_matter_hub_cpu_procent` — `unknown`
- `sensor.home_assistant_matter_hub_hukommelsesprocent` — `unknown`
- `sensor.home_assistant_matter_hub_nyeste_version` — `unknown`
- `sensor.home_assistant_matter_hub_version` — `unknown`
- `switch.home_assistant_matter_hub` — `unknown`
- `update.home_assistant_matter_hub_opdatering` — `off`