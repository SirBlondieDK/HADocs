# Loftlampe soveværelse

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Hardware: `1`
- Software: ``
- Device ID: `e5d97c2ac724098a29905480ce6ba5c6`

## Entities

- `light.loftlampe_sovevaerelse` — `off`
- `select.0xa4c1388d5e4bed62_effect` — `unknown`
- `select.loftlampe_sovevaerelse_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1388d5e4bed62_last_seen` — `unknown`
- `sensor.0xa4c1388d5e4bed62_linkquality` — `unknown`
- `switch.loftlampe_sovevaerelse_do_not_disturb` — `off`