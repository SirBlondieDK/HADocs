# Marlene – Apple Watch

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `Apple Watch Series 7 (GPS + Cellular)`
- Hardware: ``
- Software: ``
- Device ID: `5968b1f7a1602d3c7aad85ceb4d5d1b2`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.marlene_apple_watch_batteri` — `unknown`