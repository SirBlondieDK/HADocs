# Fjernsyn

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `My`
- Model: `Android TV`
- Hardware: ``
- Software: ``
- Device ID: `12ee3e2009adc0e5c4b48c552514dab4`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/upccd3c11bc758`

## Entities

- `button.fjernsyn_favorite_current_song` — `unknown`
- `media_player.fjernsyn` — `idle`