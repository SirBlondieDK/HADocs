# OpenAI AI Task

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini`
- Hardware: ``
- Software: ``
- Device ID: `92e298280131ad47ba4fa84c829d9952`

## Entities

- `ai_task.openai_ai_task` — `unknown`