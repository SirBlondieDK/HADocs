# Sebastians iPad

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPad`
- Hardware: ``
- Software: ``
- Device ID: `2b9591c9acbe658c550d1f0e672e1981`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.sebastians_ipad_batteri` — `unavailable`