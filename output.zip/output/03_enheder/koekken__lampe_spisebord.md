# Lampe spisebord

Generated: 2026-07-05 00:57:13

- Area: `Køkken`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `c743cc9c2b186b103cda116f0e93378a`

## Entities

- `light.lampe_spisebord` — `on`
- `select.0xa4c138660fe2058a_effect` — `unknown`
- `select.lampe_spisebord_color_power_on_behavior` — `unknown`
- `sensor.0xa4c138660fe2058a_last_seen` — `unknown`
- `sensor.0xa4c138660fe2058a_linkquality` — `unknown`
- `switch.lampe_spisebord_do_not_disturb` — `off`