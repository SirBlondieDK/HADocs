# Badeværelse spot 3

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `7ed4b19b38d89e4af6f6cb32b3141d0f`

## Entities

- `light.badevaerelse_spot_3` — `off`
- `select.badevaerelse_spot_3_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_3_effect` — `unknown`
- `select.badevaerelse_spot_3_power_on_behavior` — `unknown`
- `sensor.badevaerelse_spot_3_last_seen` — `unknown`
- `sensor.badevaerelse_spot_3_linkquality` — `unknown`
- `switch.badevaerelse_spot_3_do_not_disturb` — `off`