# stue og soveværelse 

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `fbd9dd353df6f6ff7363fb94dc3f6586`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/9662cd69-dd04-42cb-bd49-3adc2d0e4b7c`

## Entities

- `button.stue_og_sovevaerelse_favorite_current_song` — `unknown`
- `media_player.stue_og_sovevaerelse_2` — `off`