# OpenAI STT

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini-transcribe`
- Hardware: ``
- Software: ``
- Device ID: `bf199ce8c322de53d46dc140f9b7380d`

## Entities

- `stt.openai_stt` — `unknown`