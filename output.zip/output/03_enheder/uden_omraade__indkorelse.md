# Indkorelse

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `aa0739880fbf1f91c7f6c309bc74d7db`
- Configuration URL: `http://192.168.68.161:5000/cameras/indkorelse`

## Entities

- `binary_sensor.indkorelse_all_occupancy` — `off`
- `binary_sensor.indkorelse_car_occupancy` — `off`
- `binary_sensor.indkorelse_dog_occupancy` — `off`
- `binary_sensor.indkorelse_motion` — `off`
- `binary_sensor.indkorelse_person_occupancy` — `off`
- `camera.indkorelse` — `recording`
- `image.indkorelse_car` — `2026-07-04T22:27:38.968318`
- `image.indkorelse_dog` — `2026-07-04T22:27:38.961530`
- `image.indkorelse_person` — `2026-07-04T22:27:38.967685`
- `number.indkorelse_contour_area` — `unknown`
- `number.indkorelse_threshold` — `unknown`
- `sensor.indkorelse_all_active_count` — `0`
- `sensor.indkorelse_all_count` — `0`
- `sensor.indkorelse_camera_fps` — `unknown`
- `sensor.indkorelse_capture_cpu_usage` — `unknown`
- `sensor.indkorelse_car_active_count` — `0`
- `sensor.indkorelse_car_count` — `0`
- `sensor.indkorelse_detect_cpu_usage` — `unknown`
- `sensor.indkorelse_detection_fps` — `unknown`
- `sensor.indkorelse_dog_active_count` — `0`
- `sensor.indkorelse_dog_count` — `0`
- `sensor.indkorelse_ffmpeg_cpu_usage` — `unknown`
- `sensor.indkorelse_person_active_count` — `0`
- `sensor.indkorelse_person_count` — `0`
- `sensor.indkorelse_process_fps` — `unknown`
- `sensor.indkorelse_review_status` — `unknown`
- `sensor.indkorelse_skipped_fps` — `unknown`
- `switch.indkorelse_detect` — `on`
- `switch.indkorelse_improve_contrast` — `unknown`
- `switch.indkorelse_motion` — `on`
- `switch.indkorelse_object_descriptions` — `unknown`
- `switch.indkorelse_recordings` — `on`
- `switch.indkorelse_review_alerts` — `on`
- `switch.indkorelse_review_descriptions` — `unknown`
- `switch.indkorelse_review_detections` — `on`
- `switch.indkorelse_snapshots` — `on`