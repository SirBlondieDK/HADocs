# Home Assistant SkyConnect (9650e525)

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Nabu Casa`
- Model: `Home Assistant SkyConnect`
- Hardware: ``
- Software: `OpenThread RCP None`
- Device ID: `c5b9f202ea7a6552aee521d6e4c053a5`

## Entities

- `switch.home_assistant_skyconnect_9650e525_beta_firmware_updates` — `unknown`
- `update.home_assistant_skyconnect_9650e525_firmware` — `unknown`