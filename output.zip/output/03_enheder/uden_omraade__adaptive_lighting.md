# Adaptive Lighting

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `basnijholt, RubenKelevra, th3w1zard1, protyposis`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `4f234e8776198602d1107e618dc40fd5`
- Configuration URL: `homeassistant://hacs/repository/290261325`

## Entities

- `switch.adaptive_lighting_pre_release` — `unknown`
- `update.adaptive_lighting_update` — `unknown`