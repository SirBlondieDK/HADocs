# Badeværelse

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Hardware: ``
- Software: ``
- Device ID: `26f91837cd8b459d3609ec0ba42a6a95`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/2dcaff17-796b-d43f-2f26-3918513d1474`

## Entities

- `button.badevaerelse_favorite_current_song` — `unknown`
- `media_player.badevaerelse_2` — `idle`