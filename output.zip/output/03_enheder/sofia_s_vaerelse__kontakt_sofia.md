# Kontakt sofia

Generated: 2026-07-05 00:57:13

- Area: `Sofia's værelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `8c1ecc92d25e3b1036d95d458bfb806b`

## Entities

- `sensor.kontakt_sofia_action` — `unknown`
- `sensor.kontakt_sofia_last_seen` — `unknown`
- `sensor.kontakt_sofia_linkquality` — `unknown`