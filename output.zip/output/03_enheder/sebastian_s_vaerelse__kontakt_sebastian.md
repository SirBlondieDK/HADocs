# Kontakt Sebastian

Generated: 2026-07-05 00:57:13

- Area: `Sebastian's værelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `54f12ff2cdb8bfcff3227f38433a2887`

## Entities

- `sensor.0x0000000001714ade_last_seen` — `unknown`
- `sensor.0x0000000001714ade_linkquality` — `unknown`
- `sensor.kontakt_sebastian_action` — `unknown`