# Sun

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `309f4d51475c29dab5dd699a70acc16d`

## Entities

- `binary_sensor.sun_solar_rising` — `unknown`
- `sensor.sun_next_dawn` — `2026-07-05T01:49:27+00:00`
- `sensor.sun_next_dusk` — `2026-07-05T21:05:41+00:00`
- `sensor.sun_next_midnight` — `2026-07-04T23:28:04+00:00`
- `sensor.sun_next_noon` — `2026-07-05T11:27:58+00:00`
- `sensor.sun_next_rising` — `2026-07-05T02:49:01+00:00`
- `sensor.sun_next_setting` — `2026-07-05T20:06:29+00:00`
- `sensor.sun_solar_azimuth` — `unknown`
- `sensor.sun_solar_elevation` — `unknown`