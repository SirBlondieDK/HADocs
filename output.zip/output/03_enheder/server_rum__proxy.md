# proxy

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `4cdb46fab53e40e6e0728a7fc9cc4fb3`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/103`

## Entities

- `binary_sensor.proxy_status` — `on`
- `button.proxy_create_snapshot` — `unknown`
- `button.proxy_genstart` — `unknown`
- `button.proxy_start` — `unknown`
- `button.proxy_stop` — `unknown`
- `sensor.proxy_cpu_usage` — `0.202506309556855`
- `sensor.proxy_disk_usage` — `2.76371765136719`
- `sensor.proxy_max_cpu` — `1`
- `sensor.proxy_max_disk_usage` — `7.77682113647461`
- `sensor.proxy_max_memory_usage` — `0.5`
- `sensor.proxy_memory_usage` — `0.0891914367675781`
- `sensor.proxy_memory_usage_percentage` — `17.8382873535156`
- `sensor.proxy_network_input` — `0.389009656384587`
- `sensor.proxy_network_output` — `0.0637820847332478`
- `sensor.proxy_status` — `running`
- `sensor.proxy_uptime` — `51.4761111111111`