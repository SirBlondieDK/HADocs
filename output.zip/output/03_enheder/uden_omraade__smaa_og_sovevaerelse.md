# små og soveværelse

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `f0b7942af92c7511ac7a4d5a5f23c4c4`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/3e0011cd-9881-4370-83d0-c88c2198138b`

## Entities

- `button.sma_og_sovevaerelse_favorite_current_song` — `unknown`
- `media_player.sma_og_sovevaerelse_2` — `off`