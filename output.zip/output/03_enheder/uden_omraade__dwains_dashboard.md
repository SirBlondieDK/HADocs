# Dwains Dashboard

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `dwainscheeren`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `f718ce8001dd2d4295009f1bca285052`
- Configuration URL: `homeassistant://hacs/repository/222687548`

## Entities

- `switch.dwains_dashboard_pre_release` — `unknown`
- `update.dwains_dashboard_update` — `off`