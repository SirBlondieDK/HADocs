# Deco Stue

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Hardware: `2.0`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Device ID: `eb153c30757c6f50719060b2ab4ce0e3`

## Entities

- `binary_sensor.kitchen_deco_deco_online_2` — `on`
- `binary_sensor.kitchen_deco_internet_online_2` — `on`
- `device_tracker.kitchen_deco_2` — `home`
- `device_tracker.kitchen_deco_d100c` — `home`
- `device_tracker.kitchen_deco_google_home` — `home`
- `device_tracker.kitchen_deco_ipad_3` — `home`
- `device_tracker.kitchen_deco_iphone` — `home`
- `device_tracker.kitchen_deco_p100` — `home`
- `device_tracker.kitchen_deco_pc_8a31` — `home`
- `device_tracker.kitchen_deco_sirblondiedk` — `home`
- `device_tracker.server_rum_deco_stue_maja_iphone` — `home`
- `device_tracker.vaskerum_deco_google_home` — `home`
- `device_tracker.vaskerum_deco_wiz_44c896` — `home`
- `sensor.kitchen_deco_backhaul_type_2` — `unknown`
- `sensor.kitchen_deco_bssid_2_4_ghz_2` — `unknown`
- `sensor.kitchen_deco_bssid_5_ghz_2` — `unknown`
- `sensor.kitchen_deco_connected_clients_2` — `10`
- `sensor.kitchen_deco_ip_address_2` — `unknown`
- `sensor.kitchen_deco_kitchen_down_2` — `0.125`
- `sensor.kitchen_deco_kitchen_up_2` — `0.125`