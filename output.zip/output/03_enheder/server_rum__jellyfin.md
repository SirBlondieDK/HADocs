# jellyfin

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `733f2615da74d23377123db4ac88c034`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/102`

## Entities

- `binary_sensor.jellyfin_status` — `on`
- `button.jellyfin_create_snapshot` — `unknown`
- `button.jellyfin_genstart` — `unknown`
- `button.jellyfin_start` — `unknown`
- `button.jellyfin_stop` — `unknown`
- `sensor.jellyfin_cpu_usage` — `0.154171470238758`
- `sensor.jellyfin_disk_usage` — `3.84213256835938`
- `sensor.jellyfin_max_cpu` — `2`
- `sensor.jellyfin_max_disk_usage` — `15.5809288024902`
- `sensor.jellyfin_max_memory_usage` — `2.0`
- `sensor.jellyfin_memory_usage` — `0.3289794921875`
- `sensor.jellyfin_memory_usage_percentage` — `16.448974609375`
- `sensor.jellyfin_network_input` — `0.297598976641893`
- `sensor.jellyfin_network_output` — `0.384919934906065`
- `sensor.jellyfin_status` — `running`
- `sensor.jellyfin_uptime` — `51.4761111111111`