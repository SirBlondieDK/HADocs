# Local Tuya

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `xZetsubou`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `4fa3c1ee24ae974d344d348c43713c2f`
- Configuration URL: `homeassistant://hacs/repository/653793773`

## Entities

- `switch.local_tuya_pre_release` — `unknown`
- `update.local_tuya_update` — `off`