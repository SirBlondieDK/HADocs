# soveværelset og de smås værelse

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `72d14c49aa65492dbdcb0be3575d94d4`

## Entities

- `media_player.sovevaerelset_og_de_smas_vaerelse_2` — `off`