# Music Assistant

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Music Assistant`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `2.9.5`
- Device ID: `9ae0fa51291f0d8e38b0ea3126e29a65`
- Configuration URL: `homeassistant://hassio/addon/d5369777_music_assistant`

## Entities

- `binary_sensor.music_assistant_server_korer` — `unknown`
- `sensor.music_assistant_server_cpu_procent` — `unknown`
- `sensor.music_assistant_server_hukommelsesprocent` — `unknown`
- `sensor.music_assistant_server_nyeste_version` — `unknown`
- `sensor.music_assistant_server_version` — `unknown`
- `switch.music_assistant_server` — `unknown`
- `update.music_assistant_server_update` — `off`