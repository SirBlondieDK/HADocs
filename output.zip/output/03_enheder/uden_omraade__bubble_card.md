# Bubble Card

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Clooos`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `ee16536f283fb0854f0c6ccda3e0db92`
- Configuration URL: `homeassistant://hacs/repository/680112919`

## Entities

- `switch.bubble_card_pre_release` — `unknown`
- `update.bubble_card_update` — `off`