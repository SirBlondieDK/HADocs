# Loftlampe Sofia

Generated: 2026-07-05 00:57:13

- Area: `Sofia's værelse`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `93b15ebb3d3792db16578fa463cccf1a`

## Entities

- `light.loftlampe_sofia` — `on`
- `select.0xa4c138312c122baa_effect` — `unknown`
- `select.loftlampe_sofia_color_power_on_behavior` — `unknown`
- `sensor.0xa4c138312c122baa_last_seen` — `unknown`
- `sensor.0xa4c138312c122baa_linkquality` — `unknown`
- `switch.loftlampe_sofia_do_not_disturb` — `off`