# Group Element

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `custom-cards`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `999e280c2eee1a94b8045a11dae90efe`
- Configuration URL: `homeassistant://hacs/repository/179491130`

## Entities

- `switch.group_element_pre_release` — `unknown`
- `update.group_element_update` — `off`