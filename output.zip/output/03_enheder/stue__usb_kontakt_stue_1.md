# Usb kontakt stue 1

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Tuya`
- Model: `3 gang switch`
- Hardware: `1`
- Software: ``
- Device ID: `2084e9ab99b4b0767a446ad75f90bfd5`

## Entities

- `sensor.0xa4c138ab3197ecdf_last_seen` — `unknown`
- `sensor.0xa4c138ab3197ecdf_linkquality` — `unknown`
- `switch.usb_kontakt_stue_1_center` — `off`
- `switch.usb_kontakt_stue_1_left` — `off`
- `switch.usb_kontakt_stue_1_right` — `off`