# Google Translate en com

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google`
- Model: `Google Translate TTS`
- Hardware: ``
- Software: ``
- Device ID: `9a54c9565a8c580eb7df01fa2db8bb98`

## Entities

- `tts.google_en_com` — `unknown`