# Temp stue

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `SONOFF`
- Model: `Temperature and humidity sensor with screen`
- Hardware: `0`
- Software: `2.3.0`
- Device ID: `02e8b410fcf6b8de037b2862eb890045`

## Entities

- `number.temp_stue_comfort_humidity_max` — `unknown`
- `number.temp_stue_comfort_humidity_min` — `unknown`
- `number.temp_stue_comfort_temperature_max` — `unknown`
- `number.temp_stue_comfort_temperature_min` — `unknown`
- `number.temp_stue_humidity_calibration` — `unknown`
- `number.temp_stue_temperature_calibration` — `unknown`
- `select.temp_stue_temperature_units` — `unknown`
- `sensor.0x0cae5ffffed10fd2_last_seen` — `unknown`
- `sensor.0x0cae5ffffed10fd2_linkquality` — `unknown`
- `sensor.temp_stue_battery` — `100`
- `sensor.temp_stue_humidity` — `56.6`
- `sensor.temp_stue_temperature` — `23.2`
- `update.temp_stue` — `off`