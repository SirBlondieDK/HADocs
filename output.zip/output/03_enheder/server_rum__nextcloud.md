# nextcloud

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `7bb04740c0a2cacd26bd3f61a1c0eff1`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/105`

## Entities

- `binary_sensor.nextcloud_status` — `on`
- `button.nextcloud_create_snapshot` — `unknown`
- `button.nextcloud_genstart` — `unknown`
- `button.nextcloud_start` — `unknown`
- `button.nextcloud_stop` — `unknown`
- `sensor.nextcloud_cpu_usage` — `1.06169974640096`
- `sensor.nextcloud_disk_usage` — `17.7850952148438`
- `sensor.nextcloud_max_cpu` — `2`
- `sensor.nextcloud_max_disk_usage` — `19.5181427001953`
- `sensor.nextcloud_max_memory_usage` — `2.0`
- `sensor.nextcloud_memory_usage` — `0.143207550048828`
- `sensor.nextcloud_memory_usage_percentage` — `7.16037750244141`
- `sensor.nextcloud_network_input` — `0.314147878438234`
- `sensor.nextcloud_network_output` — `0.0221770396456122`
- `sensor.nextcloud_status` — `running`
- `sensor.nextcloud_uptime` — `50.8016666666667`