# lampe de små pære 2

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `505994613aacea95c3752265939bc715`

## Entities

- `light.lampe_de_sma_paere_2` — `off`
- `select.0xa4c1387f1efbb7b4_effect` — `unknown`
- `select.lampe_de_sma_paere_2_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1387f1efbb7b4_last_seen` — `unknown`
- `sensor.0xa4c1387f1efbb7b4_linkquality` — `unknown`
- `switch.lampe_de_sma_paere_2_do_not_disturb` — `off`