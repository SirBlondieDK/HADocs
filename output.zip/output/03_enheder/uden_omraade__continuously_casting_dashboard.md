# Continuously Casting Dashboard

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `b0mbays`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `734f1f1698c78b94db7412ee65de5253`
- Configuration URL: `homeassistant://hacs/repository/618105292`

## Entities

- `switch.continuously_casting_dashboard_pre_release` — `unknown`
- `update.continuously_casting_dashboard_update` — `off`