# Kontakt Køkken

Generated: 2026-07-05 00:57:13

- Area: `Køkken`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `527de3e0e5b045f91f017adc033362ce`

## Entities

- `sensor.kontakt_kokken_action` — `unknown`
- `sensor.kontakt_kokken_last_seen` — `unknown`
- `sensor.kontakt_kokken_linkquality` — `unknown`