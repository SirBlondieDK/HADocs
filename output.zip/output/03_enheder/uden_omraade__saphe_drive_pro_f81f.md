# Saphe Drive Pro F81F

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `deba71db20c779351bf7f182bf526615`

## Entities

- `device_tracker.saphe_drive_pro_f81f` — `unavailable`
- `sensor.saphe_drive_pro_f81f_estimated_distance` — `unavailable`
- `sensor.saphe_drive_pro_f81f_power` — `unknown`
- `sensor.saphe_drive_pro_f81f_signalstyrke` — `unknown`
- `sensor.saphe_drive_pro_f81f_vendor` — `unknown`