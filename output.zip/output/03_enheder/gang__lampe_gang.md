# Lampe gang

Generated: 2026-07-05 00:57:13

- Area: `Gang`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Hardware: `1`
- Software: ``
- Device ID: `599dbd85b6161528e0967c8814a4b5b6`

## Entities

- `light.lampe_gang` — `off`
- `select.0xa4c1389de2ac12d0_effect` — `unknown`
- `select.lampe_gang_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1389de2ac12d0_last_seen` — `unknown`
- `sensor.0xa4c1389de2ac12d0_linkquality` — `unknown`
- `switch.lampe_gang_do_not_disturb` — `off`