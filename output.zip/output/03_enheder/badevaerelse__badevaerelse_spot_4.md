# Badeværelse spot 4

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `6e35ae2c40224a396cb259507103f627`

## Entities

- `light.badevaerelse_spot_4` — `off`
- `select.0xe8ca50de7c1c0000_effect` — `unknown`
- `select.badevaerelse_spot_4_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_4_power_on_behavior` — `unknown`
- `sensor.0xe8ca50de7c1c0000_last_seen` — `unknown`
- `sensor.0xe8ca50de7c1c0000_linkquality` — `unknown`
- `switch.badevaerelse_spot_4_do_not_disturb` — `off`