# Lampe Sofabord

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `WiZ`
- Model: `SHRGBC`
- Hardware: `ESP24 01`
- Software: `1.37.0`
- Device ID: `9572efd21a050462c7a7d32db6340774`

## Entities

- `light.wiz_rgbw_tunable_44c896` — `off`
- `number.wiz_rgbw_tunable_44c896_effect_speed` — `unavailable`
- `sensor.wiz_rgbw_tunable_44c896_signalstyrke` — `unknown`
- `sensor.wiz_rgbw_tunable_44c896_strom` — `unknown`