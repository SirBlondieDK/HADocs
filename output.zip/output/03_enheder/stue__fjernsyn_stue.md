# Fjernsyn Stue

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `My`
- Model: `Android TV`
- Hardware: ``
- Software: ``
- Device ID: `def7a7e5a1c30636e701a0e6c64ee3d5`

## Entities

- `media_player.fjernsyn_stue` — `off`