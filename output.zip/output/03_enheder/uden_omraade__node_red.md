# Node-RED

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant Community Apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `22.0.0`
- Device ID: `fc37021947b67bc3c7d4d5c15f1c6c06`
- Configuration URL: `homeassistant://hassio/addon/a0d7b954_nodered`

## Entities

- `binary_sensor.node_red_korer` — `unknown`
- `sensor.node_red_cpu_procent` — `unknown`
- `sensor.node_red_hukommelsesprocent` — `unknown`
- `sensor.node_red_nyeste_version` — `unknown`
- `sensor.node_red_version` — `unknown`
- `switch.node_red` — `unknown`
- `update.node_red_update` — `off`