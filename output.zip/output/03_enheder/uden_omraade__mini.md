# mini 

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `1a4c4753edb52d8b89770e1eeae8468f`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/ba9828ea-ffd9-4d81-8111-eb2bf34605ae`

## Entities

- `button.mini_favorite_current_song` — `unknown`
- `media_player.mini_2` — `off`