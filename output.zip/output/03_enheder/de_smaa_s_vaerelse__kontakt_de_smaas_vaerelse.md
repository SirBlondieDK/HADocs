# Kontakt de smås værelse

Generated: 2026-07-05 00:57:13

- Area: `De små's værelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `0fe82e4cd03faa5fe5c035ee0b1e1783`

## Entities

- `sensor.kontakt_de_smas_vaerelse_action` — `unknown`
- `sensor.kontakt_de_smas_vaerelse_last_seen` — `unknown`
- `sensor.kontakt_de_smas_vaerelse_linkquality` — `unknown`