# Pool

Generated: 2026-07-05 00:57:13

- Area: `terrasse`
- Manufacturer: `Tuya`
- Model: `SH-OP01`
- Hardware: ``
- Software: ``
- Device ID: `4f5522be3e213d667ec6b5e8e5905132`

## Entities

- `sensor.pool_current` — `unknown`
- `sensor.pool_power` — `unknown`
- `sensor.pool_total_energy` — `unavailable`
- `sensor.pool_voltage` — `unknown`
- `switch.pool_socket_1` — `unavailable`