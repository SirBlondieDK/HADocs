# Home Assistant Operating System

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Operating System`
- Hardware: ``
- Software: `18.1`
- Device ID: `7edfb5d31924497d14e8a66ff9647d33`

## Entities

- `sensor.home_assistant_operating_system_newest_version` — `unknown`
- `sensor.home_assistant_operating_system_version` — `unknown`
- `update.home_assistant_operating_system_update` — `off`