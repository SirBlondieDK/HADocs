# Bent Dinesen Schmidt – Apple Watch

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `Apple Watch Series 7 (GPS + Cellular)`
- Hardware: ``
- Software: ``
- Device ID: `e3440bbb07361a609338a6fb558310b6`
- Configuration URL: `https://icloud.com/`

## Entities

- `device_tracker.bent_dinesen_schmidt_apple_watch` — `unavailable`
- `sensor.bent_dinesen_schmidt_apple_watch_batteri` — `unavailable`