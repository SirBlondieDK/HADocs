# Terasse

Generated: 2026-07-05 00:57:13

- Area: `terrasse`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `f2f8a18dbcd8f9b5081dc3fac19aee0e`
- Configuration URL: `http://192.168.68.161:5000/cameras/terasse`

## Entities

- `binary_sensor.terasse_all_occupancy` — `off`
- `binary_sensor.terasse_car_occupancy` — `off`
- `binary_sensor.terasse_dog_occupancy` — `off`
- `binary_sensor.terasse_motion` — `off`
- `binary_sensor.terasse_person_occupancy` — `off`
- `camera.terasse` — `recording`
- `image.terasse_car` — `2026-07-04T22:27:38.965589`
- `image.terasse_dog` — `2026-07-04T22:27:38.966948`
- `image.terasse_person` — `2026-07-04T22:27:38.962813`
- `number.terasse_contour_area` — `unknown`
- `number.terasse_threshold` — `unknown`
- `sensor.terasse_all_active_count` — `0`
- `sensor.terasse_all_count` — `0`
- `sensor.terasse_camera_fps` — `unknown`
- `sensor.terasse_capture_cpu_usage` — `unknown`
- `sensor.terasse_car_active_count` — `0`
- `sensor.terasse_car_count` — `0`
- `sensor.terasse_detect_cpu_usage` — `unknown`
- `sensor.terasse_detection_fps` — `unknown`
- `sensor.terasse_dog_active_count` — `0`
- `sensor.terasse_dog_count` — `0`
- `sensor.terasse_ffmpeg_cpu_usage` — `unknown`
- `sensor.terasse_person_active_count` — `0`
- `sensor.terasse_person_count` — `0`
- `sensor.terasse_process_fps` — `unknown`
- `sensor.terasse_review_status` — `unknown`
- `sensor.terasse_skipped_fps` — `unknown`
- `switch.terasse_detect` — `on`
- `switch.terasse_improve_contrast` — `unknown`
- `switch.terasse_motion` — `on`
- `switch.terasse_object_descriptions` — `unknown`
- `switch.terasse_recordings` — `on`
- `switch.terasse_review_alerts` — `on`
- `switch.terasse_review_descriptions` — `unknown`
- `switch.terasse_review_detections` — `on`
- `switch.terasse_snapshots` — `on`