# Kaffe hjørnet

Generated: 2026-07-05 00:57:13

- Area: `Køkken`
- Manufacturer: `TP-Link`
- Model: `P100`
- Hardware: `2.0`
- Software: `1.4.3 Build 251205 Rel.141413`
- Device ID: `c39b4a294931f652a5fad4ee1e41a61a`

## Entities

- `binary_sensor.kaffe_hjornet_cloud_connection` — `on`
- `button.kaffe_hjornet_genstart` — `unknown`
- `number.kaffe_hjornet_turn_off_in` — `120`
- `sensor.kaffe_hjornet_auto_off_at` — `unknown`
- `sensor.kaffe_hjornet_device_time` — `unknown`
- `sensor.kaffe_hjornet_on_since` — `unknown`
- `sensor.kaffe_hjornet_signal_level` — `2`
- `sensor.kaffe_hjornet_signal_strength` — `unknown`
- `sensor.kaffe_hjornet_ssid` — `unknown`
- `switch.kaffe_hjornet` — `on`
- `switch.kaffe_hjornet_auto_off_enabled` — `off`
- `switch.kaffe_hjornet_auto_update_enabled` — `on`
- `switch.kaffe_hjornet_led` — `on`