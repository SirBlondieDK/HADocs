# TP-Link Deco

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `amosyuen`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `6c3367c2f883e5ff3dcfff9c9520ca21`
- Configuration URL: `homeassistant://hacs/repository/442001863`

## Entities

- `switch.tp_link_deco_pre_release` — `unknown`
- `update.tp_link_deco_update` — `off`