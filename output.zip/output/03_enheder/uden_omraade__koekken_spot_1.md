# køkken spot 1

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `b6371c520535f582e70d63b36a8d1093`

## Entities

- `light.kokken_spot_1` — `on`
- `select.0xe8ca50dda00d0000_effect` — `unknown`
- `select.kokken_spot_1_color_power_on_behavior` — `unknown`
- `select.kokken_spot_1_power_on_behavior` — `unknown`
- `sensor.0xe8ca50dda00d0000_last_seen` — `unknown`
- `sensor.0xe8ca50dda00d0000_linkquality` — `unknown`
- `switch.kokken_spot_1_do_not_disturb` — `off`