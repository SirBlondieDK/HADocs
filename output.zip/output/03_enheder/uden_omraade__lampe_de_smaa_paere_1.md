# lampe de små pære 1

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `f23af833b07b9a2bafcbae0c8d77019c`

## Entities

- `light.lampe_de_sma_paere_1` — `off`
- `select.0xa4c1386c83e5e3a6_effect` — `unknown`
- `select.lampe_de_sma_paere_1_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1386c83e5e3a6_last_seen` — `unknown`
- `sensor.0xa4c1386c83e5e3a6_linkquality` — `unknown`
- `switch.lampe_de_sma_paere_1_do_not_disturb` — `off`