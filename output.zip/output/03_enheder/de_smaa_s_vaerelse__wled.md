# WLED

Generated: 2026-07-05 00:57:13

- Area: `De små's værelse`
- Manufacturer: `WLED`
- Model: `FOSS`
- Hardware: `esp32`
- Software: `16.0.0`
- Device ID: `b6bd358efe0641ac8a50d1a1447def3b`
- Configuration URL: `http://192.168.68.162`

## Entities

- `binary_sensor.wled_firmware_3` — `unknown`
- `button.wled_genstart_3` — `unavailable`
- `device_tracker.kitchen_deco_ledss` — `not_home`
- `light.wled_3` — `unavailable`
- `number.wled_intensity_3` — `unavailable`
- `number.wled_speed_3` — `unavailable`
- `select.wled_color_palette_3` — `unavailable`
- `select.wled_live_override_3` — `unavailable`
- `select.wled_playlist_3` — `unavailable`
- `select.wled_preset_3` — `unavailable`
- `sensor.wled_estimated_current_3` — `unavailable`
- `sensor.wled_free_memory_3` — `unknown`
- `sensor.wled_ip_3` — `unavailable`
- `sensor.wled_led_count_3` — `unavailable`
- `sensor.wled_max_current_3` — `unavailable`
- `sensor.wled_uptime_3` — `unknown`
- `sensor.wled_wi_fi_bssid_3` — `unknown`
- `sensor.wled_wi_fi_channel_3` — `unknown`
- `sensor.wled_wi_fi_rssi_3` — `unknown`
- `sensor.wled_wi_fi_signal_3` — `unknown`
- `switch.wled_freeze` — `unavailable`
- `switch.wled_nightlight_3` — `unavailable`
- `switch.wled_reverse_3` — `unavailable`
- `switch.wled_sync_receive_3` — `unavailable`
- `switch.wled_sync_send_3` — `unavailable`
- `update.wled_firmware_3` — `unavailable`