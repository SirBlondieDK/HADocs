# Foran

Generated: 2026-07-05 00:57:13

- Area: `Udendørs`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `f198340d9d36c45eabfcec8d39585640`
- Configuration URL: `http://192.168.68.161:5000/cameras/`

## Entities

- `binary_sensor.foran_all_occupancy` — `off`
- `binary_sensor.foran_person_occupancy` — `off`
- `sensor.foran_all_active_count` — `0`
- `sensor.foran_all_count` — `0`
- `sensor.foran_person_active_count` — `0`
- `sensor.foran_person_count` — `0`