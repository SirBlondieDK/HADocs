# HACS

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `hacs.xyz`
- Model: ``
- Hardware: ``
- Software: `2.0.5`
- Device ID: `4d33fb26b170f9ad1ecd3e77bc5e4e20`
- Configuration URL: `homeassistant://hacs`

## Entities

- `switch.hacs_pre_release` — `unknown`
- `update.hacs_update` — `off`