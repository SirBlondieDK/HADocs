# Badeværelse spot 5

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `74cd909413081879f779bc3b5c7fa28a`

## Entities

- `light.badevaerelse_spot_5` — `off`
- `select.0xe8ca50deb78c0000_effect` — `unknown`
- `select.badevaerelse_spot_5_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_5_power_on_behavior` — `unknown`
- `sensor.0xe8ca50deb78c0000_last_seen` — `unknown`
- `sensor.0xe8ca50deb78c0000_linkquality` — `unknown`
- `switch.badevaerelse_spot_5_do_not_disturb` — `off`