# Sirblondiedk iPhone

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPhone 13`
- Hardware: ``
- Software: ``
- Device ID: `2a3ecefa4cb823bb01433c8f54cf7737`
- Configuration URL: `https://icloud.com/`

## Entities

- `device_tracker.sirblondiedk_iphone` — `unavailable`
- `sensor.sirblondiedk_iphone_batteri` — `unavailable`