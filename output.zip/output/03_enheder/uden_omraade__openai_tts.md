# OpenAI TTS

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `OpenAI`
- Model: `gpt-4o-mini-tts`
- Hardware: ``
- Software: ``
- Device ID: `539623f7627fe800e0ca4783959d289b`

## Entities

- `tts.openai_tts` — `unknown`