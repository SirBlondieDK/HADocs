# Atomic Calendar Revive

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `totaldebug`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `72f190bccdf04d03ec7d6689e583f4b0`
- Configuration URL: `homeassistant://hacs/repository/246549747`

## Entities

- `switch.atomic_calendar_revive_pre_release` — `unknown`
- `update.atomic_calendar_revive_update` — `off`