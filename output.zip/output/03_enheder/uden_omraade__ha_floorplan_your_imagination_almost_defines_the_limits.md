# ha-floorplan 🖌🎨 | Your imagination (almost) defines the limits

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `ExperienceLovelace`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `13df4dc20ab65c6c67b758e3e933cbb4`
- Configuration URL: `homeassistant://hacs/repository/188323494`

## Entities

- `switch.ha_floorplan_your_imagination_almost_defines_the_limits_pre_release` — `unknown`
- `update.ha_floorplan_your_imagination_almost_defines_the_limits_update` — `off`