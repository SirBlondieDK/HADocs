# File editor

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `6.0.0`
- Device ID: `e358baede96d918d44749d17095e1b4c`
- Configuration URL: `homeassistant://hassio/addon/core_configurator`

## Entities

- `binary_sensor.file_editor_korer` — `unknown`
- `sensor.file_editor_cpu_procent` — `unknown`
- `sensor.file_editor_hukommelsesprocent` — `unknown`
- `sensor.file_editor_nyeste_version` — `unknown`
- `sensor.file_editor_version` — `unknown`
- `switch.file_editor` — `unknown`
- `update.file_editor_update` — `off`