# Carport

Generated: 2026-07-05 00:57:13

- Area: `Carport`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `ffa01d4378f73a9c605397af53a8aad3`
- Configuration URL: `http://192.168.68.161:5000/cameras/carport`

## Entities

- `binary_sensor.carport_all_occupancy` — `off`
- `binary_sensor.carport_car_occupancy` — `off`
- `binary_sensor.carport_dog_occupancy` — `off`
- `binary_sensor.carport_motion` — `off`
- `binary_sensor.carport_person_occupancy` — `off`
- `camera.carport` — `recording`
- `image.carport_car` — `2026-07-04T22:27:38.966380`
- `image.carport_dog` — `2026-07-04T22:27:38.969634`
- `image.carport_person` — `2026-07-04T22:27:38.964073`
- `number.carport_contour_area` — `unknown`
- `number.carport_threshold` — `unknown`
- `sensor.carport_all_active_count` — `0`
- `sensor.carport_all_count` — `0`
- `sensor.carport_camera_fps` — `unknown`
- `sensor.carport_capture_cpu_usage` — `unknown`
- `sensor.carport_car_active_count` — `0`
- `sensor.carport_car_count` — `0`
- `sensor.carport_detect_cpu_usage` — `unknown`
- `sensor.carport_detection_fps` — `unknown`
- `sensor.carport_dog_active_count` — `0`
- `sensor.carport_dog_count` — `0`
- `sensor.carport_ffmpeg_cpu_usage` — `unknown`
- `sensor.carport_person_active_count` — `0`
- `sensor.carport_person_count` — `0`
- `sensor.carport_process_fps` — `unknown`
- `sensor.carport_review_status` — `unknown`
- `sensor.carport_skipped_fps` — `unknown`
- `switch.carport_detect` — `on`
- `switch.carport_improve_contrast` — `unknown`
- `switch.carport_motion` — `on`
- `switch.carport_object_descriptions` — `unknown`
- `switch.carport_recordings` — `on`
- `switch.carport_review_alerts` — `on`
- `switch.carport_review_descriptions` — `unknown`
- `switch.carport_review_detections` — `on`
- `switch.carport_snapshots` — `on`