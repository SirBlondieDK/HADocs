# højttaler uden hubs

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Google Cast Group`
- Hardware: ``
- Software: ``
- Device ID: `1ca7c357e7ff8e3976ac89d27adb1079`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/794eb624-ef0d-43f5-a69d-999cf9d4e32c`

## Entities

- `button.hojttaler_uden_hubs_favorite_current_song` — `unknown`
- `media_player.hojttaler_uden_hubs_2` — `off`