# card-mod

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `thomasloven`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `7873feac090e676b22aa8b59244faac1`
- Configuration URL: `homeassistant://hacs/repository/190927524`

## Entities

- `switch.card_mod_pre_release` — `unknown`
- `update.card_mod_update` — `off`