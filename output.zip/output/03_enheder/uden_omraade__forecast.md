# Forecast

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Met.no`
- Model: `Forecast`
- Hardware: ``
- Software: ``
- Device ID: `b829fbe17935438312ec15253658e844`
- Configuration URL: `https://www.met.no/en`

## Entities

- `weather.forecast_hjem` — `cloudy`