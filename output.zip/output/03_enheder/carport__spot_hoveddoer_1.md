# Spot Hoveddør 1

Generated: 2026-07-05 00:57:13

- Area: `Carport`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `cb3468da8c26d5c854faf25e5e55695f`

## Entities

- `light.spot_hoveddor_1` — `unavailable`
- `select.0xe8ca50de33300000_effect` — `unknown`
- `select.spot_hoveddor_1_color_power_on_behavior` — `unavailable`
- `select.spot_hoveddor_1_power_on_behavior` — `unavailable`
- `sensor.0xe8ca50de33300000_last_seen` — `unknown`
- `sensor.0xe8ca50de33300000_linkquality` — `unknown`
- `switch.spot_hoveddor_1_do_not_disturb` — `unavailable`