# HADashboard

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `77638229fbc88e713bf2c7fb0819a1e8`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/108`

## Entities

- `binary_sensor.hadashboard_status` — `off`
- `button.hadashboard_create_snapshot` — `unknown`
- `button.hadashboard_genstart` — `unknown`
- `button.hadashboard_start` — `unknown`
- `button.hadashboard_stop` — `unknown`
- `sensor.hadashboard_cpu_usage` — `0`
- `sensor.hadashboard_disk_usage` — `0.0`
- `sensor.hadashboard_max_cpu` — `2`
- `sensor.hadashboard_max_disk_usage` — `20.0`
- `sensor.hadashboard_max_memory_usage` — `1.0`
- `sensor.hadashboard_memory_usage` — `0.0`
- `sensor.hadashboard_memory_usage_percentage` — `0.0`
- `sensor.hadashboard_network_input` — `0.0`
- `sensor.hadashboard_network_output` — `0.0`
- `sensor.hadashboard_status` — `stopped`
- `sensor.hadashboard_uptime` — `0.0`