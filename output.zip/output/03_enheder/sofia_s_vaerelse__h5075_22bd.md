# H5075 22BD

Generated: 2026-07-05 00:57:13

- Area: `Sofia's værelse`
- Manufacturer: `Govee`
- Model: `H5075`
- Hardware: ``
- Software: ``
- Device ID: `e2610d92462b7663d4029ff919c96b7d`

## Entities

- `sensor.h5075_22bd_battery` — `100`
- `sensor.h5075_22bd_humidity` — `58.8`
- `sensor.h5075_22bd_signal_strength` — `unknown`
- `sensor.h5075_22bd_temperature` — `23.9`