# Aula

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `scaarup`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `b3e2170faa86134bb424b52808acd691`
- Configuration URL: `homeassistant://hacs/repository/560307075`

## Entities

- `switch.aula_pre_release` — `unknown`
- `update.aula_update` — `off`