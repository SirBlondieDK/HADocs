# Sebastian

Generated: 2026-07-05 00:57:13

- Area: `Sebastian's værelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Hardware: ``
- Software: ``
- Device ID: `3720af76c740a7a3d46bfbcc5d44e6e2`

## Entities

- `media_player.sebastian` — `off`