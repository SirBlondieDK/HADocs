# Hikvision NVR / IP Camera

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `maciej-or`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `84e47a83d41f15e17aaf5036696b0104`
- Configuration URL: `homeassistant://hacs/repository/597502676`

## Entities

- `switch.hikvision_nvr_ip_camera_pre_release` — `unknown`
- `update.hikvision_nvr_ip_camera_update` — `off`