# HP ENVY Inspire 7200 series

Generated: 2026-07-05 00:57:13

- Area: `Computer hjørne`
- Manufacturer: `HP`
- Model: `ENVY Inspire 7200 series`
- Hardware: ``
- Software: `NOVBASPP1N002.2621A.00`
- Device ID: `a7fe240ef7bbb7ebba936fff0ea44e32`
- Configuration URL: `http://192.168.68.156/#hId-pgAirPrint`

## Entities

- `sensor.hp_envy_inspire_7200_series` — `idle`
- `sensor.hp_envy_inspire_7200_series_black_cartridge` — `40`
- `sensor.hp_envy_inspire_7200_series_tri_color_cartridge` — `30`
- `sensor.hp_envy_inspire_7200_series_uptime` — `unknown`