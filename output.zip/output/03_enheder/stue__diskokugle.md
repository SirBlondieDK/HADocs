# Diskokugle

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Hardware: `gen1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Device ID: `7baac863afc61ecdabda429d389ff7c5`
- Configuration URL: `http://192.168.68.110:80`

## Entities

- `binary_sensor.diskokugle_cloud` — `unknown`
- `binary_sensor.diskokugle_input` — `unknown`
- `button.diskokugle_reboot` — `unknown`
- `sensor.diskokugle_rssi` — `unknown`
- `sensor.diskokugle_uptime` — `unknown`
- `switch.diskokugle` — `off`
- `update.diskokugle_beta_firmware_update` — `unknown`
- `update.diskokugle_firmware_update` — `unknown`