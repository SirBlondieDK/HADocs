# Car Area

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Frigate`
- Model: `5.15.4/0.17.1-416a9b7`
- Hardware: ``
- Software: ``
- Device ID: `6f1bc14aeb4131de0e597b4bbfcf9c6e`
- Configuration URL: `http://192.168.68.161:5000/cameras/`

## Entities

- `binary_sensor.car_area_all_occupancy` — `off`
- `binary_sensor.car_area_car_occupancy` — `unavailable`
- `binary_sensor.car_area_dog_occupancy` — `unavailable`
- `binary_sensor.car_area_person_occupancy` — `off`
- `sensor.car_area_all_active_count` — `0`
- `sensor.car_area_all_count` — `0`
- `sensor.car_area_car_active_count` — `unavailable`
- `sensor.car_area_car_count` — `unavailable`
- `sensor.car_area_dog_active_count` — `unavailable`
- `sensor.car_area_dog_count` — `unavailable`
- `sensor.car_area_person_active_count` — `0`
- `sensor.car_area_person_count` — `0`