# Deco Køkken

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Hardware: `2.0`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Device ID: `8c8d0d448281927aedf0057936918997`

## Entities

- `binary_sensor.kitchen_deco_deco_online` — `on`
- `binary_sensor.kitchen_deco_internet_online` — `on`
- `device_tracker.kitchen_deco` — `home`
- `device_tracker.kitchen_deco_fjernsyn_stue` — `home`
- `device_tracker.kitchen_deco_google_home_2` — `home`
- `device_tracker.kitchen_deco_google_home_mini` — `home`
- `device_tracker.kitchen_deco_ipad_2` — `home`
- `device_tracker.kitchen_deco_phone_c504` — `home`
- `device_tracker.kitchen_deco_phone_d366` — `home`
- `device_tracker.kitchen_deco_wiz_0123ac` — `home`
- `device_tracker.server_rum_deco_stue_sebastiipiphone` — `home`
- `device_tracker.vaskerum_deco_google_home_mini` — `home`
- `sensor.kitchen_deco_backhaul_type` — `unknown`
- `sensor.kitchen_deco_bssid_2_4_ghz` — `unknown`
- `sensor.kitchen_deco_bssid_5_ghz` — `unknown`
- `sensor.kitchen_deco_connected_clients` — `9`
- `sensor.kitchen_deco_ip_address` — `unknown`
- `sensor.kitchen_deco_kitchen_down` — `0.0`
- `sensor.kitchen_deco_kitchen_up` — `0.0`