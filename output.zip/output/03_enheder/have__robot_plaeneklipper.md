# Robot plæneklipper

Generated: 2026-07-05 00:57:13

- Area: `Have`
- Manufacturer: `Adano Robotic Mower`
- Model: `RMC500E20V-ECWNTS`
- Hardware: `230500`
- Software: `50003`
- Device ID: `cd52db7eb929048a3714e846498d92c5`

## Entities

- `binary_sensor.robot_plaeneklipper_dock` — `off`
- `binary_sensor.robot_plaeneklipper_multizone` — `off`
- `binary_sensor.robot_plaeneklipper_multizone_auto` — `off`
- `binary_sensor.robot_plaeneklipper_online` — `off`
- `binary_sensor.robot_plaeneklipper_regn_sensor_aktiv` — `on`
- `button.robot_plaeneklipper_hjem` — `unknown`
- `button.robot_plaeneklipper_klip_kant` — `unknown`
- `button.robot_plaeneklipper_pause` — `unknown`
- `button.robot_plaeneklipper_start` — `2026-04-29T09:48:47.245783+00:00`
- `device_tracker.robot_plaeneklipper_robot_lokation` — `unknown`
- `lawn_mower.robot_plaeneklipper` — `Standby`
- `number.robot_plaeneklipper_regn_forsinkelse` — `180`
- `number.robot_plaeneklipper_zone_1_prioritet` — `25`
- `number.robot_plaeneklipper_zone_1_start` — `0`
- `number.robot_plaeneklipper_zone_2_prioritet` — `25`
- `number.robot_plaeneklipper_zone_2_start` — `25`
- `number.robot_plaeneklipper_zone_3_prioritet` — `25`
- `number.robot_plaeneklipper_zone_3_start` — `50`
- `number.robot_plaeneklipper_zone_4_prioritet` — `25`
- `number.robot_plaeneklipper_zone_4_start` — `75`
- `sensor.robot_plaeneklipper_aktuel_arbejdstid` — `0`
- `sensor.robot_plaeneklipper_batteri` — `33`
- `sensor.robot_plaeneklipper_fejl` — `normal`
- `sensor.robot_plaeneklipper_fejlkode` — `0`
- `sensor.robot_plaeneklipper_regn_sensor` — `Dry`
- `sensor.robot_plaeneklipper_regn_sensor_forsinkelse` — `180`
- `sensor.robot_plaeneklipper_regn_sensor_nedtaeller` — `180`
- `sensor.robot_plaeneklipper_robot_status` — `Standby`
- `sensor.robot_plaeneklipper_status_fejl` — ``
- `sensor.robot_plaeneklipper_tidsstyrring` — `Schedule`
- `sensor.robot_plaeneklipper_wifi_styrke` — `0`
- `sensor.robot_plaeneklipper_zone_1_start` — `0`
- `sensor.robot_plaeneklipper_zone_2_start` — `25`
- `sensor.robot_plaeneklipper_zone_3_start` — `50`
- `sensor.robot_plaeneklipper_zone_4_start` — `75`
- `switch.robot_plaeneklipper_multizone` — `off`
- `switch.robot_plaeneklipper_multizone_auto` — `off`
- `switch.robot_plaeneklipper_regn_sensor` — `on`
- `switch.robot_plaeneklipper_tidsstyrring` — `on`
- `text.robot_plaeneklipper_ugeplan_fredag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_lordag` — `00:00 - 00:00`
- `text.robot_plaeneklipper_ugeplan_mandag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_onsdag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_sondag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_tirsdag` — `00:00 - 00:00`
- `text.robot_plaeneklipper_ugeplan_torsdag` — `00:00 - 00:00`