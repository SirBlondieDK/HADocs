# Kontakt over seng

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `8fa43c382e02ab919af2baf548709fa6`

## Entities

- `sensor.kontakt_over_seng_action` — `unavailable`
- `sensor.kontakt_over_seng_last_seen` — `unknown`
- `sensor.kontakt_over_seng_linkquality` — `unknown`