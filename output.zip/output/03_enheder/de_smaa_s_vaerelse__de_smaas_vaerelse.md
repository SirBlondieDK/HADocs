# De smås værelse

Generated: 2026-07-05 00:57:13

- Area: `De små's værelse`
- Manufacturer: `Google Inc.`
- Model: `Google Home Mini`
- Hardware: ``
- Software: ``
- Device ID: `52d9fd2e6173f766151208c186b9797c`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/c1c5bd0f-2d9f-166d-0e83-533203957319`

## Entities

- `button.de_smas_vaerelse_favorite_current_song` — `unknown`
- `media_player.de_smas_vaerelse_2` — `idle`