# XPED-0060370B54C3

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `34a33b5c70795b6359bd8d34712de057`

## Entities

- `device_tracker.xped_0060370b54c3` — `unavailable`
- `sensor.xped_0060370b54c3_estimated_distance` — `unavailable`
- `sensor.xped_0060370b54c3_power` — `unknown`
- `sensor.xped_0060370b54c3_signalstyrke` — `unknown`
- `sensor.xped_0060370b54c3_vendor` — `unknown`