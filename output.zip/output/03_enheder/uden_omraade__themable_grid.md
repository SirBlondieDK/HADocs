# themable-grid

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `nervetattoo`
- Model: `plugin`
- Hardware: ``
- Software: ``
- Device ID: `939a391a6a935a555c7c19376565e0cc`
- Configuration URL: `homeassistant://hacs/repository/321773656`

## Entities

- `switch.themable_grid_pre_release` — `unknown`
- `update.themable_grid_update` — `off`