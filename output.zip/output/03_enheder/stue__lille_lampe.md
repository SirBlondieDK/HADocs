# Lille Lampe

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `d0fd58f5bc1b4e79f100991557d7a0c8`

## Entities

- `light.lille_lampe` — `off`
- `select.lille_lampe_color_power_on_behavior` — `unknown`
- `select.lille_lampe_effect` — `unknown`
- `select.lille_lampe_power_on_behavior` — `on`
- `sensor.0xe8ca50de54d40000_last_seen` — `unknown`
- `sensor.0xe8ca50de54d40000_linkquality` — `unknown`
- `switch.lille_lampe_do_not_disturb` — `off`