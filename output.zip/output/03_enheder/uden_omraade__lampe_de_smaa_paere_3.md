# lampe de små pære 3

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Tuya`
- Model: `Zigbee 3.0 18W led light bulb E27 RGBCW`
- Hardware: `0`
- Software: `z.1.0`
- Device ID: `0f03eeb4e49536c7c5aac0e6978f4547`

## Entities

- `light.lampe_de_sma_paere_3` — `off`
- `select.0xa4c138bf6a50d1db_effect` — `unknown`
- `select.lampe_de_sma_paere_3_color_power_on_behavior` — `unknown`
- `sensor.0xa4c138bf6a50d1db_last_seen` — `unknown`
- `sensor.0xa4c138bf6a50d1db_linkquality` — `unknown`
- `switch.lampe_de_sma_paere_3_do_not_disturb` — `off`