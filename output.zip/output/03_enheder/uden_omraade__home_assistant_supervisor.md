# Home Assistant Supervisor

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Supervisor`
- Hardware: ``
- Software: `2026.06.2`
- Device ID: `c4241307530f7448c6602182aaa8dc85`

## Entities

- `sensor.home_assistant_supervisor_cpu_percent` — `unknown`
- `sensor.home_assistant_supervisor_memory_percent` — `unknown`
- `update.home_assistant_supervisor_update` — `off`