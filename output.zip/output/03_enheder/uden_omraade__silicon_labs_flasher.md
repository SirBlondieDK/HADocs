# Silicon Labs Flasher

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `0.5.0`
- Device ID: `eed742a43b35c29ddca885d94426e500`
- Configuration URL: `homeassistant://hassio/addon/core_silabs_flasher`

## Entities

- `binary_sensor.silicon_labs_flasher_korer` — `unknown`
- `sensor.silicon_labs_flasher_cpu_procent` — `unknown`
- `sensor.silicon_labs_flasher_hukommelsesprocent` — `unknown`
- `sensor.silicon_labs_flasher_nyeste_version` — `unknown`
- `sensor.silicon_labs_flasher_version` — `unknown`
- `switch.silicon_labs_flasher` — `unknown`
- `update.silicon_labs_flasher_update` — `off`