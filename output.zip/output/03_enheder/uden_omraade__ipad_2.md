# iPad (2)

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPad (8th Generation)`
- Hardware: ``
- Software: ``
- Device ID: `0e8c87eb28cfb3e3378a09dd12be924f`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.ipad_2_batteri` — `unavailable`