# Soveværelse

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google Inc.`
- Model: `Chromecast`
- Hardware: ``
- Software: ``
- Device ID: `2d048f186f5f1b33963f8a714458fed2`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/98fc538c-3df8-7e8a-5bba-c2ccb4b0e766`

## Entities

- `button.sovevaerelse_favorite_current_song` — `unavailable`
- `media_player.sovevaerelse_2` — `unavailable`