# Google AI Conversation

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-lite`
- Hardware: ``
- Software: ``
- Device ID: `87b0b54a0b026819b2dfd3e0b5e7bd82`

## Entities

- `conversation.google_ai_conversation` — `unknown`