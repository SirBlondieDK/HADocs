# iPad

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPad (9th generation)`
- Hardware: ``
- Software: ``
- Device ID: `c35ad75965722ea8250d05f26d1685ec`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.ipad_batteri` — `unavailable`