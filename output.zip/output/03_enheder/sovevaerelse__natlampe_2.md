# Natlampe 2

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `b871badb33d866c29d0ad59958e45910`

## Entities

- `light.natlampe_2` — `off`
- `select.0xe8ca50ddee080000_effect` — `unknown`
- `select.natlampe_2_color_power_on_behavior` — `unknown`
- `select.natlampe_2_power_on_behavior` — `on`
- `sensor.0xe8ca50ddee080000_last_seen` — `unknown`
- `sensor.0xe8ca50ddee080000_linkquality` — `unknown`
- `switch.natlampe_2_do_not_disturb` — `off`