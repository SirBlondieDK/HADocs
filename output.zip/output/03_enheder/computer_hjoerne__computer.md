# Computer

Generated: 2026-07-05 00:57:13

- Area: `Computer hjørne`
- Manufacturer: `Tuya`
- Model: `SHP-102 - Smart Power Plug`
- Hardware: ``
- Software: ``
- Device ID: `82fcda8d37ef0e3701d9d9a4a8807b7a`

## Entities

- `select.pejs_power_on_behavior` — `last`
- `sensor.pejs_current` — `unknown`
- `sensor.pejs_power` — `unknown`
- `sensor.pejs_total_energy` — `0.807`
- `sensor.pejs_voltage` — `unknown`
- `switch.pejs_socket_1` — `on`