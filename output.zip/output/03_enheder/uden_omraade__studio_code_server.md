# Studio Code Server

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant Community Apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `6.0.1`
- Device ID: `f4642d527ed34da0474da1a05c1597c8`
- Configuration URL: `homeassistant://hassio/addon/a0d7b954_vscode`

## Entities

- `binary_sensor.studio_code_server_korer` — `unknown`
- `sensor.studio_code_server_cpu_procent` — `unknown`
- `sensor.studio_code_server_hukommelsesprocent` — `unknown`
- `sensor.studio_code_server_nyeste_version` — `unknown`
- `sensor.studio_code_server_version` — `unknown`
- `switch.studio_code_server` — `unknown`
- `update.studio_code_server_opdatering` — `off`