# Deco loft

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: `TP-Link Deco`
- Model: `M4R`
- Hardware: `2.0`
- Software: `1.8.2 Build 20251027 Rel. 36869`
- Device ID: `4aa834b27cca6d224f0d1497f6dee5eb`

## Entities

- `binary_sensor.vaskerum_deco_deco_online` — `on`
- `binary_sensor.vaskerum_deco_internet_online` — `on`
- `device_tracker.kitchen_deco_google_home_mini_2` — `home`
- `device_tracker.kitchen_deco_iot_device_0a30` — `home`
- `device_tracker.kitchen_deco_iot_device_2d49` — `home`
- `device_tracker.server_rum_deco_loft_device_1501` — `home`
- `device_tracker.server_rum_deco_loft_device_1738` — `home`
- `device_tracker.server_rum_deco_loft_device_3d54` — `home`
- `device_tracker.server_rum_deco_loft_device_4f06` — `home`
- `device_tracker.vaskerum_deco` — `home`
- `device_tracker.vaskerum_deco_adguard` — `home`
- `device_tracker.vaskerum_deco_ajax_002133f1` — `home`
- `device_tracker.vaskerum_deco_d210` — `home`
- `device_tracker.vaskerum_deco_device_a5e8` — `home`
- `device_tracker.vaskerum_deco_device_d57f` — `home`
- `device_tracker.vaskerum_deco_esp_c2432f` — `home`
- `device_tracker.vaskerum_deco_google_home_mini_2` — `home`
- `device_tracker.vaskerum_deco_homeassistant` — `home`
- `device_tracker.vaskerum_deco_kamera_1` — `home`
- `device_tracker.vaskerum_deco_kamera_2` — `home`
- `device_tracker.vaskerum_deco_kamera_3` — `home`
- `device_tracker.vaskerum_deco_proxy_server` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546a3372` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546a890c` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546ae397` — `home`
- `device_tracker.vaskerum_deco_wlan0` — `home`
- `device_tracker.vaskerum_deco_wlan0_2` — `home`
- `select.server_rum_deco_loft_polling_interval` — `30`
- `sensor.vaskerum_deco_bssid_2_4_ghz` — `unknown`
- `sensor.vaskerum_deco_bssid_5_ghz` — `unknown`
- `sensor.vaskerum_deco_connected_clients` — `24`
- `sensor.vaskerum_deco_cpu_usage` — `unknown`
- `sensor.vaskerum_deco_cpu_usage_raw` — `unknown`
- `sensor.vaskerum_deco_ip_address` — `unknown`
- `sensor.vaskerum_deco_memory_usage` — `unknown`
- `sensor.vaskerum_deco_memory_usage_raw` — `unknown`
- `sensor.vaskerum_deco_total_down` — `0.125`
- `sensor.vaskerum_deco_total_up` — `0.125`
- `sensor.vaskerum_deco_vaskerum_down` — `0.0`
- `sensor.vaskerum_deco_vaskerum_up` — `0.0`
- `switch.vaskerum_deco_polling` — `on`