# Soveværelse hub

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `Google Inc.`
- Model: `Google Nest Hub`
- Hardware: ``
- Software: ``
- Device ID: `4b5fe3c95982c93a7055ad5cc7b5408e`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/3a888fc3-81ff-beaf-4814-cf5111cc4d90`

## Entities

- `button.sovevaerelse_hub_favorite_current_song` — `unknown`
- `media_player.sovevaerelse_hub_2` — `idle`