# Terminal & SSH

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Official apps`
- Model: `Home Assistant App`
- Hardware: ``
- Software: `10.3.0`
- Device ID: `be16dc7ab2fd5a934795edd41f1ba2f8`
- Configuration URL: `homeassistant://hassio/addon/core_ssh`

## Entities

- `binary_sensor.terminal_ssh_korer` — `unknown`
- `sensor.terminal_ssh_cpu_procent` — `unknown`
- `sensor.terminal_ssh_hukommelsesprocent` — `unknown`
- `sensor.terminal_ssh_nyeste_version` — `unknown`
- `sensor.terminal_ssh_version` — `unknown`
- `switch.terminal_ssh` — `unknown`
- `update.terminal_ssh_update` — `off`