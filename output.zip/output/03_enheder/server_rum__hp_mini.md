# hp-mini

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Node`
- Hardware: ``
- Software: ``
- Device ID: `6b18dfcd65fac45c5f85f9a7257dad4c`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=node/hp-mini`

## Entities

- `binary_sensor.hp_mini_backup_status` — `off`
- `binary_sensor.hp_mini_status` — `on`
- `button.hp_mini_genstart` — `unknown`
- `button.hp_mini_shut_down` — `unknown`
- `button.hp_mini_start_all` — `unknown`
- `button.hp_mini_stop_all` — `unknown`
- `button.hp_mini_suspend_all` — `unknown`
- `sensor.hp_mini_backup_duration` — `1.4`
- `sensor.hp_mini_cpu_usage` — `21.2652844231792`
- `sensor.hp_mini_disk_usage` — `28.1986274719238`
- `sensor.hp_mini_last_backup` — `2026-06-28T11:36:10+00:00`
- `sensor.hp_mini_max_cpu` — `6`
- `sensor.hp_mini_max_disk_usage` — `67.8722076416016`
- `sensor.hp_mini_max_memory_usage` — `7.41191482543945`
- `sensor.hp_mini_memory_usage` — `6.26721572875977`
- `sensor.hp_mini_memory_usage_percentage` — `84.5559599153675`
- `sensor.hp_mini_status` — `online`
- `sensor.hp_mini_uptime` — `51.4816666666667`