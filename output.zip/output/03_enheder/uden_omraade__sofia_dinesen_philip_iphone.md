# Sofia Dinesen Philip - iPhone

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPhone XR`
- Hardware: ``
- Software: ``
- Device ID: `edc83005eb2b60a91f5e744fac6e0fb5`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.sofia_dinesen_philip_iphone_batteri` — `unavailable`