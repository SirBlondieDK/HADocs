# homeassistant

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `VM`
- Hardware: ``
- Software: ``
- Device ID: `f3f72db2c4f97355244b4134b148a71d`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=qemu/100`

## Entities

- `binary_sensor.homeassistant_status` — `on`
- `button.homeassistant` — `unknown`
- `button.homeassistant_create_snapshot` — `unknown`
- `button.homeassistant_genstart` — `unknown`
- `button.homeassistant_hibernate` — `unknown`
- `button.homeassistant_reset` — `unknown`
- `button.homeassistant_shut_down` — `unknown`
- `button.homeassistant_start` — `unknown`
- `button.homeassistant_stop` — `unknown`
- `sensor.homeassistant_cpu_usage` — `3.74657441150223`
- `sensor.homeassistant_disk_usage` — `0.0`
- `sensor.homeassistant_max_cpu` — `4`
- `sensor.homeassistant_max_disk_usage` — `32.0`
- `sensor.homeassistant_max_memory_usage` — `4.0`
- `sensor.homeassistant_memory_usage` — `3.65859222412109`
- `sensor.homeassistant_memory_usage_percentage` — `91.4648056030273`
- `sensor.homeassistant_network_input` — `3.73513714782894`
- `sensor.homeassistant_network_output` — `1.39521459303796`
- `sensor.homeassistant_status` — `running`
- `sensor.homeassistant_uptime` — `51.1969444444444`