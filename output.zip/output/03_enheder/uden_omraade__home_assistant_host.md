# Home Assistant Host

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Host`
- Hardware: ``
- Software: ``
- Device ID: `e72f6b1b1c976440c65bab812d3355c5`

## Entities

- `sensor.home_assistant_host_apparmor_version` — `unknown`
- `sensor.home_assistant_host_disk_free` — `unknown`
- `sensor.home_assistant_host_disk_total` — `unknown`
- `sensor.home_assistant_host_disk_used` — `unknown`
- `sensor.home_assistant_host_os_agent_version` — `unknown`