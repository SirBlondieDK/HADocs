# Bevægelses sensor badeværelse

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Luminance motion sensor`
- Hardware: `1`
- Software: `0104012026`
- Device ID: `f72fb98d67b6b504b51ecf425cc27659`

## Entities

- `binary_sensor.bevaegelses_sensor_badevaerelse_occupancy` — `off`
- `number.bevaegelses_sensor_badevaerelse_illuminance_interval` — `60`
- `select.bevaegelses_sensor_badevaerelse_keep_time` — `30`
- `select.bevaegelses_sensor_badevaerelse_sensitivity` — `high`
- `sensor.0xa4c138b01f675fef_last_seen` — `unknown`
- `sensor.0xa4c138b01f675fef_linkquality` — `unknown`
- `sensor.bevaegelses_sensor_badevaerelse_battery` — `90`
- `sensor.bevaegelses_sensor_badevaerelse_illuminance` — `0`