# Marlene Ravn

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Apple`
- Model: `iPhone 13`
- Hardware: ``
- Software: ``
- Device ID: `f51990219bec0fa7840aebbb7e7abcfc`
- Configuration URL: `https://icloud.com/`

## Entities

- `sensor.marlene_ravn_batteri` — `unknown`