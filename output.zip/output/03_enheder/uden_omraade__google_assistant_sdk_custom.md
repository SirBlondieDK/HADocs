# Google Assistant SDK Custom

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `tronikos`
- Model: `integration`
- Hardware: ``
- Software: ``
- Device ID: `0b2e930ef8416512546fdd894fe93ba0`
- Configuration URL: `homeassistant://hacs/repository/606225263`

## Entities

- `switch.google_assistant_sdk_custom_pre_release` — `unknown`
- `update.google_assistant_sdk_custom_update` — `off`