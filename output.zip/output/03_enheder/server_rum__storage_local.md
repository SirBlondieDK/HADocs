# Storage (local)

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Storage`
- Hardware: ``
- Software: ``
- Device ID: `99b3aab16b93474cd839c965f549c6f5`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=storage/hp-mini/local`

## Entities

- `binary_sensor.storage_local_storage_active` — `on`
- `binary_sensor.storage_local_storage_enabled` — `on`
- `binary_sensor.storage_local_storage_shared` — `off`
- `sensor.storage_local_available_storage` — `36.1821746826172`
- `sensor.storage_local_storage_usage_percentage` — `41.5`
- `sensor.storage_local_total_storage` — `67.8722076416016`
- `sensor.storage_local_used_storage` — `28.1986274719238`