# Badeværelse spot 1

Generated: 2026-07-05 00:57:13

- Area: `Badeværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `61068ed5432e5a9f08caf9daeb18ce1e`

## Entities

- `light.badevaerelse_spot_1` — `off`
- `select.0xe8ca50ddf96c0000_effect` — `unknown`
- `select.badevaerelse_spot_1_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_1_power_on_behavior` — `unknown`
- `sensor.0xe8ca50ddf96c0000_last_seen` — `unknown`
- `sensor.0xe8ca50ddf96c0000_linkquality` — `unknown`
- `switch.badevaerelse_spot_1_do_not_disturb` — `off`