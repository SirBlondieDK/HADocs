# Spillemaskine

Generated: 2026-07-05 00:57:13

- Area: `Stue`
- Manufacturer: `Tuya`
- Model: `SHP-102 - Smart Power Plug`
- Hardware: ``
- Software: ``
- Device ID: `5e9db843d5d200d821d9f2f656024edb`

## Entities

- `select.spillemaskine_power_on_behavior` — `last`
- `sensor.spillemaskine_current` — `unknown`
- `sensor.spillemaskine_power` — `unknown`
- `sensor.spillemaskine_total_energy` — `0`
- `sensor.spillemaskine_voltage` — `unknown`
- `switch.spillemaskine_socket_1` — `off`