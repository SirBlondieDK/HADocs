# Natlampe

Generated: 2026-07-05 00:57:13

- Area: `Soveværelse`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `e8b88b506845b349c6d90f0c1bd6e8d0`

## Entities

- `light.natlampe` — `off`
- `select.0xe8ca50de90a20000_effect` — `unknown`
- `select.natlampe_color_power_on_behavior` — `unknown`
- `select.natlampe_power_on_behavior` — `on`
- `sensor.0xe8ca50de90a20000_last_seen` — `unknown`
- `sensor.0xe8ca50de90a20000_linkquality` — `unknown`
- `switch.natlampe_do_not_disturb` — `off`