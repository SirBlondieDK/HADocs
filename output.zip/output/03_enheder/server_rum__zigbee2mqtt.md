# zigbee2mqtt

Generated: 2026-07-05 00:57:13

- Area: `Server rum`
- Manufacturer: ``
- Model: `Container`
- Hardware: ``
- Software: ``
- Device ID: `966508cdadd30a4e6cb57a4abfe455db`
- Configuration URL: `https://192.168.68.143:8006/#v1:0:=lxc/104`

## Entities

- `binary_sensor.zigbee2mqtt_status` — `on`
- `button.zigbee2mqtt_create_snapshot` — `unknown`
- `button.zigbee2mqtt_genstart` — `unknown`
- `button.zigbee2mqtt_start` — `unknown`
- `button.zigbee2mqtt_stop` — `unknown`
- `sensor.zigbee2mqtt_cpu_usage` — `0.0654187049391485`
- `sensor.zigbee2mqtt_disk_usage` — `2.38711547851562`
- `sensor.zigbee2mqtt_max_cpu` — `2`
- `sensor.zigbee2mqtt_max_disk_usage` — `4.83950805664062`
- `sensor.zigbee2mqtt_max_memory_usage` — `1.0`
- `sensor.zigbee2mqtt_memory_usage` — `0.100597381591797`
- `sensor.zigbee2mqtt_memory_usage_percentage` — `10.0597381591797`
- `sensor.zigbee2mqtt_network_input` — `0.320973188616335`
- `sensor.zigbee2mqtt_network_output` — `0.0570139894261956`
- `sensor.zigbee2mqtt_status` — `running`
- `sensor.zigbee2mqtt_uptime` — `51.4761111111111`