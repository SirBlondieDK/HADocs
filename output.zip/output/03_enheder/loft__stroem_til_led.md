# Strøm til Led

Generated: 2026-07-05 00:57:13

- Area: `Loft`
- Manufacturer: `Shelly`
- Model: `Shelly 1`
- Hardware: `gen1`
- Software: `20230913-112003/v1.14.0-gcb84623`
- Device ID: `afb4d12a0af173aa81db220defadbd83`
- Configuration URL: `http://192.168.68.120:80`

## Entities

- `binary_sensor.shelly1_3494546ae397_cloud` — `unknown`
- `binary_sensor.shelly1_3494546ae397_input` — `unknown`
- `button.shelly1_3494546ae397_reboot` — `unknown`
- `sensor.shelly1_3494546ae397_rssi` — `unknown`
- `sensor.shelly1_3494546ae397_uptime` — `unknown`
- `switch.shelly1_3494546ae397` — `off`
- `update.shelly1_3494546ae397_beta_firmware_update` — `unknown`
- `update.shelly1_3494546ae397_firmware_update` — `unknown`