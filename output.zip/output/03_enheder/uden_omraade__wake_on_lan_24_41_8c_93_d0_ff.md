# Wake on LAN 24:41:8c:93:d0:ff

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: ``
- Model: ``
- Hardware: ``
- Software: ``
- Device ID: `31664c29791d54c01257be45bde881d0`

## Entities

- `button.wake_on_lan_24_41_8c_93_d0_ff` — `2025-01-08T20:33:46.742203+00:00`
- `device_tracker.server_rum_deco_kokken_sebastianpc` — `not_home`