# Backup

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Backup`
- Hardware: ``
- Software: `2026.7.1`
- Device ID: `c64a76f6d45f719777dff61255971471`
- Configuration URL: `homeassistant://config/backup`

## Entities

- `event.backup_automatic_backup` — `2026-07-04T03:40:28.313+00:00`
- `sensor.backup_backup_manager_state` — `idle`
- `sensor.backup_last_attempted_automatic_backup` — `2026-07-04T03:40:03+00:00`
- `sensor.backup_last_successful_automatic_backup` — `2026-07-04T03:40:28+00:00`
- `sensor.backup_next_scheduled_automatic_backup` — `2026-07-08T03:04:40+00:00`