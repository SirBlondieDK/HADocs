# Loftlampe bryggers

Generated: 2026-07-05 00:57:13

- Area: `Bryggers`
- Manufacturer: `Tuya`
- Model: `Zigbee RGB+CCT light`
- Hardware: `1`
- Software: ``
- Device ID: `a7f7dbbb4e74a357f189f457a8e33da3`

## Entities

- `light.loftlampe_bryggers` — `off`
- `select.0xa4c1389d8fc50e9e_effect` — `unknown`
- `select.loftlampe_bryggers_color_power_on_behavior` — `unknown`
- `sensor.0xa4c1389d8fc50e9e_last_seen` — `unknown`
- `sensor.0xa4c1389d8fc50e9e_linkquality` — `unknown`
- `switch.loftlampe_bryggers_do_not_disturb` — `off`