# d5369777-music-assistant

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Jellyfin`
- Model: `Music Assistant`
- Hardware: ``
- Software: `2.9.5`
- Device ID: `1e4cee7408fc86256bcc848854875b96`

## Entities

- `media_player.d5369777_music_assistant` — `idle`