# Home Assistant Core

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Home Assistant`
- Model: `Home Assistant Core`
- Hardware: ``
- Software: `2026.7.1`
- Device ID: `dad3b82ea156fea4f4ec639da2663310`

## Entities

- `sensor.home_assistant_core_cpu_percent` — `unknown`
- `sensor.home_assistant_core_memory_percent` — `unknown`
- `update.home_assistant_core_update` — `off`