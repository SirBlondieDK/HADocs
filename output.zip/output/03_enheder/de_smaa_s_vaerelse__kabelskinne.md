# Kabelskinne

Generated: 2026-07-05 00:57:13

- Area: `De små's værelse`
- Manufacturer: `Tuya`
- Model: `DELTACO SH-P03USB2`
- Hardware: ``
- Software: ``
- Device ID: `b7af5780888b30cc788e98b566ceba09`

## Entities

- `light.kabelskinne_usb_1` — `off`
- `switch.deltaco_sh_p03usb2_socket` — `unknown`
- `switch.deltaco_sh_p03usb2_socket_1` — `unknown`
- `switch.deltaco_sh_p03usb2_socket_2` — `off`
- `switch.deltaco_sh_p03usb2_socket_3` — `off`
- `switch.deltaco_sh_p03usb2_usb_1` — `off`