# Køkken

Generated: 2026-07-05 00:57:13

- Area: `Køkken`
- Manufacturer: `Google Inc.`
- Model: `Google Home`
- Hardware: ``
- Software: ``
- Device ID: `5aad5c3c222108c18e94ee936b6199a2`
- Configuration URL: `http://d5369777-music-assistant:8094/#/settings/editplayer/d369e358-1735-27ae-93e0-e26914d6f04e`

## Entities

- `button.kokken_favorite_current_song` — `unknown`
- `media_player.kokken_2` — `idle`