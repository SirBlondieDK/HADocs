# Google AI Task

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `Google`
- Model: `gemini-3.1-flash-lite`
- Hardware: ``
- Software: ``
- Device ID: `82d4e691567a64ccad8e7eb77755717a`

## Entities

- `ai_task.google_ai_task` — `unknown`