# Spot Hoveddør 2

Generated: 2026-07-05 00:57:13

- Area: `Carport`
- Manufacturer: `Tuya`
- Model: `Zigbee LED bulb`
- Hardware: `0`
- Software: `1.3.6`
- Device ID: `8290abd5ade8bfde4f367df162c0e81e`

## Entities

- `light.spot_hoveddor_2` — `unavailable`
- `select.0xe8ca50ddfe570000_effect` — `unknown`
- `select.spot_hoveddor_2_color_power_on_behavior` — `unavailable`
- `select.spot_hoveddor_2_power_on_behavior` — `unavailable`
- `sensor.0xe8ca50ddfe570000_last_seen` — `unknown`
- `sensor.0xe8ca50ddfe570000_linkquality` — `unknown`
- `switch.spot_hoveddor_2_do_not_disturb` — `unavailable`