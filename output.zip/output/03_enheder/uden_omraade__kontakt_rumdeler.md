# Kontakt Rumdeler

Generated: 2026-07-05 00:57:13

- Area: `Uden område`
- Manufacturer: `EnOcean`
- Model: `Pushbutton transmitter module`
- Hardware: ``
- Software: ``
- Device ID: `d99d9b76bd44f24b011bc9f3a5a40c9e`

## Entities

- `sensor.kontakt_rumdeler_action` — `unavailable`
- `sensor.kontakt_rumdeler_last_seen` — `unknown`
- `sensor.kontakt_rumdeler_linkquality` — `unknown`