# 01 Overview

Generated: 2026-07-05 00:57:13

## Health Score: `42/100`

- 98 real entities are unavailable (-25)
- 14 real entities are unknown (-14)
- 1 batteries are low (-4)
- 59 physical devices have no area (-10)
- 68 duplicate friendly names found (-5)
- 206 system/service entities were ignored in Health Score

## System

- Home Assistant version: `2026.7.1`
- Location: `Hjem`
- Time zone: `Europe/Copenhagen`
- States: `982`
- Entities: `1620`
- Devices: `189`
- Areas: `18`
- Raw unknown states: `143`
- Raw unavailable states: `176`
- Real unknown states: `14`
- Real unavailable states: `98`
- Ignored unknown/unavailable states: `206`

## Domains

- `ai_task`: 2
- `automation`: 18
- `binary_sensor`: 134
- `button`: 79
- `calendar`: 13
- `camera`: 5
- `conversation`: 2
- `device_tracker`: 68
- `event`: 1
- `image`: 9
- `input_boolean`: 1
- `input_button`: 1
- `input_datetime`: 1
- `input_select`: 1
- `input_text`: 1
- `lawn_mower`: 1
- `light`: 51
- `media_player`: 42
- `notify`: 6
- `number`: 63
- `person`: 4
- `schedule`: 1
- `script`: 11
- `select`: 106
- `sensor`: 770
- `siren`: 1
- `stt`: 3
- `switch`: 155
- `text`: 7
- `todo`: 1
- `tts`: 4
- `update`: 50
- `weather`: 1
- `zone`: 7

## Platforms

- `adano`: 46
- `aula`: 11
- `automation`: 18
- `backup`: 5
- `cast`: 20
- `cloud`: 3
- `continuously_casting_dashboards`: 11
- `dwains_dashboard`: 1
- `file`: 1
- `frigate`: 135
- `google`: 8
- `google_generative_ai_conversation`: 4
- `google_translate`: 1
- `govee_ble`: 4
- `group`: 4
- `hacs`: 46
- `hassio`: 91
- `homeassistant_sky_connect`: 2
- `ibeacon`: 25
- `icloud`: 12
- `input_boolean`: 1
- `input_button`: 1
- `input_datetime`: 1
- `input_select`: 1
- `input_text`: 1
- `ipp`: 4
- `jellyfin`: 2
- `met`: 1
- `mobile_app`: 307
- `mqtt`: 212
- `music_assistant`: 40
- `openai_conversation`: 4
- `person`: 4
- `proxmoxve`: 164
- `schedule`: 1
- `script`: 11
- `shelly`: 24
- `shopping_list`: 1
- `spotify`: 12
- `sun`: 9
- `switch_as_x`: 1
- `tapo_control`: 82
- `tplink`: 13
- `tplink_deco`: 89
- `tuya`: 22
- `wake_on_lan`: 2
- `wiz`: 8
- `wled`: 147
- `zone`: 7