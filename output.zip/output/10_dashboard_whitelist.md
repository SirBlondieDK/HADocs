# 10 Dashboard whitelist

Generated: 2026-07-05 01:49:34

## Badeværelse

- **Badeværelse spot 1** — `light.badevaerelse_spot_1` — `off`
- **Badeværelse spot 2** — `light.badevaerelse_spot_2` — `off`
- **Badeværelse spot 3** — `light.badevaerelse_spot_3` — `off`
- **Badeværelse spot 4** — `light.badevaerelse_spot_4` — `off`
- **Badeværelse spot 5** — `light.badevaerelse_spot_5` — `off`
- **Google Home Badeværelse** — `media_player.badevaerelse` — `off`
- **Bevægelses sensor badeværelse Batteri** — `sensor.bevaegelses_sensor_badevaerelse_battery` — `90`
- **Badeværelse spot 1 Do not disturb** — `switch.badevaerelse_spot_1_do_not_disturb` — `off`
- **Badeværelse spot 2 Do not disturb** — `switch.badevaerelse_spot_2_do_not_disturb` — `off`
- **Badeværelse spot 3 Do not disturb** — `switch.badevaerelse_spot_3_do_not_disturb` — `off`
- **Badeværelse spot 4 Do not disturb** — `switch.badevaerelse_spot_4_do_not_disturb` — `off`
- **Badeværelse spot 5 Do not disturb** — `switch.badevaerelse_spot_5_do_not_disturb` — `off`

## Bryggers

- **Loftlampe bryggers** — `light.loftlampe_bryggers` — `off`
- **Bryggers** — `media_player.bryggers` — `off`
- **Loftlampe bryggers Do not disturb** — `switch.loftlampe_bryggers_do_not_disturb` — `off`

## Carport

- **Carport Motion** — `binary_sensor.carport_motion` — `off`
- **Carport** — `camera.carport` — `recording`
- **Spot Hoveddør 1** — `light.spot_hoveddor_1` — `unavailable`
- **Spot Hoveddør 2** — `light.spot_hoveddor_2` — `unavailable`
- **sensor.carport_camera_fps** — `sensor.carport_camera_fps` — `unknown`
- **sensor.carport_detection_fps** — `sensor.carport_detection_fps` — `unknown`
- **Spot Hoveddør 1 Do not disturb** — `switch.spot_hoveddor_1_do_not_disturb` — `unavailable`
- **Spot Hoveddør 2 Do not disturb** — `switch.spot_hoveddor_2_do_not_disturb` — `unavailable`

## De små's værelse

- **WLED Ledss** — `device_tracker.kitchen_deco_ledss` — `not_home`
- **Led ved de små** — `light.wled_3` — `unavailable`
- **De smås værelse** — `media_player.de_smas_vaerelse` — `off`
- **WLED Freeze** — `switch.wled_freeze` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_3` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_3` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_3` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_3` — `unavailable`

## Gang

- **Lampe gang** — `light.lampe_gang` — `off`
- **Lampe gang Do not disturb** — `switch.lampe_gang_do_not_disturb` — `off`

## Hoveddør

- **Ringklokke** — `camera.ringklokke_hd_stream_direct` — `idle`
- **camera.ringklokke_sd_stream_direct** — `camera.ringklokke_sd_stream_direct` — `unknown`
- **Ringklokke Battery** — `sensor.ringklokke_battery` — `100`

## Køkken

- **Lampe spisebord** — `light.lampe_spisebord` — `on`
- **Loftlampe Køkken** — `light.loftlampe_kokken` — `on`
- **Køkken** — `media_player.kokken` — `off`
- **Lampe spisebord Do not disturb** — `switch.lampe_spisebord_do_not_disturb` — `off`
- **Loftlampe Køkken Do not disturb** — `switch.loftlampe_kokken_do_not_disturb` — `off`

## Sebastian's værelse

- **Loftlampe Sebastian** — `light.loftlampe_sebastian` — `off`
- **Sebastian** — `media_player.sebastian` — `off`
- **Loftlampe Sebastian Do not disturb** — `switch.loftlampe_sebastian_do_not_disturb` — `off`

## Server rum

- **adguard Status** — `binary_sensor.adguard_status` — `on`
- **frigate Status** — `binary_sensor.frigate_status` — `on`
- **HADashboard Status** — `binary_sensor.hadashboard_status` — `off`
- **homeassistant Status** — `binary_sensor.homeassistant_status` — `on`
- **hp-mini Status** — `binary_sensor.hp_mini_status` — `on`
- **jellyfin Status** — `binary_sensor.jellyfin_status` — `on`
- **Deco Køkken Deco online** — `binary_sensor.kitchen_deco_deco_online` — `on`
- **Deco Stue Deco online** — `binary_sensor.kitchen_deco_deco_online_2` — `on`
- **Deco Køkken Internet online** — `binary_sensor.kitchen_deco_internet_online` — `on`
- **Deco Stue Internet online** — `binary_sensor.kitchen_deco_internet_online_2` — `on`
- **nextcloud Status** — `binary_sensor.nextcloud_status` — `on`
- **proxy Status** — `binary_sensor.proxy_status` — `on`
- **Deco loft Deco online** — `binary_sensor.vaskerum_deco_deco_online` — `on`
- **Deco loft Internet online** — `binary_sensor.vaskerum_deco_internet_online` — `on`
- **zigbee2mqtt Status** — `binary_sensor.zigbee2mqtt_status` — `on`
- **Deco Køkken** — `device_tracker.kitchen_deco` — `home`
- **Deco Stue** — `device_tracker.kitchen_deco_2` — `home`
- **Deco Stue D100C** — `device_tracker.kitchen_deco_d100c` — `home`
- **Deco Køkken Fjernsyn stue** — `device_tracker.kitchen_deco_fjernsyn_stue` — `home`
- **Deco Stue Google-Home** — `device_tracker.kitchen_deco_google_home` — `home`
- **Deco Køkken Google-Home** — `device_tracker.kitchen_deco_google_home_2` — `home`
- **Deco Køkken Google-Home-Mini** — `device_tracker.kitchen_deco_google_home_mini` — `home`
- **Deco loft Google-Home-Mini** — `device_tracker.kitchen_deco_google_home_mini_2` — `home`
- **Deco loft iot_device_0A30** — `device_tracker.kitchen_deco_iot_device_0a30` — `home`
- **Deco loft iot_device_2D49** — `device_tracker.kitchen_deco_iot_device_2d49` — `home`
- **Deco Køkken iPad** — `device_tracker.kitchen_deco_ipad_2` — `home`
- **Deco Stue iPad** — `device_tracker.kitchen_deco_ipad_3` — `home`
- **Deco Stue Bent Iphone** — `device_tracker.kitchen_deco_iphone` — `home`
- **Deco Stue P100** — `device_tracker.kitchen_deco_p100` — `home`
- **Deco Stue HPFB8A31** — `device_tracker.kitchen_deco_pc_8a31` — `home`
- **Deco Køkken phone_C504** — `device_tracker.kitchen_deco_phone_c504` — `home`
- **Deco Køkken phone_D366** — `device_tracker.kitchen_deco_phone_d366` — `home`
- **Deco Stue SirBlondieDK** — `device_tracker.kitchen_deco_sirblondiedk` — `home`
- **Deco Køkken wiz_0123ac** — `device_tracker.kitchen_deco_wiz_0123ac` — `home`
- **Deco loft Device_1501** — `device_tracker.server_rum_deco_loft_device_1501` — `home`
- **Deco loft Device_1738** — `device_tracker.server_rum_deco_loft_device_1738` — `home`
- **Deco loft USW_MINI** — `device_tracker.server_rum_deco_loft_device_3d54` — `home`
- **Deco loft Device_4F06** — `device_tracker.server_rum_deco_loft_device_4f06` — `home`
- **Deco Stue Maja iPhone** — `device_tracker.server_rum_deco_stue_maja_iphone` — `home`
- **Deco Køkken SebastiipiPhone** — `device_tracker.server_rum_deco_stue_sebastiipiphone` — `home`
- **Deco loft** — `device_tracker.vaskerum_deco` — `home`
- **Deco loft adguard** — `device_tracker.vaskerum_deco_adguard` — `home`
- **Deco loft Ajax-002133F1** — `device_tracker.vaskerum_deco_ajax_002133f1` — `home`
- **Deco loft D210** — `device_tracker.vaskerum_deco_d210` — `home`
- **Deco loft Device_A5E8** — `device_tracker.vaskerum_deco_device_a5e8` — `home`
- **Deco loft Device_D57F** — `device_tracker.vaskerum_deco_device_d57f` — `home`
- **Deco loft ESP_C2432F** — `device_tracker.vaskerum_deco_esp_c2432f` — `home`
- **Deco Stue Google-Home** — `device_tracker.vaskerum_deco_google_home` — `home`
- **Deco Køkken Google-Home-Mini** — `device_tracker.vaskerum_deco_google_home_mini` — `home`
- **Deco loft Google-Home-Mini** — `device_tracker.vaskerum_deco_google_home_mini_2` — `home`
- **Deco loft Device_F70A** — `device_tracker.vaskerum_deco_homeassistant` — `home`
- **Deco loft Kamera 1** — `device_tracker.vaskerum_deco_kamera_1` — `home`
- **Deco loft Kamera 2** — `device_tracker.vaskerum_deco_kamera_2` — `home`
- **Deco loft Kamera 3** — `device_tracker.vaskerum_deco_kamera_3` — `home`
- **Deco loft Proxy server** — `device_tracker.vaskerum_deco_proxy_server` — `home`
- **Deco loft shelly1-3494546A3372** — `device_tracker.vaskerum_deco_shelly1_3494546a3372` — `home`
- **Deco loft shelly1-3494546A890C** — `device_tracker.vaskerum_deco_shelly1_3494546a890c` — `home`
- **Deco loft shelly1-3494546AE397** — `device_tracker.vaskerum_deco_shelly1_3494546ae397` — `home`
- **Deco Stue wiz_44c896** — `device_tracker.vaskerum_deco_wiz_44c896` — `home`
- **Deco loft wlan0** — `device_tracker.vaskerum_deco_wlan0` — `home`
- **Deco loft wlan0** — `device_tracker.vaskerum_deco_wlan0_2` — `home`
- **adguard Status** — `sensor.adguard_status` — `running`
- **frigate Status** — `sensor.frigate_status_2` — `running`
- **HADashboard Status** — `sensor.hadashboard_status` — `stopped`
- **homeassistant Status** — `sensor.homeassistant_status` — `running`
- **hp-mini Status** — `sensor.hp_mini_status` — `online`
- **jellyfin Status** — `sensor.jellyfin_status` — `running`
- **nextcloud Status** — `sensor.nextcloud_status` — `running`
- **proxy Status** — `sensor.proxy_status` — `running`
- **zigbee2mqtt Status** — `sensor.zigbee2mqtt_status` — `running`

## Sofia's værelse

- **Loftlampe Sofia** — `light.loftlampe_sofia` — `on`
- **Sofias værelse** — `media_player.sofias_vaerelse` — `off`
- **Loftlampe Sofia Do not disturb** — `switch.loftlampe_sofia_do_not_disturb` — `off`

## Soveværelse

- **WLED Ledsove** — `device_tracker.kitchen_deco_ledsove` — `not_home`
- **Loftlampe soveværelse** — `light.loftlampe_sovevaerelse` — `off`
- **Natlampe** — `light.natlampe` — `off`
- **Natlampe 2** — `light.natlampe_2` — `off`
- **WLED** — `light.wled_2` — `unavailable`
- **WLED Main** — `light.wled_main` — `unavailable`
- **Soveværelse** — `media_player.sovevaerelse` — `unavailable`
- **Soveværelse hub** — `media_player.sovevaerelse_hub` — `off`
- **Loftlampe soveværelse Do not disturb** — `switch.loftlampe_sovevaerelse_do_not_disturb` — `off`
- **Natlampe 2 Do not disturb** — `switch.natlampe_2_do_not_disturb` — `off`
- **Natlampe Do not disturb** — `switch.natlampe_do_not_disturb` — `off`
- **WLED Freeze** — `switch.wled_freeze_2` — `unavailable`
- **WLED Nightlight** — `switch.wled_nightlight_2` — `unavailable`
- **WLED Reverse** — `switch.wled_reverse_2` — `unavailable`
- **WLED Sync receive** — `switch.wled_sync_receive_2` — `unavailable`
- **WLED Sync send** — `switch.wled_sync_send_2` — `unavailable`

## Stue

- **Stue wledmic** — `device_tracker.kitchen_deco_wledmic` — `not_home`
- **Lille Lampe** — `light.lille_lampe` — `off`
- **Loftlampe Stue** — `light.loftlampe_stue` — `off`
- **Led Stue** — `light.wled` — `unavailable`
- **Stue Main** — `light.wled_main_2` — `unavailable`
- **Fjernsyn Stue** — `media_player.fjernsyn_stue` — `off`
- **Stue** — `media_player.stue` — `off`
- **stue højttaler** — `media_player.stue_hojttaler` — `off`
- **Temp stue Batteri** — `sensor.temp_stue_battery` — `100`
- **Lille Lampe Do not disturb** — `switch.lille_lampe_do_not_disturb` — `off`
- **Loftlampe Stue Do not disturb** — `switch.loftlampe_stue_do_not_disturb` — `off`
- **Stue Freeze** — `switch.stue_freeze` — `unavailable`
- **Lysende rose** — `switch.usb_kontakt_stue_1_center` — `off`
- **USB kontakt 1** — `switch.usb_kontakt_stue_1_left` — `off`
- **The Black Pearl** — `switch.usb_kontakt_stue_1_right` — `off`
- **Stue Nightlight** — `switch.wled_nightlight` — `unavailable`
- **Stue Reverse** — `switch.wled_reverse` — `unavailable`
- **Stue Sync receive** — `switch.wled_sync_receive` — `unavailable`
- **Stue Sync send** — `switch.wled_sync_send` — `unavailable`

## Uden område

- **Indkorelse Motion** — `binary_sensor.indkorelse_motion` — `off`
- **Sirblondiedk iPhone Focus** — `binary_sensor.sirblondiedk_iphone_focus` — `off`
- **indkørelse** — `camera.indkorelse` — `recording`
- **iPad** — `device_tracker.kitchen_deco_ipad` — `not_home`
- **iPhone** — `device_tracker.kitchen_deco_iphone_2` — `not_home`
- **Sebastian wall display ** — `device_tracker.sebastian_wall_display` — `unknown`
- **Lenovo-Tab** — `device_tracker.server_rum_deco_kokken_lenovo_tab` — `not_home`
- **Lenovo-Tab** — `device_tracker.server_rum_deco_kokken_lenovo_tab_2` — `not_home`
- **Wake on LAN 24:41:8c:93:d0:ff SebastianPC** — `device_tracker.server_rum_deco_kokken_sebastianpc` — `not_home`
- **Chromecast** — `device_tracker.server_rum_deco_loft_chromecast` — `not_home`
- **Sirblondiedk iPhone** — `device_tracker.sirblondiedk_iphone_2` — `home`
- **Sofia Dinesen Philip - iPhone** — `device_tracker.sofia_dinesen_philip_iphone` — `not_home`
- **Sofia wall display ** — `device_tracker.sofia_wall_display` — `unknown`
- **Tabet stue** — `device_tracker.tabet_stue` — `unknown`
- **køkken spot 1** — `light.kokken_spot_1` — `on`
- **Køkken spot 2** — `light.kokken_spot_2` — `on`
- **Køkken spot 3** — `light.kokken_spot_3` — `on`
- **lampe de små pære 1** — `light.lampe_de_sma_paere_1` — `off`
- **lampe de små pære 2** — `light.lampe_de_sma_paere_2` — `off`
- **lampe de små pære 3** — `light.lampe_de_sma_paere_3` — `off`
- **All Units** — `media_player.all_units` — `off`
- **højttaler gruppe 1** — `media_player.hojttaler_gruppe_1` — `off`
- **højttaler uden hubs** — `media_player.hojttaler_uden_hubs` — `off`
- **hub stue og soveværelse** — `media_player.hub_stue_og_sovevaerelse` — `off`
- **hubs** — `media_player.hubs` — `off`
- **mini ** — `media_player.mini` — `off`
- **små og soveværelse** — `media_player.sma_og_sovevaerelse` — `off`
- **soveværelset og de smås værelse** — `media_player.sovevaerelset_og_de_smas_vaerelse_2` — `off`
- **stue og soveværelse ** — `media_player.stue_og_sovevaerelse` — `off`
- **sensor.frigate_camera_fps** — `sensor.frigate_camera_fps` — `unknown`
- **sensor.frigate_detection_fps** — `sensor.frigate_detection_fps` — `unknown`
- **sensor.indkorelse_camera_fps** — `sensor.indkorelse_camera_fps` — `unknown`
- **sensor.indkorelse_detection_fps** — `sensor.indkorelse_detection_fps` — `unknown`
- **Sebastian wall display  Battery level** — `sensor.sebastian_wall_display_battery_level` — `3`
- **Sirblondiedk iPhone Battery Level** — `sensor.sirblondiedk_iphone_battery_level` — `40`
- **Sofia Dinesen Philip - iPhone Battery Level** — `sensor.sofia_dinesen_philip_iphone_battery_level` — `100`
- **Sofia wall display  Battery level** — `sensor.sofia_wall_display_battery_level` — `100`
- **Tabet stue Battery level** — `sensor.tabet_stue_battery_level` — `100`
- **køkken spot 1 Do not disturb** — `switch.kokken_spot_1_do_not_disturb` — `off`
- **Køkken spot 2 Do not disturb** — `switch.kokken_spot_2_do_not_disturb` — `off`
- **Køkken spot 3 Do not disturb** — `switch.kokken_spot_3_do_not_disturb` — `off`
- **lampe de små pære 1 Do not disturb** — `switch.lampe_de_sma_paere_1_do_not_disturb` — `off`
- **lampe de små pære 2 Do not disturb** — `switch.lampe_de_sma_paere_2_do_not_disturb` — `off`
- **lampe de små pære 3 Do not disturb** — `switch.lampe_de_sma_paere_3_do_not_disturb` — `off`
- **Zigbee2MQTT Bridge Permit join** — `switch.zigbee2mqtt_bridge_permit_join` — `off`

## terrasse

- **Terasse Motion** — `binary_sensor.terasse_motion` — `off`
- **Terasse** — `camera.terasse` — `recording`
- **sensor.terasse_camera_fps** — `sensor.terasse_camera_fps` — `unknown`
- **sensor.terasse_detection_fps** — `sensor.terasse_detection_fps` — `unknown`
