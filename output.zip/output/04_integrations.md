# 04 Integrations

Generated: 2026-07-05 01:49:34

## adano

- Entities: `46`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `4`

## aula

- Entities: `11`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `2`

## automation

- Entities: `18`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## backup

- Entities: `5`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## cast

- Entities: `20`
- Devices: `20`
- Important: `20`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## cloud

- Entities: `3`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `2`

## continuously_casting_dashboards

- Entities: `11`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `11`

## dwains_dashboard

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## file

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## frigate

- Entities: `135`
- Devices: `6`
- Important: `14`
- Diagnostic: `17`
- Ignored: `21`
- Relevant unknown/unavailable: `36`

## google

- Entities: `8`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `2`

## google_generative_ai_conversation

- Entities: `4`
- Devices: `4`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `3`

## google_translate

- Entities: `1`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## govee_ble

- Entities: `4`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## group

- Entities: `4`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## hacs

- Entities: `46`
- Devices: `23`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `24`

## hassio

- Entities: `91`
- Devices: `15`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `77`

## homeassistant_sky_connect

- Entities: `2`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `2`

## ibeacon

- Entities: `25`
- Devices: `5`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `23`

## icloud

- Entities: `12`
- Devices: `10`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `12`

## input_boolean

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## input_button

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## input_datetime

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## input_select

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## input_text

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## ipp

- Entities: `4`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `1`

## jellyfin

- Entities: `2`
- Devices: `2`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## met

- Entities: `1`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## mobile_app

- Entities: `307`
- Devices: `5`
- Important: `11`
- Diagnostic: `8`
- Ignored: `65`
- Relevant unknown/unavailable: `227`

## mqtt

- Entities: `212`
- Devices: `35`
- Important: `54`
- Diagnostic: `0`
- Ignored: `70`
- Relevant unknown/unavailable: `79`

## music_assistant

- Entities: `40`
- Devices: `20`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `21`

## openai_conversation

- Entities: `4`
- Devices: `4`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `4`

## person

- Entities: `4`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `2`

## proxmoxve

- Entities: `164`
- Devices: `11`
- Important: `18`
- Diagnostic: `9`
- Ignored: `116`
- Relevant unknown/unavailable: `0`

## schedule

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## script

- Entities: `11`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## shelly

- Entities: `24`
- Devices: `3`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `21`

## shopping_list

- Entities: `1`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## spotify

- Entities: `12`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `12`
- Relevant unknown/unavailable: `0`

## sun

- Entities: `9`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `3`

## switch_as_x

- Entities: `1`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## tapo_control

- Entities: `82`
- Devices: `1`
- Important: `3`
- Diagnostic: `2`
- Ignored: `15`
- Relevant unknown/unavailable: `35`

## tplink

- Entities: `13`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `6`

## tplink_deco

- Entities: `89`
- Devices: `7`
- Important: `61`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `15`

## tuya

- Entities: `22`
- Devices: `4`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `13`

## wake_on_lan

- Entities: `2`
- Devices: `1`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`

## wiz

- Entities: `8`
- Devices: `2`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `6`

## wled

- Entities: `147`
- Devices: `3`
- Important: `20`
- Diagnostic: `6`
- Ignored: `94`
- Relevant unknown/unavailable: `53`

## zone

- Entities: `7`
- Devices: `0`
- Important: `0`
- Diagnostic: `0`
- Ignored: `0`
- Relevant unknown/unavailable: `0`
