# 11 Health Score details

Generated: 2026-07-05 00:57:13

Health Score: `42/100`

## Notes

- 98 real entities are unavailable (-25)
- 14 real entities are unknown (-14)
- 1 batteries are low (-4)
- 59 physical devices have no area (-10)
- 68 duplicate friendly names found (-5)
- 206 system/service entities were ignored in Health Score

## Counts used by Health Score

- Critical offline/unknown: `0`
- Real unavailable: `98`
- Real unknown: `14`
- Low batteries: `1`
- Physical devices without area: `59`
- Duplicate friendly names: `68`
- Ignored unknown/unavailable: `206`

## Ignored entity model

The Health Score ignores service-only and system entities such as buttons, update entities, events, images, notify services, conversation agents, STT/TTS entities, snapshot actions, restart actions, and firmware controls.