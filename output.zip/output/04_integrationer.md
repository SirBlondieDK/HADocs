# 04 Integrations

Generated: 2026-07-05 00:57:13

## adano

- Count: `46`
- Raw unknown/unavailable: `4`

- `binary_sensor.robot_plaeneklipper_dock` — `off`
- `binary_sensor.robot_plaeneklipper_multizone` — `off`
- `binary_sensor.robot_plaeneklipper_multizone_auto` — `off`
- `binary_sensor.robot_plaeneklipper_online` — `off`
- `binary_sensor.robot_plaeneklipper_regn_sensor_aktiv` — `on`
- `button.robot_plaeneklipper_hjem` — `unknown`
- `button.robot_plaeneklipper_klip_kant` — `unknown`
- `button.robot_plaeneklipper_pause` — `unknown`
- `button.robot_plaeneklipper_start` — `2026-04-29T09:48:47.245783+00:00`
- `device_tracker.robot_plaeneklipper_robot_lokation` — `unknown`
- `lawn_mower.robot_plaeneklipper` — `Standby`
- `number.robot_plaeneklipper_regn_forsinkelse` — `180`
- `number.robot_plaeneklipper_zone_1_prioritet` — `25`
- `number.robot_plaeneklipper_zone_1_start` — `0`
- `number.robot_plaeneklipper_zone_2_prioritet` — `25`
- `number.robot_plaeneklipper_zone_2_start` — `25`
- `number.robot_plaeneklipper_zone_3_prioritet` — `25`
- `number.robot_plaeneklipper_zone_3_start` — `50`
- `number.robot_plaeneklipper_zone_4_prioritet` — `25`
- `number.robot_plaeneklipper_zone_4_start` — `75`
- `sensor.robot_plaeneklipper_aktuel_arbejdstid` — `0`
- `sensor.robot_plaeneklipper_batteri` — `33`
- `sensor.robot_plaeneklipper_fejl` — `normal`
- `sensor.robot_plaeneklipper_fejlkode` — `0`
- `sensor.robot_plaeneklipper_regn_sensor` — `Dry`
- `sensor.robot_plaeneklipper_regn_sensor_forsinkelse` — `180`
- `sensor.robot_plaeneklipper_regn_sensor_nedtaeller` — `180`
- `sensor.robot_plaeneklipper_robot_status` — `Standby`
- `sensor.robot_plaeneklipper_status_fejl` — ``
- `sensor.robot_plaeneklipper_tidsstyrring` — `Schedule`
- `sensor.robot_plaeneklipper_wifi_styrke` — `0`
- `sensor.robot_plaeneklipper_zone_1_start` — `0`
- `sensor.robot_plaeneklipper_zone_2_start` — `25`
- `sensor.robot_plaeneklipper_zone_3_start` — `50`
- `sensor.robot_plaeneklipper_zone_4_start` — `75`
- `switch.robot_plaeneklipper_multizone` — `off`
- `switch.robot_plaeneklipper_multizone_auto` — `off`
- `switch.robot_plaeneklipper_regn_sensor` — `on`
- `switch.robot_plaeneklipper_tidsstyrring` — `on`
- `text.robot_plaeneklipper_ugeplan_fredag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_lordag` — `00:00 - 00:00`
- `text.robot_plaeneklipper_ugeplan_mandag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_onsdag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_sondag` — `09:00 - 20:00 Trim`
- `text.robot_plaeneklipper_ugeplan_tirsdag` — `00:00 - 00:00`
- `text.robot_plaeneklipper_ugeplan_torsdag` — `00:00 - 00:00`

## aula

- Count: `11`
- Raw unknown/unavailable: `2`

- `binary_sensor.aula_aulamessage` — `on`
- `calendar.skoleskema_sebastian_christiansen` — `off`
- `calendar.skoleskema_sesilie_dinesen_philip_christiansen` — `off`
- `calendar.skoleskema_silke_dinesen_philip_christiansen` — `unknown`
- `calendar.skoleskema_silke_dinesen_philip_christiansen_2` — `off`
- `calendar.skoleskema_sofia_dinesen_philip_christiansen` — `off`
- `sensor.baekke_skole_sebastian` — `Ikke kommet`
- `sensor.baekke_skole_sesilie` — `Ikke kommet`
- `sensor.baekke_skole_silke` — `n/a`
- `sensor.baekke_skole_sofia` — `Ikke kommet`
- `sensor.veerst_baekke_bornehave_mollebo_silke` — `unknown`

## automation

- Count: `18`
- Raw unknown/unavailable: `1`

- `automation.badevaerelse_lys_ved_bevaegelse_dag_nat` — `on`
- `automation.besked_der_bliver_ringet_pa_dorklokken` — `off`
- `automation.facadelys_carport_spot_ved_frigate_person_kun_morkt` — `off`
- `automation.facadelys_slukkes_med_carport_lys` — `on`
- `automation.facadelys_taendes_med_lys_i_carport` — `on`
- `automation.frigate_ai_person_alert_vision` — `off`
- `automation.frigate_ai_test` — `off`
- `automation.kontakt_de_smas_vaerelse` — `on`
- `automation.kontakt_kokken` — `on`
- `automation.kontakt_sebastian` — `on`
- `automation.kontakt_sofias_vaerelse` — `on`
- `automation.kontakt_sovevaerelse` — `on`
- `automation.kontakt_ved_de_smas_vaerelse` — `on`
- `automation.lyskaede` — `unavailable`
- `automation.night_light_auto` — `on`
- `automation.pc` — `on`
- `automation.taend_pc` — `on`
- `automation.test_lys` — `on`

## backup

- Count: `5`
- Raw unknown/unavailable: `0`

- `event.backup_automatic_backup` — `2026-07-04T03:40:28.313+00:00`
- `sensor.backup_backup_manager_state` — `idle`
- `sensor.backup_last_attempted_automatic_backup` — `2026-07-04T03:40:03+00:00`
- `sensor.backup_last_successful_automatic_backup` — `2026-07-04T03:40:28+00:00`
- `sensor.backup_next_scheduled_automatic_backup` — `2026-07-08T03:04:40+00:00`

## cast

- Count: `20`
- Raw unknown/unavailable: `1`

- `media_player.all_units` — `off`
- `media_player.badevaerelse` — `off`
- `media_player.bryggers` — `off`
- `media_player.de_smas_vaerelse` — `off`
- `media_player.fjernsyn_stue` — `off`
- `media_player.hojttaler_gruppe_1` — `off`
- `media_player.hojttaler_uden_hubs` — `off`
- `media_player.hub_stue_og_sovevaerelse` — `off`
- `media_player.hubs` — `off`
- `media_player.kokken` — `off`
- `media_player.mini` — `off`
- `media_player.sebastian` — `off`
- `media_player.sma_og_sovevaerelse` — `off`
- `media_player.sofias_vaerelse` — `off`
- `media_player.sovevaerelse` — `unavailable`
- `media_player.sovevaerelse_hub` — `off`
- `media_player.sovevaerelset_og_de_smas_vaerelse_2` — `off`
- `media_player.stue` — `off`
- `media_player.stue_hojttaler` — `off`
- `media_player.stue_og_sovevaerelse` — `off`

## cloud

- Count: `3`
- Raw unknown/unavailable: `2`

- `binary_sensor.remote_ui` — `on`
- `stt.home_assistant_cloud` — `unknown`
- `tts.home_assistant_cloud` — `unknown`

## continuously_casting_dashboards

- Count: `11`
- Raw unknown/unavailable: `11`

- `sensor.continuously_casting_dashboards_192_168_68139_status` — `unknown`
- `sensor.continuously_casting_dashboards_192_168_68_139_status` — `unknown`
- `sensor.continuously_casting_dashboards_192_168_68_151_status` — `unknown`
- `sensor.continuously_casting_dashboards_assistant_active` — `unknown`
- `sensor.continuously_casting_dashboards_connected_devices` — `unknown`
- `sensor.continuously_casting_dashboards_disconnected_devices` — `unknown`
- `sensor.continuously_casting_dashboards_media_playing` — `unknown`
- `sensor.continuously_casting_dashboards_other_content` — `unknown`
- `sensor.continuously_casting_dashboards_sovevaerelse_hub_status` — `unknown`
- `sensor.continuously_casting_dashboards_stue_status` — `unknown`
- `sensor.continuously_casting_dashboards_total_devices` — `unknown`

## dwains_dashboard

- Count: `1`
- Raw unknown/unavailable: `0`

- `sensor.dwains_dashboard_latest_version` — `3.7.0`

## file

- Count: `1`
- Raw unknown/unavailable: `1`

- `notify.file` — `unknown`

## frigate

- Count: `135`
- Raw unknown/unavailable: `53`

- `binary_sensor.car_area_all_occupancy` — `off`
- `binary_sensor.car_area_car_occupancy` — `unavailable`
- `binary_sensor.car_area_dog_occupancy` — `unavailable`
- `binary_sensor.car_area_person_occupancy` — `off`
- `binary_sensor.carport_all_occupancy` — `off`
- `binary_sensor.carport_car_occupancy` — `off`
- `binary_sensor.carport_dog_occupancy` — `off`
- `binary_sensor.carport_motion` — `off`
- `binary_sensor.carport_person_occupancy` — `off`
- `binary_sensor.foran_all_occupancy` — `off`
- `binary_sensor.foran_person_occupancy` — `off`
- `binary_sensor.indkorelse_all_occupancy` — `off`
- `binary_sensor.indkorelse_car_occupancy` — `off`
- `binary_sensor.indkorelse_dog_occupancy` — `off`
- `binary_sensor.indkorelse_motion` — `off`
- `binary_sensor.indkorelse_person_occupancy` — `off`
- `binary_sensor.terasse_all_occupancy` — `off`
- `binary_sensor.terasse_car_occupancy` — `off`
- `binary_sensor.terasse_dog_occupancy` — `off`
- `binary_sensor.terasse_motion` — `off`
- `binary_sensor.terasse_person_occupancy` — `off`
- `camera.carport` — `recording`
- `camera.indkorelse` — `recording`
- `camera.terasse` — `recording`
- `image.carport_car` — `2026-07-04T22:27:38.966380`
- `image.carport_dog` — `2026-07-04T22:27:38.969634`
- `image.carport_person` — `2026-07-04T22:27:38.964073`
- `image.indkorelse_car` — `2026-07-04T22:27:38.968318`
- `image.indkorelse_dog` — `2026-07-04T22:27:38.961530`
- `image.indkorelse_person` — `2026-07-04T22:27:38.967685`
- `image.terasse_car` — `2026-07-04T22:27:38.965589`
- `image.terasse_dog` — `2026-07-04T22:27:38.966948`
- `image.terasse_person` — `2026-07-04T22:27:38.962813`
- `number.carport_contour_area` — `unknown`
- `number.carport_threshold` — `unknown`
- `number.indkorelse_contour_area` — `unknown`
- `number.indkorelse_threshold` — `unknown`
- `number.terasse_contour_area` — `unknown`
- `number.terasse_threshold` — `unknown`
- `sensor.car_area_all_active_count` — `0`
- `sensor.car_area_all_count` — `0`
- `sensor.car_area_car_active_count` — `unavailable`
- `sensor.car_area_car_count` — `unavailable`
- `sensor.car_area_dog_active_count` — `unavailable`
- `sensor.car_area_dog_count` — `unavailable`
- `sensor.car_area_person_active_count` — `0`
- `sensor.car_area_person_count` — `0`
- `sensor.carport_all_active_count` — `0`
- `sensor.carport_all_count` — `0`
- `sensor.carport_camera_fps` — `unknown`
- `sensor.carport_capture_cpu_usage` — `unknown`
- `sensor.carport_car_active_count` — `0`
- `sensor.carport_car_count` — `0`
- `sensor.carport_detect_cpu_usage` — `unknown`
- `sensor.carport_detection_fps` — `unknown`
- `sensor.carport_dog_active_count` — `0`
- `sensor.carport_dog_count` — `0`
- `sensor.carport_ffmpeg_cpu_usage` — `unknown`
- `sensor.carport_person_active_count` — `0`
- `sensor.carport_person_count` — `0`
- `sensor.carport_process_fps` — `unknown`
- `sensor.carport_review_status` — `unknown`
- `sensor.carport_skipped_fps` — `unknown`
- `sensor.foran_all_active_count` — `0`
- `sensor.foran_all_count` — `0`
- `sensor.foran_person_active_count` — `0`
- `sensor.foran_person_count` — `0`
- `sensor.frigate_camera_fps` — `unknown`
- `sensor.frigate_coral_inference_speed` — `unknown`
- `sensor.frigate_detection_fps` — `unknown`
- `sensor.frigate_intel_vaapi_gpu_load` — `unknown`
- `sensor.frigate_process_fps` — `unknown`
- `sensor.frigate_skipped_fps` — `unknown`
- `sensor.frigate_status` — `unknown`
- `sensor.frigate_uptime` — `unknown`
- `sensor.indkorelse_all_active_count` — `0`
- `sensor.indkorelse_all_count` — `0`
- `sensor.indkorelse_camera_fps` — `unknown`
- `sensor.indkorelse_capture_cpu_usage` — `unknown`
- `sensor.indkorelse_car_active_count` — `0`
- `sensor.indkorelse_car_count` — `0`
- `sensor.indkorelse_detect_cpu_usage` — `unknown`
- `sensor.indkorelse_detection_fps` — `unknown`
- `sensor.indkorelse_dog_active_count` — `0`
- `sensor.indkorelse_dog_count` — `0`
- `sensor.indkorelse_ffmpeg_cpu_usage` — `unknown`
- `sensor.indkorelse_person_active_count` — `0`
- `sensor.indkorelse_person_count` — `0`
- `sensor.indkorelse_process_fps` — `unknown`
- `sensor.indkorelse_review_status` — `unknown`
- `sensor.indkorelse_skipped_fps` — `unknown`
- `sensor.terasse_all_active_count` — `0`
- `sensor.terasse_all_count` — `0`
- `sensor.terasse_camera_fps` — `unknown`
- `sensor.terasse_capture_cpu_usage` — `unknown`
- `sensor.terasse_car_active_count` — `0`
- `sensor.terasse_car_count` — `0`
- `sensor.terasse_detect_cpu_usage` — `unknown`
- `sensor.terasse_detection_fps` — `unknown`
- `sensor.terasse_dog_active_count` — `0`
- `sensor.terasse_dog_count` — `0`
- `sensor.terasse_ffmpeg_cpu_usage` — `unknown`
- `sensor.terasse_person_active_count` — `0`
- `sensor.terasse_person_count` — `0`
- `sensor.terasse_process_fps` — `unknown`
- `sensor.terasse_review_status` — `unknown`
- `sensor.terasse_skipped_fps` — `unknown`
- `switch.carport_detect` — `on`
- `switch.carport_improve_contrast` — `unknown`
- `switch.carport_motion` — `on`
- `switch.carport_object_descriptions` — `unknown`
- `switch.carport_recordings` — `on`
- `switch.carport_review_alerts` — `on`
- `switch.carport_review_descriptions` — `unknown`
- `switch.carport_review_detections` — `on`
- `switch.carport_snapshots` — `on`
- `switch.indkorelse_detect` — `on`
- `switch.indkorelse_improve_contrast` — `unknown`
- `switch.indkorelse_motion` — `on`
- `switch.indkorelse_object_descriptions` — `unknown`
- `switch.indkorelse_recordings` — `on`
- `switch.indkorelse_review_alerts` — `on`
- `switch.indkorelse_review_descriptions` — `unknown`
- `switch.indkorelse_review_detections` — `on`
- `switch.indkorelse_snapshots` — `on`
- `switch.terasse_detect` — `on`
- `switch.terasse_improve_contrast` — `unknown`
- `switch.terasse_motion` — `on`
- `switch.terasse_object_descriptions` — `unknown`
- `switch.terasse_recordings` — `on`
- `switch.terasse_review_alerts` — `on`
- `switch.terasse_review_descriptions` — `unknown`
- `switch.terasse_review_detections` — `on`
- `switch.terasse_snapshots` — `on`
- `update.frigate_server` — `on`

## google

- Count: `8`
- Raw unknown/unavailable: `2`

- `calendar.birthdays` — `off`
- `calendar.den_mentale_kriger` — `off`
- `calendar.familie` — `off`
- `calendar.fodselsdage` — `unavailable`
- `calendar.helligdage_i_danmark` — `off`
- `calendar.sirblondiedk_gmail_com` — `off`
- `calendar.ugenumre` — `off`
- `calendar.working_location` — `unknown`

## google_generative_ai_conversation

- Count: `4`
- Raw unknown/unavailable: `3`

- `ai_task.google_ai_task` — `unknown`
- `conversation.google_ai_conversation` — `unknown`
- `stt.google_ai_stt` — `unknown`
- `tts.google_ai_tts` — `2026-03-02T03:07:54.381201+00:00`

## google_translate

- Count: `1`
- Raw unknown/unavailable: `1`

- `tts.google_en_com` — `unknown`

## govee_ble

- Count: `4`
- Raw unknown/unavailable: `1`

- `sensor.h5075_22bd_battery` — `100`
- `sensor.h5075_22bd_humidity` — `58.8`
- `sensor.h5075_22bd_signal_strength` — `unknown`
- `sensor.h5075_22bd_temperature` — `23.9`

## group

- Count: `4`
- Raw unknown/unavailable: `1`

- `light.badevaerelse` — `off`
- `light.lampe_ved_de_sma` — `off`
- `light.spot_hovededor` — `unavailable`
- `light.spot_kokken` — `on`

## hacs

- Count: `46`
- Raw unknown/unavailable: `24`

- `switch.adano_robotic_mower_pre_release` — `unknown`
- `switch.adaptive_lighting_pre_release` — `unknown`
- `switch.atomic_calendar_revive_pre_release` — `unknown`
- `switch.aula_pre_release` — `unknown`
- `switch.bubble_card_pre_release` — `unknown`
- `switch.button_card_pre_release` — `unknown`
- `switch.card_mod_pre_release` — `unknown`
- `switch.continuously_casting_dashboard_pre_release` — `unknown`
- `switch.dwains_dashboard_pre_release` — `unknown`
- `switch.frigate_pre_release` — `unknown`
- `switch.google_assistant_sdk_custom_pre_release` — `unknown`
- `switch.group_element_pre_release` — `unknown`
- `switch.ha_floorplan_your_imagination_almost_defines_the_limits_pre_release` — `unknown`
- `switch.hacs_pre_release` — `unknown`
- `switch.hikvision_nvr_ip_camera_pre_release` — `unknown`
- `switch.layout_card_pre_release` — `unknown`
- `switch.local_tuya_pre_release` — `unknown`
- `switch.lovelace_home_feed_card_pre_release` — `unknown`
- `switch.mushroom_pre_release` — `unknown`
- `switch.tapo_cameras_control_pre_release` — `unknown`
- `switch.themable_grid_pre_release` — `unknown`
- `switch.tp_link_deco_pre_release` — `unknown`
- `switch.week_planner_card_pre_release` — `unknown`
- `update.adano_robotic_mower_update` — `off`
- `update.adaptive_lighting_update` — `unknown`
- `update.atomic_calendar_revive_update` — `off`
- `update.aula_update` — `off`
- `update.bubble_card_update` — `off`
- `update.button_card_update` — `off`
- `update.card_mod_update` — `off`
- `update.continuously_casting_dashboard_update` — `off`
- `update.dwains_dashboard_update` — `off`
- `update.frigate_update` — `off`
- `update.google_assistant_sdk_custom_update` — `off`
- `update.group_element_update` — `off`
- `update.ha_floorplan_your_imagination_almost_defines_the_limits_update` — `off`
- `update.hacs_update` — `off`
- `update.hikvision_nvr_ip_camera_update` — `off`
- `update.layout_card_update` — `off`
- `update.local_tuya_update` — `off`
- `update.lovelace_home_feed_card_update` — `off`
- `update.mushroom_update` — `off`
- `update.tapo_cameras_control_update` — `off`
- `update.themable_grid_update` — `off`
- `update.tp_link_deco_update` — `off`
- `update.week_planner_card_update` — `off`

## hassio

- Count: `91`
- Raw unknown/unavailable: `77`

- `binary_sensor.file_editor_korer` — `unknown`
- `binary_sensor.frigate_korer` — `unknown`
- `binary_sensor.home_assistant_matter_hub_korer` — `unknown`
- `binary_sensor.mosquitto_broker_korer` — `unknown`
- `binary_sensor.mqtt_explorer_korer` — `unknown`
- `binary_sensor.music_assistant_server_korer` — `unknown`
- `binary_sensor.node_red_korer` — `unknown`
- `binary_sensor.silicon_labs_flasher_korer` — `unknown`
- `binary_sensor.silicon_labs_multiprotocol_korer` — `unknown`
- `binary_sensor.studio_code_server_korer` — `unknown`
- `binary_sensor.terminal_ssh_korer` — `unknown`
- `sensor.file_editor_cpu_procent` — `unknown`
- `sensor.file_editor_hukommelsesprocent` — `unknown`
- `sensor.file_editor_nyeste_version` — `unknown`
- `sensor.file_editor_version` — `unknown`
- `sensor.frigate_cpu_procent` — `unknown`
- `sensor.frigate_hukommelsesprocent` — `unknown`
- `sensor.frigate_nyeste_version` — `unknown`
- `sensor.frigate_version` — `unknown`
- `sensor.home_assistant_core_cpu_percent` — `unknown`
- `sensor.home_assistant_core_memory_percent` — `unknown`
- `sensor.home_assistant_host_apparmor_version` — `unknown`
- `sensor.home_assistant_host_disk_free` — `unknown`
- `sensor.home_assistant_host_disk_total` — `unknown`
- `sensor.home_assistant_host_disk_used` — `unknown`
- `sensor.home_assistant_host_os_agent_version` — `unknown`
- `sensor.home_assistant_matter_hub_cpu_procent` — `unknown`
- `sensor.home_assistant_matter_hub_hukommelsesprocent` — `unknown`
- `sensor.home_assistant_matter_hub_nyeste_version` — `unknown`
- `sensor.home_assistant_matter_hub_version` — `unknown`
- `sensor.home_assistant_operating_system_newest_version` — `unknown`
- `sensor.home_assistant_operating_system_version` — `unknown`
- `sensor.home_assistant_supervisor_cpu_percent` — `unknown`
- `sensor.home_assistant_supervisor_memory_percent` — `unknown`
- `sensor.mosquitto_broker_cpu_procent` — `unknown`
- `sensor.mosquitto_broker_hukommelsesprocent` — `unknown`
- `sensor.mosquitto_broker_nyeste_version` — `unknown`
- `sensor.mosquitto_broker_version` — `unknown`
- `sensor.mqtt_explorer_cpu_procent` — `unknown`
- `sensor.mqtt_explorer_hukommelsesprocent` — `unknown`
- `sensor.mqtt_explorer_nyeste_version` — `unknown`
- `sensor.mqtt_explorer_version` — `unknown`
- `sensor.music_assistant_server_cpu_procent` — `unknown`
- `sensor.music_assistant_server_hukommelsesprocent` — `unknown`
- `sensor.music_assistant_server_nyeste_version` — `unknown`
- `sensor.music_assistant_server_version` — `unknown`
- `sensor.node_red_cpu_procent` — `unknown`
- `sensor.node_red_hukommelsesprocent` — `unknown`
- `sensor.node_red_nyeste_version` — `unknown`
- `sensor.node_red_version` — `unknown`
- `sensor.silicon_labs_flasher_cpu_procent` — `unknown`
- `sensor.silicon_labs_flasher_hukommelsesprocent` — `unknown`
- `sensor.silicon_labs_flasher_nyeste_version` — `unknown`
- `sensor.silicon_labs_flasher_version` — `unknown`
- `sensor.silicon_labs_multiprotocol_cpu_procent` — `unknown`
- `sensor.silicon_labs_multiprotocol_hukommelsesprocent` — `unknown`
- `sensor.silicon_labs_multiprotocol_nyeste_version` — `unknown`
- `sensor.silicon_labs_multiprotocol_version` — `unknown`
- `sensor.studio_code_server_cpu_procent` — `unknown`
- `sensor.studio_code_server_hukommelsesprocent` — `unknown`
- `sensor.studio_code_server_nyeste_version` — `unknown`
- `sensor.studio_code_server_version` — `unknown`
- `sensor.terminal_ssh_cpu_procent` — `unknown`
- `sensor.terminal_ssh_hukommelsesprocent` — `unknown`
- `sensor.terminal_ssh_nyeste_version` — `unknown`
- `sensor.terminal_ssh_version` — `unknown`
- `switch.file_editor` — `unknown`
- `switch.frigate` — `unknown`
- `switch.home_assistant_matter_hub` — `unknown`
- `switch.mosquitto_broker` — `unknown`
- `switch.mqtt_explorer` — `unknown`
- `switch.music_assistant_server` — `unknown`
- `switch.node_red` — `unknown`
- `switch.silicon_labs_flasher` — `unknown`
- `switch.silicon_labs_multiprotocol` — `unknown`
- `switch.studio_code_server` — `unknown`
- `switch.terminal_ssh` — `unknown`
- `update.file_editor_update` — `off`
- `update.frigate_opdatering` — `off`
- `update.home_assistant_core_update` — `off`
- `update.home_assistant_matter_hub_opdatering` — `off`
- `update.home_assistant_operating_system_update` — `off`
- `update.home_assistant_supervisor_update` — `off`
- `update.mosquitto_broker_update` — `off`
- `update.mqtt_explorer_update` — `off`
- `update.music_assistant_server_update` — `off`
- `update.node_red_update` — `off`
- `update.silicon_labs_flasher_update` — `off`
- `update.silicon_labs_multiprotocol_update` — `off`
- `update.studio_code_server_opdatering` — `off`
- `update.terminal_ssh_update` — `off`

## homeassistant_sky_connect

- Count: `2`
- Raw unknown/unavailable: `2`

- `switch.home_assistant_skyconnect_9650e525_beta_firmware_updates` — `unknown`
- `update.home_assistant_skyconnect_9650e525_firmware` — `unknown`

## ibeacon

- Count: `25`
- Raw unknown/unavailable: `24`

- `device_tracker.gvh5075_22bd` — `not_home`
- `device_tracker.s2eb7335ec69640c3c_94bc` — `unavailable`
- `device_tracker.saphe_drive_pro_710c` — `unavailable`
- `device_tracker.saphe_drive_pro_f81f` — `unavailable`
- `device_tracker.xped_0060370b54c3` — `unavailable`
- `sensor.gvh5075_22bd_estimated_distance` — `unavailable`
- `sensor.gvh5075_22bd_power` — `unknown`
- `sensor.gvh5075_22bd_signalstyrke` — `unknown`
- `sensor.gvh5075_22bd_vendor` — `unknown`
- `sensor.s2eb7335ec69640c3c_94bc_estimated_distance` — `unavailable`
- `sensor.s2eb7335ec69640c3c_94bc_power` — `unknown`
- `sensor.s2eb7335ec69640c3c_94bc_signalstyrke` — `unknown`
- `sensor.s2eb7335ec69640c3c_94bc_vendor` — `unknown`
- `sensor.saphe_drive_pro_710c_estimated_distance` — `unavailable`
- `sensor.saphe_drive_pro_710c_power` — `unknown`
- `sensor.saphe_drive_pro_710c_signalstyrke` — `unknown`
- `sensor.saphe_drive_pro_710c_vendor` — `unknown`
- `sensor.saphe_drive_pro_f81f_estimated_distance` — `unavailable`
- `sensor.saphe_drive_pro_f81f_power` — `unknown`
- `sensor.saphe_drive_pro_f81f_signalstyrke` — `unknown`
- `sensor.saphe_drive_pro_f81f_vendor` — `unknown`
- `sensor.xped_0060370b54c3_estimated_distance` — `unavailable`
- `sensor.xped_0060370b54c3_power` — `unknown`
- `sensor.xped_0060370b54c3_signalstyrke` — `unknown`
- `sensor.xped_0060370b54c3_vendor` — `unknown`

## icloud

- Count: `12`
- Raw unknown/unavailable: `12`

- `device_tracker.bent_dinesen_schmidt_apple_watch` — `unavailable`
- `device_tracker.sirblondiedk_iphone` — `unavailable`
- `sensor.bent_dinesen_schmidt_apple_watch_batteri` — `unavailable`
- `sensor.ipad_2_batteri` — `unavailable`
- `sensor.ipad_batteri` — `unavailable`
- `sensor.marlene_apple_watch_batteri` — `unknown`
- `sensor.marlene_ravn_batteri` — `unknown`
- `sensor.sebastian_dinesen_philip_iphone_batteri` — `unavailable`
- `sensor.sebastians_ipad_batteri` — `unavailable`
- `sensor.silke_dinesen_philip_ipad_batteri` — `unavailable`
- `sensor.sirblondiedk_iphone_batteri` — `unavailable`
- `sensor.sofia_dinesen_philip_iphone_batteri` — `unavailable`

## input_boolean

- Count: `1`
- Raw unknown/unavailable: `0`

- `input_boolean.party_mode` — `off`

## input_button

- Count: `1`
- Raw unknown/unavailable: `0`

- `input_button.pc` — `2026-06-30T17:20:33.296932+00:00`

## input_datetime

- Count: `1`
- Raw unknown/unavailable: `0`

- `input_datetime.last_ai_alert` — `2026-04-04 00:00:00`

## input_select

- Count: `1`
- Raw unknown/unavailable: `0`

- `input_select.ai_mode` — `Normal`

## input_text

- Count: `1`
- Raw unknown/unavailable: `1`

- `input_text.kontakt_ved_de_sma_sidste_status` — `unknown`

## ipp

- Count: `4`
- Raw unknown/unavailable: `1`

- `sensor.hp_envy_inspire_7200_series` — `idle`
- `sensor.hp_envy_inspire_7200_series_black_cartridge` — `40`
- `sensor.hp_envy_inspire_7200_series_tri_color_cartridge` — `30`
- `sensor.hp_envy_inspire_7200_series_uptime` — `unknown`

## jellyfin

- Count: `2`
- Raw unknown/unavailable: `0`

- `media_player.d5369777_music_assistant` — `idle`
- `sensor.husets_multimedie_active_clients` — `0`

## met

- Count: `1`
- Raw unknown/unavailable: `0`

- `weather.forecast_hjem` — `cloudy`

## mobile_app

- Count: `307`
- Raw unknown/unavailable: `257`

- `binary_sensor.sebastian_wall_display_android_auto` — `unknown`
- `binary_sensor.sebastian_wall_display_app_inactive` — `unknown`
- `binary_sensor.sebastian_wall_display_bluetooth_state` — `unknown`
- `binary_sensor.sebastian_wall_display_device_locked` — `unknown`
- `binary_sensor.sebastian_wall_display_device_secure` — `unknown`
- `binary_sensor.sebastian_wall_display_doze_mode` — `unknown`
- `binary_sensor.sebastian_wall_display_headphones` — `unknown`
- `binary_sensor.sebastian_wall_display_high_accuracy_mode` — `unknown`
- `binary_sensor.sebastian_wall_display_hotspot_state` — `unknown`
- `binary_sensor.sebastian_wall_display_interactive` — `unknown`
- `binary_sensor.sebastian_wall_display_is_charging` — `unknown`
- `binary_sensor.sebastian_wall_display_keyguard_locked` — `unknown`
- `binary_sensor.sebastian_wall_display_keyguard_secure` — `unknown`
- `binary_sensor.sebastian_wall_display_mic_muted` — `unknown`
- `binary_sensor.sebastian_wall_display_music_active` — `unknown`
- `binary_sensor.sebastian_wall_display_power_save` — `unknown`
- `binary_sensor.sebastian_wall_display_speakerphone` — `unknown`
- `binary_sensor.sebastian_wall_display_wi_fi_state` — `unknown`
- `binary_sensor.sebastian_wall_display_work_profile` — `unknown`
- `binary_sensor.sirblondiedk_iphone_focus` — `off`
- `binary_sensor.sofia_wall_display_android_auto` — `unknown`
- `binary_sensor.sofia_wall_display_app_inactive` — `unknown`
- `binary_sensor.sofia_wall_display_bluetooth_state` — `unknown`
- `binary_sensor.sofia_wall_display_device_locked` — `unknown`
- `binary_sensor.sofia_wall_display_device_secure` — `unknown`
- `binary_sensor.sofia_wall_display_doze_mode` — `unknown`
- `binary_sensor.sofia_wall_display_headphones` — `unknown`
- `binary_sensor.sofia_wall_display_high_accuracy_mode` — `unknown`
- `binary_sensor.sofia_wall_display_hotspot_state` — `unknown`
- `binary_sensor.sofia_wall_display_interactive` — `unknown`
- `binary_sensor.sofia_wall_display_is_charging` — `unknown`
- `binary_sensor.sofia_wall_display_keyguard_locked` — `unknown`
- `binary_sensor.sofia_wall_display_keyguard_secure` — `unknown`
- `binary_sensor.sofia_wall_display_mic_muted` — `unknown`
- `binary_sensor.sofia_wall_display_music_active` — `unknown`
- `binary_sensor.sofia_wall_display_power_save` — `unknown`
- `binary_sensor.sofia_wall_display_speakerphone` — `unknown`
- `binary_sensor.sofia_wall_display_wi_fi_state` — `unknown`
- `binary_sensor.sofia_wall_display_work_profile` — `unknown`
- `binary_sensor.tabet_stue_android_auto` — `unknown`
- `binary_sensor.tabet_stue_app_inactive` — `unknown`
- `binary_sensor.tabet_stue_bluetooth_state` — `unknown`
- `binary_sensor.tabet_stue_device_locked` — `unknown`
- `binary_sensor.tabet_stue_device_secure` — `unknown`
- `binary_sensor.tabet_stue_doze_mode` — `unknown`
- `binary_sensor.tabet_stue_headphones` — `unknown`
- `binary_sensor.tabet_stue_high_accuracy_mode` — `unknown`
- `binary_sensor.tabet_stue_hotspot_state` — `unknown`
- `binary_sensor.tabet_stue_interactive` — `unknown`
- `binary_sensor.tabet_stue_is_charging` — `unknown`
- `binary_sensor.tabet_stue_keyguard_locked` — `unknown`
- `binary_sensor.tabet_stue_keyguard_secure` — `unknown`
- `binary_sensor.tabet_stue_mic_muted` — `unknown`
- `binary_sensor.tabet_stue_music_active` — `unknown`
- `binary_sensor.tabet_stue_power_save` — `unknown`
- `binary_sensor.tabet_stue_speakerphone` — `unknown`
- `binary_sensor.tabet_stue_wifi_state` — `unknown`
- `binary_sensor.tabet_stue_work_profile` — `unknown`
- `device_tracker.sebastian_wall_display` — `unknown`
- `device_tracker.sirblondiedk_iphone_2` — `home`
- `device_tracker.sofia_dinesen_philip_iphone` — `not_home`
- `device_tracker.sofia_wall_display` — `unknown`
- `device_tracker.tabet_stue` — `unknown`
- `notify.sebastian_wall_display` — `unknown`
- `notify.sirblondiedk_iphone` — `unknown`
- `notify.sofia_dinesen_philip_iphone` — `unknown`
- `notify.sofia_wall_display` — `unknown`
- `notify.tabet_stue` — `unknown`
- `sensor.sebastian_wall_display_active_notification_count` — `unknown`
- `sensor.sebastian_wall_display_app_importance` — `unknown`
- `sensor.sebastian_wall_display_app_memory` — `unknown`
- `sensor.sebastian_wall_display_app_rx_gb` — `unknown`
- `sensor.sebastian_wall_display_app_tx_gb` — `unknown`
- `sensor.sebastian_wall_display_audio_mode` — `unknown`
- `sensor.sebastian_wall_display_battery_health` — `unknown`
- `sensor.sebastian_wall_display_battery_level` — `3`
- `sensor.sebastian_wall_display_battery_power` — `unknown`
- `sensor.sebastian_wall_display_battery_state` — `discharging`
- `sensor.sebastian_wall_display_battery_temperature` — `unknown`
- `sensor.sebastian_wall_display_beacon_monitor` — `unknown`
- `sensor.sebastian_wall_display_ble_transmitter` — `unknown`
- `sensor.sebastian_wall_display_bluetooth_connection` — `unknown`
- `sensor.sebastian_wall_display_car_battery` — `unknown`
- `sensor.sebastian_wall_display_car_charging_status` — `unknown`
- `sensor.sebastian_wall_display_car_ev_connector_type` — `unknown`
- `sensor.sebastian_wall_display_car_fuel` — `unknown`
- `sensor.sebastian_wall_display_car_fuel_type` — `unknown`
- `sensor.sebastian_wall_display_car_name` — `unknown`
- `sensor.sebastian_wall_display_car_odometer` — `unknown`
- `sensor.sebastian_wall_display_car_range_remaining` — `unknown`
- `sensor.sebastian_wall_display_car_speed` — `unknown`
- `sensor.sebastian_wall_display_charger_type` — `none`
- `sensor.sebastian_wall_display_current_time_zone` — `unknown`
- `sensor.sebastian_wall_display_current_version` — `unknown`
- `sensor.sebastian_wall_display_detected_activity` — `unknown`
- `sensor.sebastian_wall_display_do_not_disturb_sensor` — `unknown`
- `sensor.sebastian_wall_display_external_storage` — `unknown`
- `sensor.sebastian_wall_display_geocoded_location` — `unknown`
- `sensor.sebastian_wall_display_high_accuracy_update_interval` — `unknown`
- `sensor.sebastian_wall_display_internal_storage` — `unknown`
- `sensor.sebastian_wall_display_ipv6_addresses` — `unknown`
- `sensor.sebastian_wall_display_last_notification` — `unknown`
- `sensor.sebastian_wall_display_last_reboot` — `unknown`
- `sensor.sebastian_wall_display_last_removed_notification` — `unknown`
- `sensor.sebastian_wall_display_last_update_trigger` — `unknown`
- `sensor.sebastian_wall_display_last_used_app` — `unknown`
- `sensor.sebastian_wall_display_media_session` — `unknown`
- `sensor.sebastian_wall_display_network_type` — `unknown`
- `sensor.sebastian_wall_display_next_alarm` — `unknown`
- `sensor.sebastian_wall_display_os_version` — `unknown`
- `sensor.sebastian_wall_display_public_ip_address` — `unknown`
- `sensor.sebastian_wall_display_ringer_mode` — `unknown`
- `sensor.sebastian_wall_display_screen_brightness` — `unknown`
- `sensor.sebastian_wall_display_screen_off_timeout` — `unknown`
- `sensor.sebastian_wall_display_screen_orientation` — `unknown`
- `sensor.sebastian_wall_display_screen_rotation` — `unknown`
- `sensor.sebastian_wall_display_security_patch` — `unknown`
- `sensor.sebastian_wall_display_sleep_confidence` — `unknown`
- `sensor.sebastian_wall_display_sleep_segment` — `unknown`
- `sensor.sebastian_wall_display_total_rx_gb` — `unknown`
- `sensor.sebastian_wall_display_total_tx_gb` — `unknown`
- `sensor.sebastian_wall_display_volume_level_accessibility` — `unknown`
- `sensor.sebastian_wall_display_volume_level_alarm` — `unknown`
- `sensor.sebastian_wall_display_volume_level_call` — `unknown`
- `sensor.sebastian_wall_display_volume_level_dtmf` — `unknown`
- `sensor.sebastian_wall_display_volume_level_music` — `unknown`
- `sensor.sebastian_wall_display_volume_level_notification` — `unknown`
- `sensor.sebastian_wall_display_volume_level_ringer` — `unknown`
- `sensor.sebastian_wall_display_volume_level_system` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_bssid` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_connection` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_frequency` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_ip_address` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_link_speed` — `unknown`
- `sensor.sebastian_wall_display_wi_fi_signal_strength` — `unknown`
- `sensor.sirblondiedk_iphone_activity` — `Stationary`
- `sensor.sirblondiedk_iphone_app_version` — `2026.6.0`
- `sensor.sirblondiedk_iphone_audio_output` — `Built-in Speaker`
- `sensor.sirblondiedk_iphone_average_active_pace` — `0`
- `sensor.sirblondiedk_iphone_battery_level` — `50`
- `sensor.sirblondiedk_iphone_battery_state` — `Not Charging`
- `sensor.sirblondiedk_iphone_bssid` — `cc:32:e5:3b:b3:8f`
- `sensor.sirblondiedk_iphone_connection_type` — `Wi-Fi`
- `sensor.sirblondiedk_iphone_distance` — `1900`
- `sensor.sirblondiedk_iphone_floors_ascended` — `0`
- `sensor.sirblondiedk_iphone_floors_descended` — `0`
- `sensor.sirblondiedk_iphone_geocoded_location` — `Podersvej 16
6622 Bække
Danmark`
- `sensor.sirblondiedk_iphone_last_update_trigger` — `Signaled`
- `sensor.sirblondiedk_iphone_location_permission` — `Authorized Always`
- `sensor.sirblondiedk_iphone_pressure` — `1007.99`
- `sensor.sirblondiedk_iphone_sim_1` — `--`
- `sensor.sirblondiedk_iphone_sim_2` — `--`
- `sensor.sirblondiedk_iphone_ssid` — `Det lille hjem`
- `sensor.sirblondiedk_iphone_steps` — `2067`
- `sensor.sirblondiedk_iphone_storage` — `0.99`
- `sensor.sirblondiedk_iphone_watch_battery` — `100`
- `sensor.sirblondiedk_iphone_watch_battery_state` — `Full`
- `sensor.sofia_dinesen_philip_iphone_activity` — `Unknown`
- `sensor.sofia_dinesen_philip_iphone_average_active_pace` — `1`
- `sensor.sofia_dinesen_philip_iphone_battery_level` — `100`
- `sensor.sofia_dinesen_philip_iphone_battery_state` — `Not Charging`
- `sensor.sofia_dinesen_philip_iphone_bssid` — `Not Connected`
- `sensor.sofia_dinesen_philip_iphone_connection_type` — `Cellular`
- `sensor.sofia_dinesen_philip_iphone_distance` — `134`
- `sensor.sofia_dinesen_philip_iphone_floors_ascended` — `0`
- `sensor.sofia_dinesen_philip_iphone_floors_descended` — `0`
- `sensor.sofia_dinesen_philip_iphone_geocoded_location` — `Møllevej 34
6622 Bække
Danmark`
- `sensor.sofia_dinesen_philip_iphone_last_update_trigger` — `Launch`
- `sensor.sofia_dinesen_philip_iphone_sim_1` — `--`
- `sensor.sofia_dinesen_philip_iphone_sim_2` — `--`
- `sensor.sofia_dinesen_philip_iphone_ssid` — `Not Connected`
- `sensor.sofia_dinesen_philip_iphone_steps` — `196`
- `sensor.sofia_dinesen_philip_iphone_storage` — `37.26`
- `sensor.sofia_wall_display_active_notification_count` — `unknown`
- `sensor.sofia_wall_display_app_importance` — `unknown`
- `sensor.sofia_wall_display_app_memory` — `unknown`
- `sensor.sofia_wall_display_app_rx_gb` — `unknown`
- `sensor.sofia_wall_display_app_tx_gb` — `unknown`
- `sensor.sofia_wall_display_audio_mode` — `unknown`
- `sensor.sofia_wall_display_battery_health` — `unknown`
- `sensor.sofia_wall_display_battery_level` — `100`
- `sensor.sofia_wall_display_battery_power` — `unknown`
- `sensor.sofia_wall_display_battery_state` — `full`
- `sensor.sofia_wall_display_battery_temperature` — `unknown`
- `sensor.sofia_wall_display_beacon_monitor` — `unknown`
- `sensor.sofia_wall_display_ble_transmitter` — `unknown`
- `sensor.sofia_wall_display_bluetooth_connection` — `unknown`
- `sensor.sofia_wall_display_car_battery` — `unknown`
- `sensor.sofia_wall_display_car_charging_status` — `unknown`
- `sensor.sofia_wall_display_car_ev_connector_type` — `unknown`
- `sensor.sofia_wall_display_car_fuel` — `unknown`
- `sensor.sofia_wall_display_car_fuel_type` — `unknown`
- `sensor.sofia_wall_display_car_name` — `unknown`
- `sensor.sofia_wall_display_car_odometer` — `unknown`
- `sensor.sofia_wall_display_car_range_remaining` — `unknown`
- `sensor.sofia_wall_display_car_speed` — `unknown`
- `sensor.sofia_wall_display_charger_type` — `ac`
- `sensor.sofia_wall_display_current_time_zone` — `unknown`
- `sensor.sofia_wall_display_current_version` — `unknown`
- `sensor.sofia_wall_display_detected_activity` — `unknown`
- `sensor.sofia_wall_display_do_not_disturb_sensor` — `unknown`
- `sensor.sofia_wall_display_external_storage` — `unknown`
- `sensor.sofia_wall_display_geocoded_location` — `unknown`
- `sensor.sofia_wall_display_high_accuracy_update_interval` — `unknown`
- `sensor.sofia_wall_display_internal_storage` — `unknown`
- `sensor.sofia_wall_display_ipv6_addresses` — `unknown`
- `sensor.sofia_wall_display_last_notification` — `unknown`
- `sensor.sofia_wall_display_last_reboot` — `unknown`
- `sensor.sofia_wall_display_last_removed_notification` — `unknown`
- `sensor.sofia_wall_display_last_update_trigger` — `unknown`
- `sensor.sofia_wall_display_last_used_app` — `unknown`
- `sensor.sofia_wall_display_media_session` — `unknown`
- `sensor.sofia_wall_display_network_type` — `unknown`
- `sensor.sofia_wall_display_next_alarm` — `unknown`
- `sensor.sofia_wall_display_os_version` — `unknown`
- `sensor.sofia_wall_display_public_ip_address` — `unknown`
- `sensor.sofia_wall_display_ringer_mode` — `unknown`
- `sensor.sofia_wall_display_screen_brightness` — `unknown`
- `sensor.sofia_wall_display_screen_off_timeout` — `unknown`
- `sensor.sofia_wall_display_screen_orientation` — `unknown`
- `sensor.sofia_wall_display_screen_rotation` — `unknown`
- `sensor.sofia_wall_display_security_patch` — `unknown`
- `sensor.sofia_wall_display_sleep_confidence` — `unknown`
- `sensor.sofia_wall_display_sleep_segment` — `unknown`
- `sensor.sofia_wall_display_total_rx_gb` — `unknown`
- `sensor.sofia_wall_display_total_tx_gb` — `unknown`
- `sensor.sofia_wall_display_volume_level_accessibility` — `unknown`
- `sensor.sofia_wall_display_volume_level_alarm` — `unknown`
- `sensor.sofia_wall_display_volume_level_call` — `unknown`
- `sensor.sofia_wall_display_volume_level_dtmf` — `unknown`
- `sensor.sofia_wall_display_volume_level_music` — `unknown`
- `sensor.sofia_wall_display_volume_level_notification` — `unknown`
- `sensor.sofia_wall_display_volume_level_ringer` — `unknown`
- `sensor.sofia_wall_display_volume_level_system` — `unknown`
- `sensor.sofia_wall_display_wi_fi_bssid` — `unknown`
- `sensor.sofia_wall_display_wi_fi_connection` — `unknown`
- `sensor.sofia_wall_display_wi_fi_frequency` — `unknown`
- `sensor.sofia_wall_display_wi_fi_ip_address` — `unknown`
- `sensor.sofia_wall_display_wi_fi_link_speed` — `unknown`
- `sensor.sofia_wall_display_wi_fi_signal_strength` — `unknown`
- `sensor.tabet_stue_active_notification_count` — `unknown`
- `sensor.tabet_stue_app_importance` — `unknown`
- `sensor.tabet_stue_app_memory` — `unknown`
- `sensor.tabet_stue_app_rx_gb` — `unknown`
- `sensor.tabet_stue_app_tx_gb` — `unknown`
- `sensor.tabet_stue_audio_mode` — `unknown`
- `sensor.tabet_stue_battery_health` — `unknown`
- `sensor.tabet_stue_battery_level` — `100`
- `sensor.tabet_stue_battery_power` — `unknown`
- `sensor.tabet_stue_battery_state` — `full`
- `sensor.tabet_stue_battery_temperature` — `unknown`
- `sensor.tabet_stue_beacon_monitor` — `unknown`
- `sensor.tabet_stue_ble_transmitter` — `unknown`
- `sensor.tabet_stue_bluetooth_connection` — `unknown`
- `sensor.tabet_stue_car_battery` — `unknown`
- `sensor.tabet_stue_car_charging_status` — `unknown`
- `sensor.tabet_stue_car_ev_connector_type` — `unknown`
- `sensor.tabet_stue_car_fuel` — `unknown`
- `sensor.tabet_stue_car_fuel_type` — `unknown`
- `sensor.tabet_stue_car_name` — `unknown`
- `sensor.tabet_stue_car_odometer` — `unknown`
- `sensor.tabet_stue_car_range_remaining` — `unknown`
- `sensor.tabet_stue_car_speed` — `unknown`
- `sensor.tabet_stue_charger_type` — `ac`
- `sensor.tabet_stue_current_time_zone` — `unknown`
- `sensor.tabet_stue_current_version` — `unknown`
- `sensor.tabet_stue_detected_activity` — `unknown`
- `sensor.tabet_stue_do_not_disturb_sensor` — `unknown`
- `sensor.tabet_stue_external_storage` — `unknown`
- `sensor.tabet_stue_geocoded_location` — `unknown`
- `sensor.tabet_stue_high_accuracy_update_interval` — `unknown`
- `sensor.tabet_stue_internal_storage` — `unknown`
- `sensor.tabet_stue_ipv6_addresses` — `unknown`
- `sensor.tabet_stue_last_notification` — `unknown`
- `sensor.tabet_stue_last_reboot` — `unknown`
- `sensor.tabet_stue_last_removed_notification` — `unknown`
- `sensor.tabet_stue_last_update_trigger` — `unknown`
- `sensor.tabet_stue_last_used_app` — `unknown`
- `sensor.tabet_stue_media_session` — `unknown`
- `sensor.tabet_stue_network_type` — `unknown`
- `sensor.tabet_stue_next_alarm` — `unknown`
- `sensor.tabet_stue_os_version` — `unknown`
- `sensor.tabet_stue_public_ip_address` — `unknown`
- `sensor.tabet_stue_ringer_mode` — `unknown`
- `sensor.tabet_stue_screen_brightness` — `unknown`
- `sensor.tabet_stue_screen_off_timeout` — `unknown`
- `sensor.tabet_stue_screen_orientation` — `unknown`
- `sensor.tabet_stue_screen_rotation` — `unknown`
- `sensor.tabet_stue_security_patch` — `unknown`
- `sensor.tabet_stue_sleep_confidence` — `unknown`
- `sensor.tabet_stue_sleep_segment` — `unknown`
- `sensor.tabet_stue_total_rx_gb` — `unknown`
- `sensor.tabet_stue_total_tx_gb` — `unknown`
- `sensor.tabet_stue_volume_level_accessibility` — `unknown`
- `sensor.tabet_stue_volume_level_alarm` — `unknown`
- `sensor.tabet_stue_volume_level_call` — `unknown`
- `sensor.tabet_stue_volume_level_dtmf` — `unknown`
- `sensor.tabet_stue_volume_level_music` — `unknown`
- `sensor.tabet_stue_volume_level_notification` — `unknown`
- `sensor.tabet_stue_volume_level_ringer` — `unknown`
- `sensor.tabet_stue_volume_level_system` — `unknown`
- `sensor.tabet_stue_wifi_bssid` — `unknown`
- `sensor.tabet_stue_wifi_connection` — `unknown`
- `sensor.tabet_stue_wifi_frequency` — `unknown`
- `sensor.tabet_stue_wifi_ip_address` — `unknown`
- `sensor.tabet_stue_wifi_link_speed` — `unknown`
- `sensor.tabet_stue_wifi_signal_strength` — `unknown`

## mqtt

- Count: `212`
- Raw unknown/unavailable: `148`

- `binary_sensor.bevaegelses_sensor_badevaerelse_occupancy` — `off`
- `binary_sensor.zigbee2mqtt_bridge_connection_state` — `on`
- `binary_sensor.zigbee2mqtt_bridge_restart_required` — `unknown`
- `button.zigbee2mqtt_bridge_restart` — `unknown`
- `light.badevaerelse_spot_1` — `off`
- `light.badevaerelse_spot_2` — `off`
- `light.badevaerelse_spot_3` — `off`
- `light.badevaerelse_spot_4` — `off`
- `light.badevaerelse_spot_5` — `off`
- `light.kokken_spot_1` — `on`
- `light.kokken_spot_2` — `on`
- `light.kokken_spot_3` — `on`
- `light.lampe_de_sma_paere_1` — `off`
- `light.lampe_de_sma_paere_2` — `off`
- `light.lampe_de_sma_paere_3` — `off`
- `light.lampe_gang` — `off`
- `light.lampe_spisebord` — `on`
- `light.lille_lampe` — `off`
- `light.loftlampe_bryggers` — `off`
- `light.loftlampe_kokken` — `on`
- `light.loftlampe_sebastian` — `off`
- `light.loftlampe_sofia` — `on`
- `light.loftlampe_sovevaerelse` — `off`
- `light.loftlampe_stue` — `off`
- `light.natlampe` — `off`
- `light.natlampe_2` — `off`
- `light.spot_hoveddor_1` — `unavailable`
- `light.spot_hoveddor_2` — `unavailable`
- `number.bevaegelses_sensor_badevaerelse_illuminance_interval` — `60`
- `number.temp_stue_comfort_humidity_max` — `unknown`
- `number.temp_stue_comfort_humidity_min` — `unknown`
- `number.temp_stue_comfort_temperature_max` — `unknown`
- `number.temp_stue_comfort_temperature_min` — `unknown`
- `number.temp_stue_humidity_calibration` — `unknown`
- `number.temp_stue_temperature_calibration` — `unknown`
- `select.0xa4c138312c122baa_effect` — `unknown`
- `select.0xa4c1383c67fc69da_effect` — `unknown`
- `select.0xa4c13862b3e83b4d_effect` — `unknown`
- `select.0xa4c138660fe2058a_effect` — `unknown`
- `select.0xa4c1386c83e5e3a6_effect` — `unknown`
- `select.0xa4c1387f1efbb7b4_effect` — `unknown`
- `select.0xa4c1388d5e4bed62_effect` — `unknown`
- `select.0xa4c1389d8fc50e9e_effect` — `unknown`
- `select.0xa4c1389de2ac12d0_effect` — `unknown`
- `select.0xa4c138b4051e6603_effect` — `unknown`
- `select.0xa4c138bf6a50d1db_effect` — `unknown`
- `select.0xe8ca50dda00d0000_effect` — `unknown`
- `select.0xe8ca50ddece90000_effect` — `unknown`
- `select.0xe8ca50ddee080000_effect` — `unknown`
- `select.0xe8ca50ddf96c0000_effect` — `unknown`
- `select.0xe8ca50ddf9bc0000_effect` — `unknown`
- `select.0xe8ca50ddfe570000_effect` — `unknown`
- `select.0xe8ca50de33300000_effect` — `unknown`
- `select.0xe8ca50de41110000_effect` — `unknown`
- `select.0xe8ca50de7c1c0000_effect` — `unknown`
- `select.0xe8ca50de90a20000_effect` — `unknown`
- `select.0xe8ca50deb78c0000_effect` — `unknown`
- `select.badevaerelse_spot_1_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_1_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_2_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_2_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_3_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_3_effect` — `unknown`
- `select.badevaerelse_spot_3_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_4_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_4_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_5_color_power_on_behavior` — `unknown`
- `select.badevaerelse_spot_5_power_on_behavior` — `unknown`
- `select.bevaegelses_sensor_badevaerelse_keep_time` — `30`
- `select.bevaegelses_sensor_badevaerelse_sensitivity` — `high`
- `select.kokken_spot_1_color_power_on_behavior` — `unknown`
- `select.kokken_spot_1_power_on_behavior` — `unknown`
- `select.kokken_spot_2_color_power_on_behavior` — `unknown`
- `select.kokken_spot_2_power_on_behavior` — `unknown`
- `select.kokken_spot_3_color_power_on_behavior` — `unknown`
- `select.kokken_spot_3_power_on_behavior` — `unknown`
- `select.lampe_de_sma_paere_1_color_power_on_behavior` — `unknown`
- `select.lampe_de_sma_paere_2_color_power_on_behavior` — `unknown`
- `select.lampe_de_sma_paere_3_color_power_on_behavior` — `unknown`
- `select.lampe_gang_color_power_on_behavior` — `unknown`
- `select.lampe_spisebord_color_power_on_behavior` — `unknown`
- `select.lille_lampe_color_power_on_behavior` — `unknown`
- `select.lille_lampe_effect` — `unknown`
- `select.lille_lampe_power_on_behavior` — `on`
- `select.loftlampe_bryggers_color_power_on_behavior` — `unknown`
- `select.loftlampe_kokken_color_power_on_behavior` — `unknown`
- `select.loftlampe_sebastian_color_power_on_behavior` — `unknown`
- `select.loftlampe_sofia_color_power_on_behavior` — `unknown`
- `select.loftlampe_sovevaerelse_color_power_on_behavior` — `unknown`
- `select.loftlampe_stue_color_power_on_behavior` — `unknown`
- `select.natlampe_2_color_power_on_behavior` — `unknown`
- `select.natlampe_2_power_on_behavior` — `on`
- `select.natlampe_color_power_on_behavior` — `unknown`
- `select.natlampe_power_on_behavior` — `on`
- `select.spot_hoveddor_1_color_power_on_behavior` — `unavailable`
- `select.spot_hoveddor_1_power_on_behavior` — `unavailable`
- `select.spot_hoveddor_2_color_power_on_behavior` — `unavailable`
- `select.spot_hoveddor_2_power_on_behavior` — `unavailable`
- `select.temp_stue_temperature_units` — `unknown`
- `select.zigbee2mqtt_bridge_log_level` — `info`
- `sensor.0x0000000001714ade_last_seen` — `unknown`
- `sensor.0x0000000001714ade_linkquality` — `unknown`
- `sensor.0x0cae5ffffed10fd2_last_seen` — `unknown`
- `sensor.0x0cae5ffffed10fd2_linkquality` — `unknown`
- `sensor.0xa4c138312c122baa_last_seen` — `unknown`
- `sensor.0xa4c138312c122baa_linkquality` — `unknown`
- `sensor.0xa4c1383c67fc69da_last_seen` — `unknown`
- `sensor.0xa4c1383c67fc69da_linkquality` — `unknown`
- `sensor.0xa4c13862b3e83b4d_last_seen` — `unknown`
- `sensor.0xa4c13862b3e83b4d_linkquality` — `unknown`
- `sensor.0xa4c138660fe2058a_last_seen` — `unknown`
- `sensor.0xa4c138660fe2058a_linkquality` — `unknown`
- `sensor.0xa4c1386c83e5e3a6_last_seen` — `unknown`
- `sensor.0xa4c1386c83e5e3a6_linkquality` — `unknown`
- `sensor.0xa4c1387f1efbb7b4_last_seen` — `unknown`
- `sensor.0xa4c1387f1efbb7b4_linkquality` — `unknown`
- `sensor.0xa4c1388d5e4bed62_last_seen` — `unknown`
- `sensor.0xa4c1388d5e4bed62_linkquality` — `unknown`
- `sensor.0xa4c1389d8fc50e9e_last_seen` — `unknown`
- `sensor.0xa4c1389d8fc50e9e_linkquality` — `unknown`
- `sensor.0xa4c1389de2ac12d0_last_seen` — `unknown`
- `sensor.0xa4c1389de2ac12d0_linkquality` — `unknown`
- `sensor.0xa4c138ab3197ecdf_last_seen` — `unknown`
- `sensor.0xa4c138ab3197ecdf_linkquality` — `unknown`
- `sensor.0xa4c138b01f675fef_last_seen` — `unknown`
- `sensor.0xa4c138b01f675fef_linkquality` — `unknown`
- `sensor.0xa4c138b4051e6603_last_seen` — `unknown`
- `sensor.0xa4c138b4051e6603_linkquality` — `unknown`
- `sensor.0xa4c138bf6a50d1db_last_seen` — `unknown`
- `sensor.0xa4c138bf6a50d1db_linkquality` — `unknown`
- `sensor.0xe8ca50dda00d0000_last_seen` — `unknown`
- `sensor.0xe8ca50dda00d0000_linkquality` — `unknown`
- `sensor.0xe8ca50ddece90000_last_seen` — `unknown`
- `sensor.0xe8ca50ddece90000_linkquality` — `unknown`
- `sensor.0xe8ca50ddee080000_last_seen` — `unknown`
- `sensor.0xe8ca50ddee080000_linkquality` — `unknown`
- `sensor.0xe8ca50ddf96c0000_last_seen` — `unknown`
- `sensor.0xe8ca50ddf96c0000_linkquality` — `unknown`
- `sensor.0xe8ca50ddf9bc0000_last_seen` — `unknown`
- `sensor.0xe8ca50ddf9bc0000_linkquality` — `unknown`
- `sensor.0xe8ca50ddfe570000_last_seen` — `unknown`
- `sensor.0xe8ca50ddfe570000_linkquality` — `unknown`
- `sensor.0xe8ca50de33300000_last_seen` — `unknown`
- `sensor.0xe8ca50de33300000_linkquality` — `unknown`
- `sensor.0xe8ca50de41110000_last_seen` — `unknown`
- `sensor.0xe8ca50de41110000_linkquality` — `unknown`
- `sensor.0xe8ca50de54d40000_last_seen` — `unknown`
- `sensor.0xe8ca50de54d40000_linkquality` — `unknown`
- `sensor.0xe8ca50de7c1c0000_last_seen` — `unknown`
- `sensor.0xe8ca50de7c1c0000_linkquality` — `unknown`
- `sensor.0xe8ca50de90a20000_last_seen` — `unknown`
- `sensor.0xe8ca50de90a20000_linkquality` — `unknown`
- `sensor.0xe8ca50deb78c0000_last_seen` — `unknown`
- `sensor.0xe8ca50deb78c0000_linkquality` — `unknown`
- `sensor.badevaerelse_spot_3_last_seen` — `unknown`
- `sensor.badevaerelse_spot_3_linkquality` — `unknown`
- `sensor.bevaegelses_sensor_badevaerelse_battery` — `90`
- `sensor.bevaegelses_sensor_badevaerelse_illuminance` — `0`
- `sensor.kontakt_de_smas_vaerelse_action` — `unknown`
- `sensor.kontakt_de_smas_vaerelse_last_seen` — `unknown`
- `sensor.kontakt_de_smas_vaerelse_linkquality` — `unknown`
- `sensor.kontakt_kokken_action` — `unknown`
- `sensor.kontakt_kokken_last_seen` — `unknown`
- `sensor.kontakt_kokken_linkquality` — `unknown`
- `sensor.kontakt_over_seng_action` — `unavailable`
- `sensor.kontakt_over_seng_last_seen` — `unknown`
- `sensor.kontakt_over_seng_linkquality` — `unknown`
- `sensor.kontakt_rumdeler_action` — `unavailable`
- `sensor.kontakt_rumdeler_last_seen` — `unknown`
- `sensor.kontakt_rumdeler_linkquality` — `unknown`
- `sensor.kontakt_sebastian_action` — `unknown`
- `sensor.kontakt_sofia_action` — `unknown`
- `sensor.kontakt_sofia_last_seen` — `unknown`
- `sensor.kontakt_sofia_linkquality` — `unknown`
- `sensor.kontakt_stue_action` — `unavailable`
- `sensor.kontakt_stue_last_seen` — `unknown`
- `sensor.kontakt_stue_linkquality` — `unknown`
- `sensor.temp_stue_battery` — `100`
- `sensor.temp_stue_humidity` — `56.6`
- `sensor.temp_stue_temperature` — `23.2`
- `sensor.zigbee2mqtt_bridge_coordinator_version` — `unknown`
- `sensor.zigbee2mqtt_bridge_network_map` — `unknown`
- `sensor.zigbee2mqtt_bridge_version` — `2.9.2`
- `switch.badevaerelse_spot_1_do_not_disturb` — `off`
- `switch.badevaerelse_spot_2_do_not_disturb` — `off`
- `switch.badevaerelse_spot_3_do_not_disturb` — `off`
- `switch.badevaerelse_spot_4_do_not_disturb` — `off`
- `switch.badevaerelse_spot_5_do_not_disturb` — `off`
- `switch.kokken_spot_1_do_not_disturb` — `off`
- `switch.kokken_spot_2_do_not_disturb` — `off`
- `switch.kokken_spot_3_do_not_disturb` — `off`
- `switch.lampe_de_sma_paere_1_do_not_disturb` — `off`
- `switch.lampe_de_sma_paere_2_do_not_disturb` — `off`
- `switch.lampe_de_sma_paere_3_do_not_disturb` — `off`
- `switch.lampe_gang_do_not_disturb` — `off`
- `switch.lampe_spisebord_do_not_disturb` — `off`
- `switch.lille_lampe_do_not_disturb` — `off`
- `switch.loftlampe_bryggers_do_not_disturb` — `off`
- `switch.loftlampe_kokken_do_not_disturb` — `off`
- `switch.loftlampe_sebastian_do_not_disturb` — `off`
- `switch.loftlampe_sofia_do_not_disturb` — `off`
- `switch.loftlampe_sovevaerelse_do_not_disturb` — `off`
- `switch.loftlampe_stue_do_not_disturb` — `off`
- `switch.natlampe_2_do_not_disturb` — `off`
- `switch.natlampe_do_not_disturb` — `off`
- `switch.spot_hoveddor_1_do_not_disturb` — `unavailable`
- `switch.spot_hoveddor_2_do_not_disturb` — `unavailable`
- `switch.usb_kontakt_stue_1_center` — `off`
- `switch.usb_kontakt_stue_1_left` — `off`
- `switch.usb_kontakt_stue_1_right` — `off`
- `switch.zigbee2mqtt_bridge_permit_join` — `off`
- `update.temp_stue` — `off`

## music_assistant

- Count: `40`
- Raw unknown/unavailable: `21`

- `button.all_units_favorite_current_song` — `unknown`
- `button.badevaerelse_favorite_current_song` — `unknown`
- `button.bryggers_favorite_current_song` — `unknown`
- `button.de_smas_vaerelse_favorite_current_song` — `unknown`
- `button.fjernsyn_favorite_current_song` — `unknown`
- `button.hojttaler_gruppe_1_favorite_current_song` — `unknown`
- `button.hojttaler_uden_hubs_favorite_current_song` — `unknown`
- `button.hub_stue_og_sovevaerelse_favorite_current_song` — `unknown`
- `button.hubs_favorite_current_song` — `unknown`
- `button.kokken_favorite_current_song` — `unknown`
- `button.mini_favorite_current_song` — `unknown`
- `button.sebastian_favorite_current_song` — `unknown`
- `button.sma_og_sovevaerelse_favorite_current_song` — `unknown`
- `button.sofias_vaerelse_favorite_current_song` — `unknown`
- `button.sovevaerelse_favorite_current_song` — `unavailable`
- `button.sovevaerelse_hub_favorite_current_song` — `unknown`
- `button.sovevaerelset_og_de_smas_vaerelse_favorite_current_song` — `unknown`
- `button.stue_favorite_current_song` — `unknown`
- `button.stue_hojttaler_favorite_current_song` — `unknown`
- `button.stue_og_sovevaerelse_favorite_current_song` — `unknown`
- `media_player.all_units_2` — `off`
- `media_player.badevaerelse_2` — `idle`
- `media_player.bryggers_2` — `idle`
- `media_player.de_smas_vaerelse_2` — `idle`
- `media_player.fjernsyn` — `idle`
- `media_player.hojttaler_gruppe_1_2` — `off`
- `media_player.hojttaler_uden_hubs_2` — `off`
- `media_player.hub_stue_og_sovevaerelse_2` — `off`
- `media_player.hubs_2` — `off`
- `media_player.kokken_2` — `idle`
- `media_player.mini_2` — `off`
- `media_player.sebastian_2` — `idle`
- `media_player.sma_og_sovevaerelse_2` — `off`
- `media_player.sofias_vaerelse_2` — `idle`
- `media_player.sovevaerelse_2` — `unavailable`
- `media_player.sovevaerelse_hub_2` — `idle`
- `media_player.sovevaerelset_og_de_smas_vaerelse` — `off`
- `media_player.stue_2` — `idle`
- `media_player.stue_hojttaler_2` — `idle`
- `media_player.stue_og_sovevaerelse_2` — `off`

## openai_conversation

- Count: `4`
- Raw unknown/unavailable: `4`

- `ai_task.openai_ai_task` — `unknown`
- `conversation.openai_conversation` — `unknown`
- `stt.openai_stt` — `unknown`
- `tts.openai_tts` — `unknown`

## person

- Count: `4`
- Raw unknown/unavailable: `2`

- `person.bent_dinesen_schmidt_christiansen` — `home`
- `person.maja` — `unknown`
- `person.sebastian_dinesen_philip_christiansen` — `unknown`
- `person.sofie_dinesen_philip_christiansen` — `not_home`

## proxmoxve

- Count: `164`
- Raw unknown/unavailable: `41`

- `binary_sensor.adguard_status` — `on`
- `binary_sensor.frigate_status` — `on`
- `binary_sensor.hadashboard_status` — `off`
- `binary_sensor.homeassistant_status` — `on`
- `binary_sensor.hp_mini_backup_status` — `off`
- `binary_sensor.hp_mini_status` — `on`
- `binary_sensor.jellyfin_status` — `on`
- `binary_sensor.nextcloud_status` — `on`
- `binary_sensor.proxy_status` — `on`
- `binary_sensor.storage_local_lvm_storage_active` — `on`
- `binary_sensor.storage_local_lvm_storage_enabled` — `on`
- `binary_sensor.storage_local_lvm_storage_shared` — `off`
- `binary_sensor.storage_local_storage_active` — `on`
- `binary_sensor.storage_local_storage_enabled` — `on`
- `binary_sensor.storage_local_storage_shared` — `off`
- `binary_sensor.zigbee2mqtt_status` — `on`
- `button.adguard_create_snapshot` — `unknown`
- `button.adguard_genstart` — `unknown`
- `button.adguard_start` — `unknown`
- `button.adguard_stop` — `unknown`
- `button.frigate_create_snapshot` — `unknown`
- `button.frigate_genstart` — `unknown`
- `button.frigate_start` — `unknown`
- `button.frigate_stop` — `unknown`
- `button.hadashboard_create_snapshot` — `unknown`
- `button.hadashboard_genstart` — `unknown`
- `button.hadashboard_start` — `unknown`
- `button.hadashboard_stop` — `unknown`
- `button.homeassistant` — `unknown`
- `button.homeassistant_create_snapshot` — `unknown`
- `button.homeassistant_genstart` — `unknown`
- `button.homeassistant_hibernate` — `unknown`
- `button.homeassistant_reset` — `unknown`
- `button.homeassistant_shut_down` — `unknown`
- `button.homeassistant_start` — `unknown`
- `button.homeassistant_stop` — `unknown`
- `button.hp_mini_genstart` — `unknown`
- `button.hp_mini_shut_down` — `unknown`
- `button.hp_mini_start_all` — `unknown`
- `button.hp_mini_stop_all` — `unknown`
- `button.hp_mini_suspend_all` — `unknown`
- `button.jellyfin_create_snapshot` — `unknown`
- `button.jellyfin_genstart` — `unknown`
- `button.jellyfin_start` — `unknown`
- `button.jellyfin_stop` — `unknown`
- `button.nextcloud_create_snapshot` — `unknown`
- `button.nextcloud_genstart` — `unknown`
- `button.nextcloud_start` — `unknown`
- `button.nextcloud_stop` — `unknown`
- `button.proxy_create_snapshot` — `unknown`
- `button.proxy_genstart` — `unknown`
- `button.proxy_start` — `unknown`
- `button.proxy_stop` — `unknown`
- `button.zigbee2mqtt_create_snapshot` — `unknown`
- `button.zigbee2mqtt_genstart` — `unknown`
- `button.zigbee2mqtt_start` — `unknown`
- `button.zigbee2mqtt_stop` — `unknown`
- `sensor.adguard_cpu_usage` — `0.0858360077545516`
- `sensor.adguard_disk_usage` — `1.26094436645508`
- `sensor.adguard_max_cpu` — `1`
- `sensor.adguard_max_disk_usage` — `1.90024566650391`
- `sensor.adguard_max_memory_usage` — `0.5`
- `sensor.adguard_memory_usage` — `0.0595169067382812`
- `sensor.adguard_memory_usage_percentage` — `11.9033813476562`
- `sensor.adguard_network_input` — `0.302515191957355`
- `sensor.adguard_network_output` — `0.0424216231331229`
- `sensor.adguard_status` — `running`
- `sensor.adguard_uptime` — `51.4761111111111`
- `sensor.frigate_cpu_usage` — `21.9263081653211`
- `sensor.frigate_disk_usage` — `10.7278251647949`
- `sensor.frigate_max_cpu` — `4`
- `sensor.frigate_max_disk_usage` — `19.5181427001953`
- `sensor.frigate_max_memory_usage` — `4.0`
- `sensor.frigate_memory_usage` — `0.656719207763672`
- `sensor.frigate_memory_usage_percentage` — `16.4179801940918`
- `sensor.frigate_network_input` — `128.267546872608`
- `sensor.frigate_network_output` — `2.93577069230378`
- `sensor.frigate_status_2` — `running`
- `sensor.frigate_uptime_2` — `13.3597222222222`
- `sensor.hadashboard_cpu_usage` — `0`
- `sensor.hadashboard_disk_usage` — `0.0`
- `sensor.hadashboard_max_cpu` — `2`
- `sensor.hadashboard_max_disk_usage` — `20.0`
- `sensor.hadashboard_max_memory_usage` — `1.0`
- `sensor.hadashboard_memory_usage` — `0.0`
- `sensor.hadashboard_memory_usage_percentage` — `0.0`
- `sensor.hadashboard_network_input` — `0.0`
- `sensor.hadashboard_network_output` — `0.0`
- `sensor.hadashboard_status` — `stopped`
- `sensor.hadashboard_uptime` — `0.0`
- `sensor.homeassistant_cpu_usage` — `3.74657441150223`
- `sensor.homeassistant_disk_usage` — `0.0`
- `sensor.homeassistant_max_cpu` — `4`
- `sensor.homeassistant_max_disk_usage` — `32.0`
- `sensor.homeassistant_max_memory_usage` — `4.0`
- `sensor.homeassistant_memory_usage` — `3.65859222412109`
- `sensor.homeassistant_memory_usage_percentage` — `91.4648056030273`
- `sensor.homeassistant_network_input` — `3.73513714782894`
- `sensor.homeassistant_network_output` — `1.39521459303796`
- `sensor.homeassistant_status` — `running`
- `sensor.homeassistant_uptime` — `51.1969444444444`
- `sensor.hp_mini_backup_duration` — `1.4`
- `sensor.hp_mini_cpu_usage` — `21.2652844231792`
- `sensor.hp_mini_disk_usage` — `28.1986274719238`
- `sensor.hp_mini_last_backup` — `2026-06-28T11:36:10+00:00`
- `sensor.hp_mini_max_cpu` — `6`
- `sensor.hp_mini_max_disk_usage` — `67.8722076416016`
- `sensor.hp_mini_max_memory_usage` — `7.41191482543945`
- `sensor.hp_mini_memory_usage` — `6.26721572875977`
- `sensor.hp_mini_memory_usage_percentage` — `84.5559599153675`
- `sensor.hp_mini_status` — `online`
- `sensor.hp_mini_uptime` — `51.4816666666667`
- `sensor.jellyfin_cpu_usage` — `0.154171470238758`
- `sensor.jellyfin_disk_usage` — `3.84213256835938`
- `sensor.jellyfin_max_cpu` — `2`
- `sensor.jellyfin_max_disk_usage` — `15.5809288024902`
- `sensor.jellyfin_max_memory_usage` — `2.0`
- `sensor.jellyfin_memory_usage` — `0.3289794921875`
- `sensor.jellyfin_memory_usage_percentage` — `16.448974609375`
- `sensor.jellyfin_network_input` — `0.297598976641893`
- `sensor.jellyfin_network_output` — `0.384919934906065`
- `sensor.jellyfin_status` — `running`
- `sensor.jellyfin_uptime` — `51.4761111111111`
- `sensor.nextcloud_cpu_usage` — `1.06169974640096`
- `sensor.nextcloud_disk_usage` — `17.7850952148438`
- `sensor.nextcloud_max_cpu` — `2`
- `sensor.nextcloud_max_disk_usage` — `19.5181427001953`
- `sensor.nextcloud_max_memory_usage` — `2.0`
- `sensor.nextcloud_memory_usage` — `0.143207550048828`
- `sensor.nextcloud_memory_usage_percentage` — `7.16037750244141`
- `sensor.nextcloud_network_input` — `0.314147878438234`
- `sensor.nextcloud_network_output` — `0.0221770396456122`
- `sensor.nextcloud_status` — `running`
- `sensor.nextcloud_uptime` — `50.8016666666667`
- `sensor.proxy_cpu_usage` — `0.202506309556855`
- `sensor.proxy_disk_usage` — `2.76371765136719`
- `sensor.proxy_max_cpu` — `1`
- `sensor.proxy_max_disk_usage` — `7.77682113647461`
- `sensor.proxy_max_memory_usage` — `0.5`
- `sensor.proxy_memory_usage` — `0.0891914367675781`
- `sensor.proxy_memory_usage_percentage` — `17.8382873535156`
- `sensor.proxy_network_input` — `0.389009656384587`
- `sensor.proxy_network_output` — `0.0637820847332478`
- `sensor.proxy_status` — `running`
- `sensor.proxy_uptime` — `51.4761111111111`
- `sensor.storage_local_available_storage` — `36.1821746826172`
- `sensor.storage_local_lvm_available_storage` — `50.3999039065093`
- `sensor.storage_local_lvm_storage_usage_percentage` — `64.4`
- `sensor.storage_local_lvm_total_storage` — `141.65234375`
- `sensor.storage_local_lvm_used_storage` — `91.2524398434907`
- `sensor.storage_local_storage_usage_percentage` — `41.5`
- `sensor.storage_local_total_storage` — `67.8722076416016`
- `sensor.storage_local_used_storage` — `28.1986274719238`
- `sensor.zigbee2mqtt_cpu_usage` — `0.0654187049391485`
- `sensor.zigbee2mqtt_disk_usage` — `2.38711547851562`
- `sensor.zigbee2mqtt_max_cpu` — `2`
- `sensor.zigbee2mqtt_max_disk_usage` — `4.83950805664062`
- `sensor.zigbee2mqtt_max_memory_usage` — `1.0`
- `sensor.zigbee2mqtt_memory_usage` — `0.100597381591797`
- `sensor.zigbee2mqtt_memory_usage_percentage` — `10.0597381591797`
- `sensor.zigbee2mqtt_network_input` — `0.320973188616335`
- `sensor.zigbee2mqtt_network_output` — `0.0570139894261956`
- `sensor.zigbee2mqtt_status` — `running`
- `sensor.zigbee2mqtt_uptime` — `51.4761111111111`

## schedule

- Count: `1`
- Raw unknown/unavailable: `0`

- `schedule.test` — `off`

## script

- Count: `11`
- Raw unknown/unavailable: `0`

- `script.dorklokke` — `off`
- `script.fest` — `off`
- `script.natlys_de_sma` — `off`
- `script.natlys_sebastian` — `off`
- `script.natlys_sofia` — `off`
- `script.print_entity_attributes` — `off`
- `script.wakeup_de_sma` — `off`
- `script.wakeup_kokken` — `off`
- `script.wakeup_sebastian` — `off`
- `script.wakeup_sofia` — `off`
- `script.wakeup_sovevarelse` — `off`

## shelly

- Count: `24`
- Raw unknown/unavailable: `21`

- `binary_sensor.diskokugle_cloud` — `unknown`
- `binary_sensor.diskokugle_input` — `unknown`
- `binary_sensor.shelly1_3494546a3372_cloud` — `unknown`
- `binary_sensor.shelly1_3494546a3372_input` — `unknown`
- `binary_sensor.shelly1_3494546ae397_cloud` — `unknown`
- `binary_sensor.shelly1_3494546ae397_input` — `unknown`
- `button.diskokugle_reboot` — `unknown`
- `button.facadelys_reboot` — `unknown`
- `button.shelly1_3494546ae397_reboot` — `unknown`
- `sensor.diskokugle_rssi` — `unknown`
- `sensor.diskokugle_uptime` — `unknown`
- `sensor.shelly1_3494546a3372_rssi` — `unknown`
- `sensor.shelly1_3494546a3372_uptime` — `unknown`
- `sensor.shelly1_3494546ae397_rssi` — `unknown`
- `sensor.shelly1_3494546ae397_uptime` — `unknown`
- `switch.diskokugle` — `off`
- `switch.facadelys` — `off`
- `switch.shelly1_3494546ae397` — `off`
- `update.diskokugle_beta_firmware_update` — `unknown`
- `update.diskokugle_firmware_update` — `unknown`
- `update.shelly1_3494546a3372_beta_firmware` — `unknown`
- `update.shelly1_3494546a3372_firmware` — `unknown`
- `update.shelly1_3494546ae397_beta_firmware_update` — `unknown`
- `update.shelly1_3494546ae397_firmware_update` — `unknown`

## shopping_list

- Count: `1`
- Raw unknown/unavailable: `0`

- `todo.indkobsliste` — `0`

## spotify

- Count: `12`
- Raw unknown/unavailable: `11`

- `media_player.spotify_bent_christiansen` — `idle`
- `sensor.spotify_bent_christiansen_song_acousticness` — `unknown`
- `sensor.spotify_bent_christiansen_song_danceability` — `unknown`
- `sensor.spotify_bent_christiansen_song_energy` — `unknown`
- `sensor.spotify_bent_christiansen_song_instrumentalness` — `unknown`
- `sensor.spotify_bent_christiansen_song_key` — `unknown`
- `sensor.spotify_bent_christiansen_song_liveness` — `unknown`
- `sensor.spotify_bent_christiansen_song_mode` — `unknown`
- `sensor.spotify_bent_christiansen_song_speechiness` — `unknown`
- `sensor.spotify_bent_christiansen_song_tempo` — `unavailable`
- `sensor.spotify_bent_christiansen_song_time_signature` — `unknown`
- `sensor.spotify_bent_christiansen_song_valence` — `unknown`

## sun

- Count: `9`
- Raw unknown/unavailable: `3`

- `binary_sensor.sun_solar_rising` — `unknown`
- `sensor.sun_next_dawn` — `2026-07-05T01:49:27+00:00`
- `sensor.sun_next_dusk` — `2026-07-05T21:05:41+00:00`
- `sensor.sun_next_midnight` — `2026-07-04T23:28:04+00:00`
- `sensor.sun_next_noon` — `2026-07-05T11:27:58+00:00`
- `sensor.sun_next_rising` — `2026-07-05T02:49:01+00:00`
- `sensor.sun_next_setting` — `2026-07-05T20:06:29+00:00`
- `sensor.sun_solar_azimuth` — `unknown`
- `sensor.sun_solar_elevation` — `unknown`

## switch_as_x

- Count: `1`
- Raw unknown/unavailable: `0`

- `light.kabelskinne_usb_1` — `off`

## tapo_control

- Count: `82`
- Raw unknown/unavailable: `40`

- `binary_sensor.ringklokke_doorbell` — `off`
- `button.ringklokke_format_sd_card` — `unknown`
- `button.ringklokke_manual_alarm_start` — `unknown`
- `button.ringklokke_manual_alarm_stop` — `unknown`
- `button.ringklokke_reboot` — `unknown`
- `button.ringklokke_sync_time` — `unavailable`
- `camera.ringklokke_hd_stream_direct` — `idle`
- `camera.ringklokke_sd_stream_direct` — `unknown`
- `light.ringklokke_floodlight_timed` — `off`
- `number.ringklokke_microphone_volume` — `100`
- `number.ringklokke_motion_detection_digital_sensitivity` — `60`
- `number.ringklokke_speaker_volume` — `100`
- `number.ringklokke_spotlight_intensity` — `3`
- `select.ringklokke_automatic_alarm` — `off`
- `select.ringklokke_automatic_reboot_time` — `03:00 - 03:30`
- `select.ringklokke_light_frequency` — `50`
- `select.ringklokke_motion_detection` — `off`
- `select.ringklokke_night_vision` — `Infrared Mode`
- `select.ringklokke_night_vision_switching` — `auto`
- `select.ringklokke_person_detection` — `off`
- `select.ringklokke_pet_detection` — `off`
- `select.ringklokke_siren_type` — `Siren`
- `select.ringklokke_spotlight_on_off_for` — `5 min`
- `select.ringklokke_timezone` — `UTC+01:00 (Europe/Brussels)`
- `select.ringklokke_vehicle_detection` — `off`
- `sensor.hoveddor_ringklokke_disk_1_hardware_security_config` — `unknown`
- `sensor.hoveddor_ringklokke_disk_1_password` — `unknown`
- `sensor.hoveddor_ringklokke_disk_1_security_status` — `unknown`
- `sensor.ringklokke_battery` — `100`
- `sensor.ringklokke_disk_1_crossline_free_space` — `unknown`
- `sensor.ringklokke_disk_1_crossline_free_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_crossline_total_space` — `unknown`
- `sensor.ringklokke_disk_1_crossline_total_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_detect_status` — `unknown`
- `sensor.ringklokke_disk_1_disk_name` — `unknown`
- `sensor.ringklokke_disk_1_free_space` — `unknown`
- `sensor.ringklokke_disk_1_free_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_loop_record_status` — `unknown`
- `sensor.ringklokke_disk_1_msg_push_free_space` — `unknown`
- `sensor.ringklokke_disk_1_msg_push_free_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_msg_push_total_space` — `unknown`
- `sensor.ringklokke_disk_1_msg_push_total_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_percent` — `unknown`
- `sensor.ringklokke_disk_1_picture_free_space` — `unknown`
- `sensor.ringklokke_disk_1_picture_free_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_picture_total_space` — `unknown`
- `sensor.ringklokke_disk_1_picture_total_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_record_duration` — `unknown`
- `sensor.ringklokke_disk_1_record_free_duration` — `unknown`
- `sensor.ringklokke_disk_1_record_start_time` — `unknown`
- `sensor.ringklokke_disk_1_rw_attr` — `unknown`
- `sensor.ringklokke_disk_1_status` — `unknown`
- `sensor.ringklokke_disk_1_total_space` — `unknown`
- `sensor.ringklokke_disk_1_total_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_type` — `unknown`
- `sensor.ringklokke_disk_1_video_free_space` — `unknown`
- `sensor.ringklokke_disk_1_video_free_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_video_total_space` — `unknown`
- `sensor.ringklokke_disk_1_video_total_space_accurate` — `unknown`
- `sensor.ringklokke_disk_1_write_protect` — `unknown`
- `sensor.ringklokke_last_automatic_reboot_time` — `2026-06-23T01:38:07+00:00`
- `sensor.ringklokke_link_type` — `wifi`
- `sensor.ringklokke_network_ssid` — `Det lille hjem`
- `sensor.ringklokke_recordings_synchronization` — `Idle`
- `sensor.ringklokke_rssi` — `-48`
- `siren.ringklokke_siren` — `off`
- `switch.ringklokke_automatic_reboot` — `off`
- `switch.ringklokke_automatically_upgrade_firmware` — `on`
- `switch.ringklokke_diagnose_mode` — `off`
- `switch.ringklokke_flip` — `on`
- `switch.ringklokke_indicator_led` — `off`
- `switch.ringklokke_lens_distortion_correction` — `off`
- `switch.ringklokke_media_sync` — `off`
- `switch.ringklokke_microphone_mute` — `off`
- `switch.ringklokke_microphone_noise_cancellation` — `on`
- `switch.ringklokke_notifications` — `on`
- `switch.ringklokke_privacy` — `off`
- `switch.ringklokke_privacy_zones` — `off`
- `switch.ringklokke_record_audio` — `on`
- `switch.ringklokke_record_to_sd_card` — `on`
- `switch.ringklokke_rich_notifications` — `off`
- `update.ringklokke_update` — `off`

## tplink

- Count: `13`
- Raw unknown/unavailable: `6`

- `binary_sensor.kaffe_hjornet_cloud_connection` — `on`
- `button.kaffe_hjornet_genstart` — `unknown`
- `number.kaffe_hjornet_turn_off_in` — `120`
- `sensor.kaffe_hjornet_auto_off_at` — `unknown`
- `sensor.kaffe_hjornet_device_time` — `unknown`
- `sensor.kaffe_hjornet_on_since` — `unknown`
- `sensor.kaffe_hjornet_signal_level` — `2`
- `sensor.kaffe_hjornet_signal_strength` — `unknown`
- `sensor.kaffe_hjornet_ssid` — `unknown`
- `switch.kaffe_hjornet` — `on`
- `switch.kaffe_hjornet_auto_off_enabled` — `off`
- `switch.kaffe_hjornet_auto_update_enabled` — `on`
- `switch.kaffe_hjornet_led` — `on`

## tplink_deco

- Count: `89`
- Raw unknown/unavailable: `15`

- `binary_sensor.kitchen_deco_deco_online` — `on`
- `binary_sensor.kitchen_deco_deco_online_2` — `on`
- `binary_sensor.kitchen_deco_internet_online` — `on`
- `binary_sensor.kitchen_deco_internet_online_2` — `on`
- `binary_sensor.vaskerum_deco_deco_online` — `on`
- `binary_sensor.vaskerum_deco_internet_online` — `on`
- `device_tracker.kitchen_deco` — `home`
- `device_tracker.kitchen_deco_2` — `home`
- `device_tracker.kitchen_deco_d100c` — `home`
- `device_tracker.kitchen_deco_fjernsyn_stue` — `home`
- `device_tracker.kitchen_deco_google_home` — `home`
- `device_tracker.kitchen_deco_google_home_2` — `home`
- `device_tracker.kitchen_deco_google_home_mini` — `home`
- `device_tracker.kitchen_deco_google_home_mini_2` — `home`
- `device_tracker.kitchen_deco_iot_device_0a30` — `home`
- `device_tracker.kitchen_deco_iot_device_2d49` — `home`
- `device_tracker.kitchen_deco_ipad` — `not_home`
- `device_tracker.kitchen_deco_ipad_2` — `home`
- `device_tracker.kitchen_deco_ipad_3` — `home`
- `device_tracker.kitchen_deco_iphone` — `home`
- `device_tracker.kitchen_deco_iphone_2` — `not_home`
- `device_tracker.kitchen_deco_ledsove` — `not_home`
- `device_tracker.kitchen_deco_ledss` — `not_home`
- `device_tracker.kitchen_deco_p100` — `home`
- `device_tracker.kitchen_deco_pc_8a31` — `home`
- `device_tracker.kitchen_deco_phone_c504` — `home`
- `device_tracker.kitchen_deco_phone_d366` — `home`
- `device_tracker.kitchen_deco_sirblondiedk` — `home`
- `device_tracker.kitchen_deco_wiz_0123ac` — `home`
- `device_tracker.kitchen_deco_wledmic` — `not_home`
- `device_tracker.server_rum_deco_kokken_lenovo_tab` — `not_home`
- `device_tracker.server_rum_deco_kokken_lenovo_tab_2` — `not_home`
- `device_tracker.server_rum_deco_kokken_sebastianpc` — `not_home`
- `device_tracker.server_rum_deco_loft_chromecast` — `not_home`
- `device_tracker.server_rum_deco_loft_device_1501` — `home`
- `device_tracker.server_rum_deco_loft_device_1738` — `home`
- `device_tracker.server_rum_deco_loft_device_3d54` — `home`
- `device_tracker.server_rum_deco_loft_device_4f06` — `home`
- `device_tracker.server_rum_deco_stue_maja_iphone` — `home`
- `device_tracker.server_rum_deco_stue_sebastiipiphone` — `home`
- `device_tracker.vaskerum_deco` — `home`
- `device_tracker.vaskerum_deco_adguard` — `home`
- `device_tracker.vaskerum_deco_ajax_002133f1` — `home`
- `device_tracker.vaskerum_deco_d210` — `home`
- `device_tracker.vaskerum_deco_device_a5e8` — `home`
- `device_tracker.vaskerum_deco_device_d57f` — `home`
- `device_tracker.vaskerum_deco_esp_c2432f` — `home`
- `device_tracker.vaskerum_deco_google_home` — `home`
- `device_tracker.vaskerum_deco_google_home_mini` — `home`
- `device_tracker.vaskerum_deco_google_home_mini_2` — `home`
- `device_tracker.vaskerum_deco_homeassistant` — `home`
- `device_tracker.vaskerum_deco_kamera_1` — `home`
- `device_tracker.vaskerum_deco_kamera_2` — `home`
- `device_tracker.vaskerum_deco_kamera_3` — `home`
- `device_tracker.vaskerum_deco_proxy_server` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546a3372` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546a890c` — `home`
- `device_tracker.vaskerum_deco_shelly1_3494546ae397` — `home`
- `device_tracker.vaskerum_deco_wiz_44c896` — `home`
- `device_tracker.vaskerum_deco_wlan0` — `home`
- `device_tracker.vaskerum_deco_wlan0_2` — `home`
- `select.server_rum_deco_loft_polling_interval` — `30`
- `sensor.kitchen_deco_backhaul_type` — `unknown`
- `sensor.kitchen_deco_backhaul_type_2` — `unknown`
- `sensor.kitchen_deco_bssid_2_4_ghz` — `unknown`
- `sensor.kitchen_deco_bssid_2_4_ghz_2` — `unknown`
- `sensor.kitchen_deco_bssid_5_ghz` — `unknown`
- `sensor.kitchen_deco_bssid_5_ghz_2` — `unknown`
- `sensor.kitchen_deco_connected_clients` — `9`
- `sensor.kitchen_deco_connected_clients_2` — `10`
- `sensor.kitchen_deco_ip_address` — `unknown`
- `sensor.kitchen_deco_ip_address_2` — `unknown`
- `sensor.kitchen_deco_kitchen_down` — `0.0`
- `sensor.kitchen_deco_kitchen_down_2` — `0.125`
- `sensor.kitchen_deco_kitchen_up` — `0.0`
- `sensor.kitchen_deco_kitchen_up_2` — `0.125`
- `sensor.vaskerum_deco_bssid_2_4_ghz` — `unknown`
- `sensor.vaskerum_deco_bssid_5_ghz` — `unknown`
- `sensor.vaskerum_deco_connected_clients` — `24`
- `sensor.vaskerum_deco_cpu_usage` — `unknown`
- `sensor.vaskerum_deco_cpu_usage_raw` — `unknown`
- `sensor.vaskerum_deco_ip_address` — `unknown`
- `sensor.vaskerum_deco_memory_usage` — `unknown`
- `sensor.vaskerum_deco_memory_usage_raw` — `unknown`
- `sensor.vaskerum_deco_total_down` — `0.125`
- `sensor.vaskerum_deco_total_up` — `0.125`
- `sensor.vaskerum_deco_vaskerum_down` — `0.0`
- `sensor.vaskerum_deco_vaskerum_up` — `0.0`
- `switch.vaskerum_deco_polling` — `on`

## tuya

- Count: `22`
- Raw unknown/unavailable: `13`

- `select.pejs_power_on_behavior` — `last`
- `select.spillemaskine_power_on_behavior` — `last`
- `sensor.pejs_current` — `unknown`
- `sensor.pejs_power` — `unknown`
- `sensor.pejs_total_energy` — `0.807`
- `sensor.pejs_voltage` — `unknown`
- `sensor.pool_current` — `unknown`
- `sensor.pool_power` — `unknown`
- `sensor.pool_total_energy` — `unavailable`
- `sensor.pool_voltage` — `unknown`
- `sensor.spillemaskine_current` — `unknown`
- `sensor.spillemaskine_power` — `unknown`
- `sensor.spillemaskine_total_energy` — `0`
- `sensor.spillemaskine_voltage` — `unknown`
- `switch.deltaco_sh_p03usb2_socket` — `unknown`
- `switch.deltaco_sh_p03usb2_socket_1` — `unknown`
- `switch.deltaco_sh_p03usb2_socket_2` — `off`
- `switch.deltaco_sh_p03usb2_socket_3` — `off`
- `switch.deltaco_sh_p03usb2_usb_1` — `off`
- `switch.pejs_socket_1` — `on`
- `switch.pool_socket_1` — `unavailable`
- `switch.spillemaskine_socket_1` — `off`

## wake_on_lan

- Count: `2`
- Raw unknown/unavailable: `0`

- `button.wake_on_lan_24_41_8c_93_d0_ff` — `2025-01-08T20:33:46.742203+00:00`
- `switch.wake_on_lan` — `off`

## wiz

- Count: `8`
- Raw unknown/unavailable: `6`

- `light.wiz_rgbw_tunable_44c896` — `off`
- `light.wiz_rgbww_tunable_0123ac` — `off`
- `number.wiz_rgbw_tunable_44c896_effect_speed` — `unavailable`
- `number.wiz_rgbww_tunable_0123ac_effect_speed` — `unavailable`
- `sensor.wiz_rgbw_tunable_44c896_signalstyrke` — `unknown`
- `sensor.wiz_rgbw_tunable_44c896_strom` — `unknown`
- `sensor.wiz_rgbww_tunable_0123ac_signalstyrke` — `unknown`
- `sensor.wiz_rgbww_tunable_0123ac_strom` — `unknown`

## wled

- Count: `147`
- Raw unknown/unavailable: `147`

- `binary_sensor.wled_firmware` — `unavailable`
- `binary_sensor.wled_firmware_2` — `unavailable`
- `binary_sensor.wled_firmware_3` — `unknown`
- `button.wled_genstart` — `unavailable`
- `button.wled_genstart_2` — `unavailable`
- `button.wled_genstart_3` — `unavailable`
- `light.wled` — `unavailable`
- `light.wled_2` — `unavailable`
- `light.wled_3` — `unavailable`
- `light.wled_main` — `unavailable`
- `light.wled_main_2` — `unavailable`
- `light.wled_segment_1` — `unavailable`
- `light.wled_segment_1_2` — `unavailable`
- `light.wled_segment_2` — `unavailable`
- `light.wled_segment_2_2` — `unavailable`
- `light.wled_segment_3` — `unavailable`
- `light.wled_segment_3_2` — `unavailable`
- `light.wled_segment_4` — `unavailable`
- `light.wled_segment_4_2` — `unavailable`
- `light.wled_segment_5` — `unavailable`
- `light.wled_segment_5_2` — `unavailable`
- `light.wled_segment_6` — `unavailable`
- `light.wled_segment_6_2` — `unavailable`
- `light.wled_segment_7` — `unavailable`
- `light.wled_segment_7_2` — `unavailable`
- `number.wled_intensity` — `unavailable`
- `number.wled_intensity_2` — `unavailable`
- `number.wled_intensity_3` — `unavailable`
- `number.wled_segment_1_intensity` — `unavailable`
- `number.wled_segment_1_intensity_2` — `unavailable`
- `number.wled_segment_1_speed` — `unavailable`
- `number.wled_segment_1_speed_2` — `unavailable`
- `number.wled_segment_2_intensity` — `unavailable`
- `number.wled_segment_2_intensity_2` — `unavailable`
- `number.wled_segment_2_speed` — `unavailable`
- `number.wled_segment_2_speed_2` — `unavailable`
- `number.wled_segment_3_intensity` — `unavailable`
- `number.wled_segment_3_intensity_2` — `unavailable`
- `number.wled_segment_3_speed` — `unavailable`
- `number.wled_segment_3_speed_2` — `unavailable`
- `number.wled_segment_4_intensity` — `unavailable`
- `number.wled_segment_4_intensity_2` — `unavailable`
- `number.wled_segment_4_speed` — `unavailable`
- `number.wled_segment_4_speed_2` — `unavailable`
- `number.wled_segment_5_intensity` — `unavailable`
- `number.wled_segment_5_intensity_2` — `unavailable`
- `number.wled_segment_5_speed` — `unavailable`
- `number.wled_segment_5_speed_2` — `unavailable`
- `number.wled_segment_6_intensity` — `unavailable`
- `number.wled_segment_6_intensity_2` — `unavailable`
- `number.wled_segment_6_speed` — `unavailable`
- `number.wled_segment_6_speed_2` — `unavailable`
- `number.wled_segment_7_intensity` — `unavailable`
- `number.wled_segment_7_intensity_2` — `unavailable`
- `number.wled_segment_7_speed` — `unavailable`
- `number.wled_segment_7_speed_2` — `unavailable`
- `number.wled_speed` — `unavailable`
- `number.wled_speed_2` — `unavailable`
- `number.wled_speed_3` — `unavailable`
- `select.wled_color_palette` — `unavailable`
- `select.wled_color_palette_2` — `unavailable`
- `select.wled_color_palette_3` — `unavailable`
- `select.wled_live_override` — `unavailable`
- `select.wled_live_override_2` — `unavailable`
- `select.wled_live_override_3` — `unavailable`
- `select.wled_playlist` — `unavailable`
- `select.wled_playlist_2` — `unavailable`
- `select.wled_playlist_3` — `unavailable`
- `select.wled_preset` — `unavailable`
- `select.wled_preset_2` — `unavailable`
- `select.wled_preset_3` — `unavailable`
- `select.wled_segment_1_color_palette` — `unavailable`
- `select.wled_segment_1_color_palette_2` — `unavailable`
- `select.wled_segment_2_color_palette` — `unavailable`
- `select.wled_segment_2_color_palette_2` — `unavailable`
- `select.wled_segment_3_color_palette` — `unavailable`
- `select.wled_segment_3_color_palette_2` — `unavailable`
- `select.wled_segment_4_color_palette` — `unavailable`
- `select.wled_segment_4_color_palette_2` — `unavailable`
- `select.wled_segment_5_color_palette` — `unavailable`
- `select.wled_segment_5_color_palette_2` — `unavailable`
- `select.wled_segment_6_color_palette` — `unavailable`
- `select.wled_segment_6_color_palette_2` — `unavailable`
- `select.wled_segment_7_color_palette` — `unavailable`
- `select.wled_segment_7_color_palette_2` — `unavailable`
- `sensor.wled_estimated_current` — `unavailable`
- `sensor.wled_estimated_current_2` — `unavailable`
- `sensor.wled_estimated_current_3` — `unavailable`
- `sensor.wled_free_memory` — `unknown`
- `sensor.wled_free_memory_2` — `unknown`
- `sensor.wled_free_memory_3` — `unknown`
- `sensor.wled_ip` — `unavailable`
- `sensor.wled_ip_2` — `unavailable`
- `sensor.wled_ip_3` — `unavailable`
- `sensor.wled_led_count` — `unavailable`
- `sensor.wled_led_count_2` — `unavailable`
- `sensor.wled_led_count_3` — `unavailable`
- `sensor.wled_max_current` — `unavailable`
- `sensor.wled_max_current_2` — `unavailable`
- `sensor.wled_max_current_3` — `unavailable`
- `sensor.wled_uptime` — `unknown`
- `sensor.wled_uptime_2` — `unknown`
- `sensor.wled_uptime_3` — `unknown`
- `sensor.wled_wi_fi_bssid` — `unknown`
- `sensor.wled_wi_fi_bssid_2` — `unknown`
- `sensor.wled_wi_fi_bssid_3` — `unknown`
- `sensor.wled_wi_fi_channel` — `unknown`
- `sensor.wled_wi_fi_channel_2` — `unknown`
- `sensor.wled_wi_fi_channel_3` — `unknown`
- `sensor.wled_wi_fi_rssi` — `unknown`
- `sensor.wled_wi_fi_rssi_2` — `unknown`
- `sensor.wled_wi_fi_rssi_3` — `unknown`
- `sensor.wled_wi_fi_signal` — `unknown`
- `sensor.wled_wi_fi_signal_2` — `unknown`
- `sensor.wled_wi_fi_signal_3` — `unknown`
- `switch.stue_freeze` — `unavailable`
- `switch.wled_freeze` — `unavailable`
- `switch.wled_freeze_2` — `unavailable`
- `switch.wled_nightlight` — `unavailable`
- `switch.wled_nightlight_2` — `unavailable`
- `switch.wled_nightlight_3` — `unavailable`
- `switch.wled_reverse` — `unavailable`
- `switch.wled_reverse_2` — `unavailable`
- `switch.wled_reverse_3` — `unavailable`
- `switch.wled_segment_1_reverse` — `unavailable`
- `switch.wled_segment_1_reverse_2` — `unavailable`
- `switch.wled_segment_2_reverse` — `unavailable`
- `switch.wled_segment_2_reverse_2` — `unavailable`
- `switch.wled_segment_3_reverse` — `unavailable`
- `switch.wled_segment_3_reverse_2` — `unavailable`
- `switch.wled_segment_4_reverse` — `unavailable`
- `switch.wled_segment_4_reverse_2` — `unavailable`
- `switch.wled_segment_5_reverse` — `unavailable`
- `switch.wled_segment_5_reverse_2` — `unavailable`
- `switch.wled_segment_6_reverse` — `unavailable`
- `switch.wled_segment_6_reverse_2` — `unavailable`
- `switch.wled_segment_7_reverse` — `unavailable`
- `switch.wled_segment_7_reverse_2` — `unavailable`
- `switch.wled_sync_receive` — `unavailable`
- `switch.wled_sync_receive_2` — `unavailable`
- `switch.wled_sync_receive_3` — `unavailable`
- `switch.wled_sync_send` — `unavailable`
- `switch.wled_sync_send_2` — `unavailable`
- `switch.wled_sync_send_3` — `unavailable`
- `update.wled_firmware` — `unavailable`
- `update.wled_firmware_2` — `unavailable`
- `update.wled_firmware_3` — `unavailable`

## zone

- Count: `7`
- Raw unknown/unavailable: `0`

- `zone.baekke_skole` — `0`
- `zone.daglig_brugsen_baekke` — `0`
- `zone.farmor_s_hus` — `0`
- `zone.haervejshallen` — `0`
- `zone.hos_jim` — `0`
- `zone.mollevang_bornehave` — `0`
- `zone.sandersvig_camping` — `0`
